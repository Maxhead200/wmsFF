"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BillingDocumentService = void 0;
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
const prisma_service_1 = require("../../common/prisma/prisma.service");
const client_scope_service_1 = require("../auth/client-scope.service");
const billing_printing_1 = require("./billing-printing");
const own_companies_service_1 = require("../own-companies/own-companies.service");
let BillingDocumentService = class BillingDocumentService {
    prisma;
    clientScopes;
    ownCompanies;
    constructor(prisma, clientScopes, ownCompanies) {
        this.prisma = prisma;
        this.clientScopes = clientScopes;
        this.ownCompanies = ownCompanies;
    }
    async getInvoiceDocument(invoiceId, user) {
        const invoice = await this.prisma.billingInvoice.findUnique({
            where: { id: invoiceId },
            include: invoiceDocumentInclude,
        });
        if (!invoice) {
            throw new common_1.NotFoundException('Счет биллинга не найден.');
        }
        this.clientScopes.requireClientAccess(user, invoice.clientId, 'read');
        const invoiceWarehouseId = invoice.warehouseId ?? invoice.request?.warehouseId ?? null;
        if (user.activeWarehouseId &&
            !user.roleCodes.includes('CLIENT') &&
            !user.permissionCodes.includes('system:admin') &&
            invoiceWarehouseId !== user.activeWarehouseId) {
            throw new common_1.NotFoundException('Счёт биллинга не найден в активном филиале.');
        }
        if (invoice.status === client_1.BillingInvoiceStatus.DRAFT &&
            user.roleCodes.includes('CLIENT') &&
            !user.permissionCodes.includes('system:admin')) {
            throw new common_1.NotFoundException('Счет биллинга не найден.');
        }
        const rows = await this.buildPrintableRows(invoice);
        const payments = invoice.payments
            .filter((payment) => payment.status === client_1.BillingPaymentStatus.RECORDED)
            .map((payment) => ({
            id: payment.id,
            amountRub: Number(payment.amountRub),
            paidAt: payment.paidAt.toISOString(),
            method: payment.method,
            reference: payment.reference,
            comment: payment.comment,
        }));
        const totalRub = Number(invoice.totalRub);
        const paidRub = Number(invoice.paidRub);
        const remainingRub = roundMoney(totalRub - paidRub);
        const seller = await this.findSeller(invoice.clientId, invoice, invoiceWarehouseId ?? user.activeWarehouseId);
        const payload = {
            invoiceId: invoice.id,
            number: invoice.number,
            title: `Счет на оплату № ${(0, billing_printing_1.invoiceDisplayNumber)(invoice.number)}`,
            fileName: `${safeFileName(invoice.number)}.html`,
            status: invoice.status,
            statusLabel: invoiceStatusLabel(invoice.status),
            periodFrom: invoice.periodFrom.toISOString(),
            periodTo: invoice.periodTo.toISOString(),
            dueDate: invoice.dueDate?.toISOString() ?? null,
            issuedAt: invoice.issuedAt?.toISOString() ?? null,
            totalRub,
            paidRub,
            remainingRub,
            comment: invoice.comment,
            seller,
            client: {
                id: invoice.client.id,
                code: invoice.client.code,
                name: invoice.client.name,
                legalName: invoice.client.legalName,
                inn: invoice.client.inn,
                kpp: invoice.client.kpp,
                ogrn: invoice.client.ogrn,
                legalAddress: invoice.client.legalAddress,
                actualAddress: invoice.client.actualAddress,
                email: invoice.client.email,
                phone: invoice.client.phone,
                bankName: invoice.client.bankName,
                bankBik: invoice.client.bankBik,
                bankAccount: invoice.client.bankAccount,
                correspondentAccount: invoice.client.correspondentAccount,
            },
            rows,
            payments,
            createdBy: invoice.createdBy
                ? {
                    id: invoice.createdBy.id,
                    email: invoice.createdBy.email,
                    name: invoice.createdBy.name,
                }
                : null,
        };
        return {
            ...payload,
            html: renderInvoiceHtml(payload),
        };
    }
    async getInvoiceActDocument(invoiceId, user) {
        const invoiceDocument = await this.getInvoiceDocument(invoiceId, user);
        if (invoiceDocument.status !== client_1.BillingInvoiceStatus.PAID && !canForceAct(user)) {
            throw new common_1.ForbiddenException('Акт доступен клиенту только после оплаты счета.');
        }
        const actNumber = actNumberForInvoice(invoiceDocument.number);
        const title = `Акт № ${(0, billing_printing_1.invoiceDisplayNumber)(invoiceDocument.number)}`;
        const fileName = `${safeFileName(actNumber)}.html`;
        // Русский комментарий: акт строится из того же снимка счета, чтобы суммы и состав услуг не расходились между документами.
        return {
            ...invoiceDocument,
            documentKind: 'act',
            actNumber,
            title,
            fileName,
            html: renderActHtml({
                ...invoiceDocument,
                documentKind: 'act',
                actNumber,
                title,
                fileName,
            }),
        };
    }
    async findSeller(clientId, invoice, warehouseId) {
        const defaultSeller = this.ownCompanies
            ? await this.ownCompanies.findSellerForClient(clientId, undefined, warehouseId)
            : billing_printing_1.BILLING_SELLER;
        if (!invoice?.paymentBankAccountId) {
            return defaultSeller;
        }
        return {
            ...defaultSeller,
            bankName: invoice.paymentBankName ?? defaultSeller.bankName,
            bankBik: invoice.paymentBankBik ?? defaultSeller.bankBik,
            bankInn: invoice.paymentBankInn ?? defaultSeller.bankInn,
            bankKpp: invoice.paymentBankKpp ?? defaultSeller.bankKpp,
            bankAccount: invoice.paymentBankAccount ?? defaultSeller.bankAccount,
            correspondentAccount: invoice.paymentCorrespondentAccount ?? defaultSeller.correspondentAccount,
        };
    }
    async buildPrintableRows(invoice) {
        const normalizeMergedRows = isMergedInvoiceSourceKey(invoice.sourceKey);
        const basicRows = invoice.items.map((item) => ({
            description: item.description,
            unit: item.unit,
            quantity: Number(item.quantity),
            unitPriceRub: Number(item.unitPriceRub),
            totalRub: Number(item.totalRub),
            serviceDate: item.serviceDate.toISOString(),
        }));
        const orderQuantities = new Map();
        for (const item of invoice.items) {
            const orderId = fbsOrderIdFromDescription(item.description);
            if (orderId) {
                orderQuantities.set(orderId, Math.max(1, Number(item.quantity) || 1));
            }
        }
        const fbsItems = invoice.items.filter((item) => asDocumentRecord(item.charge?.metadata).kind === 'FBS');
        const orderIds = [
            ...new Set(fbsItems.flatMap((item) => documentStringArray(asDocumentRecord(item.charge?.metadata).orderIds))),
        ];
        if (fbsItems.length === 0 || orderIds.length === 0) {
            return finalizePrintableRows(basicRows, normalizeMergedRows);
        }
        const links = await this.prisma.fbsOrderRequestLink.findMany({
            where: { clientId: invoice.clientId, orderId: { in: orderIds } },
            select: {
                orderId: true,
                requestId: true,
                request: { select: { id: true, number: true } },
            },
        });
        const requestByOrder = new Map(links.map((link) => [
            link.orderId,
            { id: link.requestId, number: link.request.number },
        ]));
        const groups = new Map();
        const processedChargeIds = new Set();
        for (const item of fbsItems) {
            if (item.chargeId && processedChargeIds.has(item.chargeId)) {
                continue;
            }
            if (item.chargeId) {
                processedChargeIds.add(item.chargeId);
            }
            const itemOrderIds = documentStringArray(asDocumentRecord(item.charge?.metadata).orderIds);
            if (itemOrderIds.length === 0) {
                continue;
            }
            const allocations = allocateFbsAmountByRequest(Math.round(Number(item.totalRub) * 100), itemOrderIds, orderQuantities, requestByOrder);
            for (const allocation of allocations) {
                const current = groups.get(allocation.key) ?? {
                    requestNumber: allocation.requestNumber,
                    orderIds: new Set(),
                    totalCents: 0,
                    serviceDate: item.serviceDate.toISOString(),
                };
                allocation.orderIds.forEach((orderId) => current.orderIds.add(orderId));
                current.totalCents += allocation.cents;
                if (item.serviceDate.toISOString() < current.serviceDate) {
                    current.serviceDate = item.serviceDate.toISOString();
                }
                groups.set(allocation.key, current);
            }
        }
        const nonFbsRows = invoice.items
            .filter((item) => asDocumentRecord(item.charge?.metadata).kind !== 'FBS' &&
            !fbsOrderIdFromDescription(item.description))
            .map((item) => ({
            description: item.description,
            unit: item.unit,
            quantity: Number(item.quantity),
            unitPriceRub: Number(item.unitPriceRub),
            totalRub: Number(item.totalRub),
            serviceDate: item.serviceDate.toISOString(),
        }));
        const requestRows = [...groups.values()].map((group) => {
            const sortedOrderIds = [...group.orderIds].sort((left, right) => left.localeCompare(right, 'ru-RU', { numeric: true }));
            const quantity = Math.max(1, sortedOrderIds.length);
            const totalRub = group.totalCents / 100;
            const requestLabel = group.requestNumber === null
                ? 'FBS без заявки'
                : `Заявка №${group.requestNumber}`;
            return {
                description: `${requestLabel} (заказы: ${sortedOrderIds.map((orderId) => `№${orderId}`).join(', ')})`,
                unit: 'ORDER',
                quantity,
                unitPriceRub: roundMoney(totalRub / quantity),
                totalRub,
                serviceDate: group.serviceDate,
            };
        });
        return finalizePrintableRows([...requestRows, ...nonFbsRows], normalizeMergedRows);
    }
};
exports.BillingDocumentService = BillingDocumentService;
exports.BillingDocumentService = BillingDocumentService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        client_scope_service_1.ClientScopeService,
        own_companies_service_1.OwnCompaniesService])
], BillingDocumentService);
const invoiceDocumentInclude = {
    client: {
        select: {
            id: true,
            code: true,
            name: true,
            legalName: true,
            inn: true,
            kpp: true,
            ogrn: true,
            legalAddress: true,
            actualAddress: true,
            email: true,
            phone: true,
            bankName: true,
            bankBik: true,
            bankAccount: true,
            correspondentAccount: true,
        },
    },
    createdBy: {
        select: {
            id: true,
            email: true,
            name: true,
        },
    },
    items: {
        include: {
            charge: {
                select: {
                    id: true,
                    metadata: true,
                },
            },
        },
        orderBy: [{ serviceDate: 'asc' }, { id: 'asc' }],
    },
    payments: {
        orderBy: [{ paidAt: 'desc' }, { createdAt: 'desc' }],
    },
    request: {
        select: { warehouseId: true },
    },
};
function renderInvoiceHtml(document) {
    // Русский комментарий: HTML остается быстрым preview, а PDF строится отдельным сервисом из того же payload.
    return `<!doctype html>
<html lang="ru">
<head>
  <meta charset="utf-8" />
  <title>${escapeHtml(document.title)}</title>
  <style>
    body { color: #111827; font-family: Arial, sans-serif; margin: 32px; }
    h1 { font-size: 24px; margin: 0 0 8px; }
    h2 { font-size: 16px; margin: 24px 0 10px; }
    .muted { color: #64748b; }
    .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 18px; margin-top: 20px; }
    .box { border: 1px solid #d7dde5; border-radius: 6px; padding: 12px; }
    table { border-collapse: collapse; margin-top: 14px; width: 100%; }
    th, td { border-bottom: 1px solid #d7dde5; font-size: 13px; padding: 8px; text-align: left; vertical-align: top; }
    th { background: #f8fafc; color: #334155; text-transform: uppercase; }
    .right { text-align: right; }
    .total { font-size: 16px; font-weight: 700; }
    @media print { body { margin: 16mm; } button { display: none; } }
  </style>
</head>
<body>
  <h1>${escapeHtml(document.title)}</h1>
  <p class="muted">Статус: ${escapeHtml(document.statusLabel)} · период ${formatDate(document.periodFrom)} - ${formatDate(document.periodTo)}</p>
  <div class="grid">
    <section class="box">
      <strong>Клиент</strong>
      ${clientRequisitesHtml(document.client)}
    </section>
    <section class="box">
      <strong>Документ</strong>
      <p>Выставлен: ${formatDate(document.issuedAt)}</p>
      <p>Оплатить до: ${formatDate(document.dueDate)}</p>
      <p>Ответственный: ${escapeHtml(document.createdBy?.name ?? '-')}</p>
    </section>
  </div>
  <h2>Позиции</h2>
  <table>
    <thead>
      <tr>
        <th>№</th>
        <th>Услуга</th>
        <th>Дата</th>
        <th class="right">Кол-во</th>
        <th class="right">Цена</th>
        <th class="right">Сумма</th>
      </tr>
    </thead>
    <tbody>
      ${document.rows
        .map((row) => `<tr>
        <td>${row.position}</td>
        <td>${escapeHtml(row.description)}</td>
        <td>${formatDate(row.serviceDate)}</td>
        <td class="right">${formatNumber(row.quantity)}</td>
        <td class="right">${formatMoney(row.unitPriceRub)} ₽</td>
        <td class="right">${formatMoney(row.totalRub)} ₽</td>
      </tr>`)
        .join('')}
    </tbody>
  </table>
  <p class="right total">Итого: ${formatMoney(document.totalRub)} ₽</p>
  <p class="right">Оплачено: ${formatMoney(document.paidRub)} ₽</p>
  <p class="right">К оплате: ${formatMoney(document.remainingRub)} ₽</p>
  ${document.payments.length
        ? `<h2>Оплаты</h2>
  <table>
    <thead><tr><th>Дата</th><th>Способ</th><th>Номер</th><th class="right">Сумма</th></tr></thead>
    <tbody>${document.payments
            .map((payment) => `<tr>
      <td>${formatDate(payment.paidAt)}</td>
      <td>${escapeHtml(payment.method ?? '-')}</td>
      <td>${escapeHtml(payment.reference ?? '-')}</td>
      <td class="right">${formatMoney(payment.amountRub)} ₽</td>
    </tr>`)
            .join('')}</tbody>
  </table>`
        : ''}
</body>
</html>`;
}
function renderActHtml(document) {
    return `<!doctype html>
<html lang="ru">
<head>
  <meta charset="utf-8" />
  <title>${escapeHtml(document.title)}</title>
  <style>
    body { color: #111827; font-family: Arial, sans-serif; margin: 32px; }
    h1 { font-size: 24px; margin: 0 0 8px; }
    h2 { font-size: 16px; margin: 24px 0 10px; }
    .muted { color: #64748b; }
    .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 18px; margin-top: 20px; }
    .box { border: 1px solid #d7dde5; border-radius: 6px; padding: 12px; }
    table { border-collapse: collapse; margin-top: 14px; width: 100%; }
    th, td { border-bottom: 1px solid #d7dde5; font-size: 13px; padding: 8px; text-align: left; vertical-align: top; }
    th { background: #f8fafc; color: #334155; text-transform: uppercase; }
    .right { text-align: right; }
    .total { font-size: 16px; font-weight: 700; }
    .statement { line-height: 1.55; margin-top: 20px; }
    .signatures { display: grid; grid-template-columns: 1fr 1fr; gap: 28px; margin-top: 42px; }
    .signature-line { border-top: 1px solid #111827; margin-top: 42px; padding-top: 6px; }
    @media print { body { margin: 16mm; } button { display: none; } }
  </style>
</head>
<body>
  <h1>${escapeHtml(document.title)}</h1>
  <p class="muted">Основание: счет № ${escapeHtml(document.number)} · период ${formatDate(document.periodFrom)} - ${formatDate(document.periodTo)}</p>
  <div class="grid">
    <section class="box">
      <strong>Заказчик</strong>
      ${clientRequisitesHtml(document.client)}
    </section>
    <section class="box">
      <strong>Исполнитель</strong>
      <p>${escapeHtml(document.seller.fullName)}</p>
      <p>Дата акта: ${formatDate(document.issuedAt ?? new Date().toISOString())}</p>
      <p>Ответственный: ${escapeHtml(document.createdBy?.name ?? '-')}</p>
    </section>
  </div>
  <h2>Оказанные услуги</h2>
  <table>
    <thead>
      <tr>
        <th>№</th>
        <th>Услуга</th>
        <th>Дата</th>
        <th class="right">Кол-во</th>
        <th class="right">Цена</th>
        <th class="right">Сумма</th>
      </tr>
    </thead>
    <tbody>
      ${document.rows
        .map((row) => `<tr>
        <td>${row.position}</td>
        <td>${escapeHtml(row.description)}</td>
        <td>${formatDate(row.serviceDate)}</td>
        <td class="right">${formatNumber(row.quantity)}</td>
        <td class="right">${formatMoney(row.unitPriceRub)} руб.</td>
        <td class="right">${formatMoney(row.totalRub)} руб.</td>
      </tr>`)
        .join('')}
    </tbody>
  </table>
  <p class="right total">Итого оказано услуг на сумму: ${formatMoney(document.totalRub)} руб.</p>
  <p class="statement">Услуги оказаны в полном объеме за указанный период. Стороны подтверждают состав и стоимость услуг по настоящему акту.</p>
  <div class="signatures">
    <section>
      <strong>Исполнитель</strong>
      <div class="signature-line">Подпись / расшифровка</div>
    </section>
    <section>
      <strong>Заказчик</strong>
      <div class="signature-line">Подпись / расшифровка</div>
    </section>
  </div>
</body>
</html>`;
}
function invoiceStatusLabel(status) {
    const labels = {
        DRAFT: 'Черновик',
        ISSUED: 'Выставлен',
        PAID: 'Оплачен',
        CANCELLED: 'Отменен',
    };
    return labels[status];
}
function clientRequisitesHtml(client) {
    return [
        `<p>${escapeHtml(client.legalName || client.name)} (${escapeHtml(client.code)})</p>`,
        `<p>${escapeHtml(taxLine(client))}</p>`,
        client.legalAddress ? `<p>Юр. адрес: ${escapeHtml(client.legalAddress)}</p>` : '',
        client.actualAddress ? `<p>Факт. адрес: ${escapeHtml(client.actualAddress)}</p>` : '',
        client.phone || client.email ? `<p>${escapeHtml(contactLine(client))}</p>` : '',
        client.bankName ? `<p>Банк: ${escapeHtml(client.bankName)}</p>` : '',
        bankAccountLine(client) ? `<p>${escapeHtml(bankAccountLine(client))}</p>` : '',
    ]
        .filter(Boolean)
        .join('');
}
function taxLine(client) {
    return [`ИНН: ${client.inn ?? '-'}`, `КПП: ${client.kpp ?? '-'}`, client.ogrn ? `ОГРН: ${client.ogrn}` : '']
        .filter(Boolean)
        .join(' · ');
}
function contactLine(client) {
    return [`Телефон: ${client.phone ?? '-'}`, `Почта: ${client.email ?? '-'}`].join(' · ');
}
function bankAccountLine(client) {
    return [
        client.bankBik ? `БИК: ${client.bankBik}` : '',
        client.bankAccount ? `Р/с: ${client.bankAccount}` : '',
        client.correspondentAccount ? `К/с: ${client.correspondentAccount}` : '',
    ]
        .filter(Boolean)
        .join(' · ');
}
function escapeHtml(value) {
    return String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
}
function formatDate(value) {
    if (!value) {
        return '-';
    }
    return new Intl.DateTimeFormat('ru-RU').format(new Date(value));
}
function formatMoney(value) {
    return new Intl.NumberFormat('ru-RU', { maximumFractionDigits: 2, minimumFractionDigits: 2 }).format(value);
}
function formatNumber(value) {
    return new Intl.NumberFormat('ru-RU', { maximumFractionDigits: 3 }).format(value);
}
function roundMoney(value) {
    return Math.round((value + Number.EPSILON) * 100) / 100;
}
function positionPrintableRows(rows) {
    return rows
        .sort((left, right) => left.serviceDate.localeCompare(right.serviceDate) ||
        left.description.localeCompare(right.description, 'ru-RU', { numeric: true }))
        .map((row, index) => ({ ...row, position: index + 1 }));
}
function finalizePrintableRows(rows, normalizeMergedRows) {
    // FIX: consolidate equal services in every invoice/act, not only manually merged invoices.
    // Keep the existing merged-invoice zero-row policy; stored items and amounts remain untouched.
    const grouped = new Map();
    for (const row of rows) {
        const totalRub = roundMoney(row.totalRub);
        if (normalizeMergedRows && totalRub === 0) {
            continue;
        }
        const description = row.description.trim().replace(/\s+/g, ' ');
        const unitPriceRub = roundMoney(row.unitPriceRub);
        const key = [
            description.toLocaleLowerCase('ru-RU'),
            row.unit,
            unitPriceRub.toFixed(2),
        ].join('|');
        const existing = grouped.get(key);
        if (!existing) {
            grouped.set(key, {
                ...row,
                description,
                quantity: roundQuantity(row.quantity),
                unitPriceRub,
                totalRub,
            });
            continue;
        }
        existing.quantity = roundQuantity(existing.quantity + row.quantity);
        existing.totalRub = roundMoney(existing.totalRub + totalRub);
        if (row.serviceDate < existing.serviceDate) {
            existing.serviceDate = row.serviceDate;
        }
    }
    return positionPrintableRows([...grouped.values()]);
}
function isMergedInvoiceSourceKey(sourceKey) {
    return sourceKey?.startsWith('invoice-merged:') === true || sourceKey?.startsWith('fbs-merged:') === true;
}
function roundQuantity(value) {
    return Math.round((value + Number.EPSILON) * 1000) / 1000;
}
function fbsOrderIdFromDescription(description) {
    const match = description.trim().match(/^FBS-заказ №(.+)$/u);
    return match?.[1]?.trim() || null;
}
function allocateFbsAmountByRequest(totalCents, orderIds, orderQuantities, requestByOrder) {
    const grouped = new Map();
    for (const orderId of [...new Set(orderIds)]) {
        const request = requestByOrder.get(orderId);
        const key = request ? `request:${request.id}` : 'request:unlinked';
        const current = grouped.get(key) ?? {
            key,
            requestNumber: request?.number ?? null,
            orderIds: [],
            weight: 0,
        };
        current.orderIds.push(orderId);
        current.weight += Math.max(1, orderQuantities.get(orderId) ?? 1);
        grouped.set(key, current);
    }
    const rows = [...grouped.values()];
    const totalWeight = rows.reduce((sum, row) => sum + row.weight, 0) || rows.length;
    const shares = rows.map((row) => {
        const exact = (totalCents * row.weight) / totalWeight;
        const cents = Math.floor(exact);
        return { ...row, cents, remainder: exact - cents };
    });
    let undistributed = totalCents - shares.reduce((sum, row) => sum + row.cents, 0);
    for (const row of [...shares].sort((left, right) => right.remainder - left.remainder)) {
        if (undistributed <= 0)
            break;
        row.cents += 1;
        undistributed -= 1;
    }
    return shares;
}
function asDocumentRecord(value) {
    return value && typeof value === 'object' && !Array.isArray(value)
        ? value
        : {};
}
function documentStringArray(value) {
    if (!Array.isArray(value)) {
        return [];
    }
    return [
        ...new Set(value
            .filter((item) => typeof item === 'string')
            .map((item) => item.trim())
            .filter(Boolean)),
    ];
}
function canForceAct(user) {
    return (user.permissionCodes.includes('system:admin') ||
        user.permissionCodes.includes('billing:write') ||
        user.roleCodes.includes('ADMIN') ||
        user.roleCodes.includes('OWNER'));
}
function actNumberForInvoice(invoiceNumber) {
    return invoiceNumber.startsWith('INV-') ? `ACT-${invoiceNumber.slice(4)}` : `ACT-${invoiceNumber}`;
}
function safeFileName(value) {
    return value.replace(/[^a-zA-Z0-9а-яА-ЯёЁ._-]+/g, '_');
}
