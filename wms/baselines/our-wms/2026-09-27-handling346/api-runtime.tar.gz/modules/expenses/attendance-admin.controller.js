"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var _a, _b, _c;
Object.defineProperty(exports, "__esModule", { value: true });
exports.AttendanceAdminController = void 0;
const common_1 = require("@nestjs/common");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const require_permissions_decorator_1 = require("../auth/decorators/require-permissions.decorator");
const attendance_device_service_1 = require("./attendance-device.service");
const payroll_service_1 = require("./payroll.service");
// FIX: Administrative endpoints retain WMS permissions and branch scope.
let AttendanceAdminController = class AttendanceAdminController {
    service;
    constructor(service) {
        this.service = service;
    }
    capabilities(user) { (0, payroll_service_1.payrollWarehouses)(user); return { enabled: this.service.enabled() }; }
    devices(user) { return this.service.devices(user); }
    code(user, body) { return this.service.issue(user, body.warehouseId); }
    revoke(user, id) { return this.service.revoke(user, id); }
    events(user, employeeId, from, to) { return this.service.events(user, employeeId, from, to); }
    resolve(user, id, body) { return this.service.resolve(user, id, body); }
    requestPhoto(user, id) { return this.service.requestPhoto(user, id); }
    async photo(user, id, response) {
        const bytes = await this.service.photo(user, id);
        response.setHeader('Content-Type', 'image/jpeg');
        response.setHeader('Cache-Control', 'no-store');
        response.setHeader('X-Content-Type-Options', 'nosniff');
        return new common_1.StreamableFile(bytes);
    }
};
exports.AttendanceAdminController = AttendanceAdminController;
__decorate([
    (0, common_1.Get)('capabilities'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], AttendanceAdminController.prototype, "capabilities", null);
__decorate([
    (0, common_1.Get)('devices'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], AttendanceAdminController.prototype, "devices", null);
__decorate([
    (0, common_1.Post)('codes'),
    (0, require_permissions_decorator_1.RequirePermissions)('expenses:write'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, typeof (_b = typeof Record !== "undefined" && Record) === "function" ? _b : Object]),
    __metadata("design:returntype", void 0)
], AttendanceAdminController.prototype, "code", null);
__decorate([
    (0, common_1.Post)('devices/:id/revoke'),
    (0, require_permissions_decorator_1.RequirePermissions)('expenses:write'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", void 0)
], AttendanceAdminController.prototype, "revoke", null);
__decorate([
    (0, common_1.Get)('events'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)('employeeId')),
    __param(2, (0, common_1.Query)('from')),
    __param(3, (0, common_1.Query)('to')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, String, String]),
    __metadata("design:returntype", void 0)
], AttendanceAdminController.prototype, "events", null);
__decorate([
    (0, common_1.Post)('events/:id/resolve'),
    (0, require_permissions_decorator_1.RequirePermissions)('expenses:write'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Param)('id')),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, typeof (_c = typeof Record !== "undefined" && Record) === "function" ? _c : Object]),
    __metadata("design:returntype", void 0)
], AttendanceAdminController.prototype, "resolve", null);
__decorate([
    (0, common_1.Post)('events/:id/photo'),
    (0, require_permissions_decorator_1.RequirePermissions)('expenses:write'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", void 0)
], AttendanceAdminController.prototype, "requestPhoto", null);
__decorate([
    (0, common_1.Get)('events/:id/photo'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Param)('id')),
    __param(2, (0, common_1.Res)({ passthrough: true })),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, Object]),
    __metadata("design:returntype", Promise)
], AttendanceAdminController.prototype, "photo", null);
exports.AttendanceAdminController = AttendanceAdminController = __decorate([
    (0, common_1.Controller)('expenses/workforce/attendance'),
    (0, require_permissions_decorator_1.RequirePermissions)('expenses:read'),
    __metadata("design:paramtypes", [typeof (_a = typeof attendance_device_service_1.AttendanceDeviceService !== "undefined" && attendance_device_service_1.AttendanceDeviceService) === "function" ? _a : Object])
], AttendanceAdminController);
