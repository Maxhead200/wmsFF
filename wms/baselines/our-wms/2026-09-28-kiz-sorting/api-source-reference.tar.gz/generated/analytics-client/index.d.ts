
/**
 * Client
**/

import * as runtime from './runtime/library.js';
import $Types = runtime.Types // general types
import $Public = runtime.Types.Public
import $Utils = runtime.Types.Utils
import $Extensions = runtime.Types.Extensions
import $Result = runtime.Types.Result

export type PrismaPromise<T> = $Public.PrismaPromise<T>


/**
 * Model AnalyticsConnection
 * 
 */
export type AnalyticsConnection = $Result.DefaultSelection<Prisma.$AnalyticsConnectionPayload>
/**
 * Model AnalyticsSyncState
 * 
 */
export type AnalyticsSyncState = $Result.DefaultSelection<Prisma.$AnalyticsSyncStatePayload>
/**
 * Model AnalyticsProduct
 * 
 */
export type AnalyticsProduct = $Result.DefaultSelection<Prisma.$AnalyticsProductPayload>
/**
 * Model AnalyticsRegion
 * 
 */
export type AnalyticsRegion = $Result.DefaultSelection<Prisma.$AnalyticsRegionPayload>
/**
 * Model AnalyticsDailySummary
 * 
 */
export type AnalyticsDailySummary = $Result.DefaultSelection<Prisma.$AnalyticsDailySummaryPayload>

/**
 * ##  Prisma Client ʲˢ
 *
 * Type-safe database client for TypeScript & Node.js
 * @example
 * ```
 * const prisma = new PrismaClient()
 * // Fetch zero or more AnalyticsConnections
 * const analyticsConnections = await prisma.analyticsConnection.findMany()
 * ```
 *
 *
 * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client).
 */
export class PrismaClient<
  ClientOptions extends Prisma.PrismaClientOptions = Prisma.PrismaClientOptions,
  const U = 'log' extends keyof ClientOptions ? ClientOptions['log'] extends Array<Prisma.LogLevel | Prisma.LogDefinition> ? Prisma.GetEvents<ClientOptions['log']> : never : never,
  ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs
> {
  [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['other'] }

    /**
   * ##  Prisma Client ʲˢ
   *
   * Type-safe database client for TypeScript & Node.js
   * @example
   * ```
   * const prisma = new PrismaClient()
   * // Fetch zero or more AnalyticsConnections
   * const analyticsConnections = await prisma.analyticsConnection.findMany()
   * ```
   *
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client).
   */

  constructor(optionsArg ?: Prisma.Subset<ClientOptions, Prisma.PrismaClientOptions>);
  $on<V extends U>(eventType: V, callback: (event: V extends 'query' ? Prisma.QueryEvent : Prisma.LogEvent) => void): PrismaClient;

  /**
   * Connect with the database
   */
  $connect(): $Utils.JsPromise<void>;

  /**
   * Disconnect from the database
   */
  $disconnect(): $Utils.JsPromise<void>;

/**
   * Executes a prepared raw query and returns the number of affected rows.
   * @example
   * ```
   * const result = await prisma.$executeRaw`UPDATE User SET cool = ${true} WHERE email = ${'user@email.com'};`
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $executeRaw<T = unknown>(query: TemplateStringsArray | Prisma.Sql, ...values: any[]): Prisma.PrismaPromise<number>;

  /**
   * Executes a raw query and returns the number of affected rows.
   * Susceptible to SQL injections, see documentation.
   * @example
   * ```
   * const result = await prisma.$executeRawUnsafe('UPDATE User SET cool = $1 WHERE email = $2 ;', true, 'user@email.com')
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $executeRawUnsafe<T = unknown>(query: string, ...values: any[]): Prisma.PrismaPromise<number>;

  /**
   * Performs a prepared raw query and returns the `SELECT` data.
   * @example
   * ```
   * const result = await prisma.$queryRaw`SELECT * FROM User WHERE id = ${1} OR email = ${'user@email.com'};`
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $queryRaw<T = unknown>(query: TemplateStringsArray | Prisma.Sql, ...values: any[]): Prisma.PrismaPromise<T>;

  /**
   * Performs a raw query and returns the `SELECT` data.
   * Susceptible to SQL injections, see documentation.
   * @example
   * ```
   * const result = await prisma.$queryRawUnsafe('SELECT * FROM User WHERE id = $1 OR email = $2;', 1, 'user@email.com')
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $queryRawUnsafe<T = unknown>(query: string, ...values: any[]): Prisma.PrismaPromise<T>;


  /**
   * Allows the running of a sequence of read/write operations that are guaranteed to either succeed or fail as a whole.
   * @example
   * ```
   * const [george, bob, alice] = await prisma.$transaction([
   *   prisma.user.create({ data: { name: 'George' } }),
   *   prisma.user.create({ data: { name: 'Bob' } }),
   *   prisma.user.create({ data: { name: 'Alice' } }),
   * ])
   * ```
   * 
   * Read more in our [docs](https://www.prisma.io/docs/concepts/components/prisma-client/transactions).
   */
  $transaction<P extends Prisma.PrismaPromise<any>[]>(arg: [...P], options?: { isolationLevel?: Prisma.TransactionIsolationLevel }): $Utils.JsPromise<runtime.Types.Utils.UnwrapTuple<P>>

  $transaction<R>(fn: (prisma: Omit<PrismaClient, runtime.ITXClientDenyList>) => $Utils.JsPromise<R>, options?: { maxWait?: number, timeout?: number, isolationLevel?: Prisma.TransactionIsolationLevel }): $Utils.JsPromise<R>


  $extends: $Extensions.ExtendsHook<"extends", Prisma.TypeMapCb<ClientOptions>, ExtArgs, $Utils.Call<Prisma.TypeMapCb<ClientOptions>, {
    extArgs: ExtArgs
  }>>

      /**
   * `prisma.analyticsConnection`: Exposes CRUD operations for the **AnalyticsConnection** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more AnalyticsConnections
    * const analyticsConnections = await prisma.analyticsConnection.findMany()
    * ```
    */
  get analyticsConnection(): Prisma.AnalyticsConnectionDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.analyticsSyncState`: Exposes CRUD operations for the **AnalyticsSyncState** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more AnalyticsSyncStates
    * const analyticsSyncStates = await prisma.analyticsSyncState.findMany()
    * ```
    */
  get analyticsSyncState(): Prisma.AnalyticsSyncStateDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.analyticsProduct`: Exposes CRUD operations for the **AnalyticsProduct** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more AnalyticsProducts
    * const analyticsProducts = await prisma.analyticsProduct.findMany()
    * ```
    */
  get analyticsProduct(): Prisma.AnalyticsProductDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.analyticsRegion`: Exposes CRUD operations for the **AnalyticsRegion** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more AnalyticsRegions
    * const analyticsRegions = await prisma.analyticsRegion.findMany()
    * ```
    */
  get analyticsRegion(): Prisma.AnalyticsRegionDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.analyticsDailySummary`: Exposes CRUD operations for the **AnalyticsDailySummary** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more AnalyticsDailySummaries
    * const analyticsDailySummaries = await prisma.analyticsDailySummary.findMany()
    * ```
    */
  get analyticsDailySummary(): Prisma.AnalyticsDailySummaryDelegate<ExtArgs, ClientOptions>;
}

export namespace Prisma {
  export import DMMF = runtime.DMMF

  export type PrismaPromise<T> = $Public.PrismaPromise<T>

  /**
   * Validator
   */
  export import validator = runtime.Public.validator

  /**
   * Prisma Errors
   */
  export import PrismaClientKnownRequestError = runtime.PrismaClientKnownRequestError
  export import PrismaClientUnknownRequestError = runtime.PrismaClientUnknownRequestError
  export import PrismaClientRustPanicError = runtime.PrismaClientRustPanicError
  export import PrismaClientInitializationError = runtime.PrismaClientInitializationError
  export import PrismaClientValidationError = runtime.PrismaClientValidationError

  /**
   * Re-export of sql-template-tag
   */
  export import sql = runtime.sqltag
  export import empty = runtime.empty
  export import join = runtime.join
  export import raw = runtime.raw
  export import Sql = runtime.Sql



  /**
   * Decimal.js
   */
  export import Decimal = runtime.Decimal

  export type DecimalJsLike = runtime.DecimalJsLike

  /**
   * Metrics
   */
  export type Metrics = runtime.Metrics
  export type Metric<T> = runtime.Metric<T>
  export type MetricHistogram = runtime.MetricHistogram
  export type MetricHistogramBucket = runtime.MetricHistogramBucket

  /**
  * Extensions
  */
  export import Extension = $Extensions.UserArgs
  export import getExtensionContext = runtime.Extensions.getExtensionContext
  export import Args = $Public.Args
  export import Payload = $Public.Payload
  export import Result = $Public.Result
  export import Exact = $Public.Exact

  /**
   * Prisma Client JS version: 6.19.3
   * Query Engine version: c2990dca591cba766e3b7ef5d9e8a84796e47ab7
   */
  export type PrismaVersion = {
    client: string
  }

  export const prismaVersion: PrismaVersion

  /**
   * Utility Types
   */


  export import Bytes = runtime.Bytes
  export import JsonObject = runtime.JsonObject
  export import JsonArray = runtime.JsonArray
  export import JsonValue = runtime.JsonValue
  export import InputJsonObject = runtime.InputJsonObject
  export import InputJsonArray = runtime.InputJsonArray
  export import InputJsonValue = runtime.InputJsonValue

  /**
   * Types of the values used to represent different kinds of `null` values when working with JSON fields.
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  namespace NullTypes {
    /**
    * Type of `Prisma.DbNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.DbNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class DbNull {
      private DbNull: never
      private constructor()
    }

    /**
    * Type of `Prisma.JsonNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.JsonNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class JsonNull {
      private JsonNull: never
      private constructor()
    }

    /**
    * Type of `Prisma.AnyNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.AnyNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class AnyNull {
      private AnyNull: never
      private constructor()
    }
  }

  /**
   * Helper for filtering JSON entries that have `null` on the database (empty on the db)
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const DbNull: NullTypes.DbNull

  /**
   * Helper for filtering JSON entries that have JSON `null` values (not empty on the db)
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const JsonNull: NullTypes.JsonNull

  /**
   * Helper for filtering JSON entries that are `Prisma.DbNull` or `Prisma.JsonNull`
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const AnyNull: NullTypes.AnyNull

  type SelectAndInclude = {
    select: any
    include: any
  }

  type SelectAndOmit = {
    select: any
    omit: any
  }

  /**
   * Get the type of the value, that the Promise holds.
   */
  export type PromiseType<T extends PromiseLike<any>> = T extends PromiseLike<infer U> ? U : T;

  /**
   * Get the return type of a function which returns a Promise.
   */
  export type PromiseReturnType<T extends (...args: any) => $Utils.JsPromise<any>> = PromiseType<ReturnType<T>>

  /**
   * From T, pick a set of properties whose keys are in the union K
   */
  type Prisma__Pick<T, K extends keyof T> = {
      [P in K]: T[P];
  };


  export type Enumerable<T> = T | Array<T>;

  export type RequiredKeys<T> = {
    [K in keyof T]-?: {} extends Prisma__Pick<T, K> ? never : K
  }[keyof T]

  export type TruthyKeys<T> = keyof {
    [K in keyof T as T[K] extends false | undefined | null ? never : K]: K
  }

  export type TrueKeys<T> = TruthyKeys<Prisma__Pick<T, RequiredKeys<T>>>

  /**
   * Subset
   * @desc From `T` pick properties that exist in `U`. Simple version of Intersection
   */
  export type Subset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never;
  };

  /**
   * SelectSubset
   * @desc From `T` pick properties that exist in `U`. Simple version of Intersection.
   * Additionally, it validates, if both select and include are present. If the case, it errors.
   */
  export type SelectSubset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never
  } &
    (T extends SelectAndInclude
      ? 'Please either choose `select` or `include`.'
      : T extends SelectAndOmit
        ? 'Please either choose `select` or `omit`.'
        : {})

  /**
   * Subset + Intersection
   * @desc From `T` pick properties that exist in `U` and intersect `K`
   */
  export type SubsetIntersection<T, U, K> = {
    [key in keyof T]: key extends keyof U ? T[key] : never
  } &
    K

  type Without<T, U> = { [P in Exclude<keyof T, keyof U>]?: never };

  /**
   * XOR is needed to have a real mutually exclusive union type
   * https://stackoverflow.com/questions/42123407/does-typescript-support-mutually-exclusive-types
   */
  type XOR<T, U> =
    T extends object ?
    U extends object ?
      (Without<T, U> & U) | (Without<U, T> & T)
    : U : T


  /**
   * Is T a Record?
   */
  type IsObject<T extends any> = T extends Array<any>
  ? False
  : T extends Date
  ? False
  : T extends Uint8Array
  ? False
  : T extends BigInt
  ? False
  : T extends object
  ? True
  : False


  /**
   * If it's T[], return T
   */
  export type UnEnumerate<T extends unknown> = T extends Array<infer U> ? U : T

  /**
   * From ts-toolbelt
   */

  type __Either<O extends object, K extends Key> = Omit<O, K> &
    {
      // Merge all but K
      [P in K]: Prisma__Pick<O, P & keyof O> // With K possibilities
    }[K]

  type EitherStrict<O extends object, K extends Key> = Strict<__Either<O, K>>

  type EitherLoose<O extends object, K extends Key> = ComputeRaw<__Either<O, K>>

  type _Either<
    O extends object,
    K extends Key,
    strict extends Boolean
  > = {
    1: EitherStrict<O, K>
    0: EitherLoose<O, K>
  }[strict]

  type Either<
    O extends object,
    K extends Key,
    strict extends Boolean = 1
  > = O extends unknown ? _Either<O, K, strict> : never

  export type Union = any

  type PatchUndefined<O extends object, O1 extends object> = {
    [K in keyof O]: O[K] extends undefined ? At<O1, K> : O[K]
  } & {}

  /** Helper Types for "Merge" **/
  export type IntersectOf<U extends Union> = (
    U extends unknown ? (k: U) => void : never
  ) extends (k: infer I) => void
    ? I
    : never

  export type Overwrite<O extends object, O1 extends object> = {
      [K in keyof O]: K extends keyof O1 ? O1[K] : O[K];
  } & {};

  type _Merge<U extends object> = IntersectOf<Overwrite<U, {
      [K in keyof U]-?: At<U, K>;
  }>>;

  type Key = string | number | symbol;
  type AtBasic<O extends object, K extends Key> = K extends keyof O ? O[K] : never;
  type AtStrict<O extends object, K extends Key> = O[K & keyof O];
  type AtLoose<O extends object, K extends Key> = O extends unknown ? AtStrict<O, K> : never;
  export type At<O extends object, K extends Key, strict extends Boolean = 1> = {
      1: AtStrict<O, K>;
      0: AtLoose<O, K>;
  }[strict];

  export type ComputeRaw<A extends any> = A extends Function ? A : {
    [K in keyof A]: A[K];
  } & {};

  export type OptionalFlat<O> = {
    [K in keyof O]?: O[K];
  } & {};

  type _Record<K extends keyof any, T> = {
    [P in K]: T;
  };

  // cause typescript not to expand types and preserve names
  type NoExpand<T> = T extends unknown ? T : never;

  // this type assumes the passed object is entirely optional
  type AtLeast<O extends object, K extends string> = NoExpand<
    O extends unknown
    ? | (K extends keyof O ? { [P in K]: O[P] } & O : O)
      | {[P in keyof O as P extends K ? P : never]-?: O[P]} & O
    : never>;

  type _Strict<U, _U = U> = U extends unknown ? U & OptionalFlat<_Record<Exclude<Keys<_U>, keyof U>, never>> : never;

  export type Strict<U extends object> = ComputeRaw<_Strict<U>>;
  /** End Helper Types for "Merge" **/

  export type Merge<U extends object> = ComputeRaw<_Merge<Strict<U>>>;

  /**
  A [[Boolean]]
  */
  export type Boolean = True | False

  // /**
  // 1
  // */
  export type True = 1

  /**
  0
  */
  export type False = 0

  export type Not<B extends Boolean> = {
    0: 1
    1: 0
  }[B]

  export type Extends<A1 extends any, A2 extends any> = [A1] extends [never]
    ? 0 // anything `never` is false
    : A1 extends A2
    ? 1
    : 0

  export type Has<U extends Union, U1 extends Union> = Not<
    Extends<Exclude<U1, U>, U1>
  >

  export type Or<B1 extends Boolean, B2 extends Boolean> = {
    0: {
      0: 0
      1: 1
    }
    1: {
      0: 1
      1: 1
    }
  }[B1][B2]

  export type Keys<U extends Union> = U extends unknown ? keyof U : never

  type Cast<A, B> = A extends B ? A : B;

  export const type: unique symbol;



  /**
   * Used by group by
   */

  export type GetScalarType<T, O> = O extends object ? {
    [P in keyof T]: P extends keyof O
      ? O[P]
      : never
  } : never

  type FieldPaths<
    T,
    U = Omit<T, '_avg' | '_sum' | '_count' | '_min' | '_max'>
  > = IsObject<T> extends True ? U : T

  type GetHavingFields<T> = {
    [K in keyof T]: Or<
      Or<Extends<'OR', K>, Extends<'AND', K>>,
      Extends<'NOT', K>
    > extends True
      ? // infer is only needed to not hit TS limit
        // based on the brilliant idea of Pierre-Antoine Mills
        // https://github.com/microsoft/TypeScript/issues/30188#issuecomment-478938437
        T[K] extends infer TK
        ? GetHavingFields<UnEnumerate<TK> extends object ? Merge<UnEnumerate<TK>> : never>
        : never
      : {} extends FieldPaths<T[K]>
      ? never
      : K
  }[keyof T]

  /**
   * Convert tuple to union
   */
  type _TupleToUnion<T> = T extends (infer E)[] ? E : never
  type TupleToUnion<K extends readonly any[]> = _TupleToUnion<K>
  type MaybeTupleToUnion<T> = T extends any[] ? TupleToUnion<T> : T

  /**
   * Like `Pick`, but additionally can also accept an array of keys
   */
  type PickEnumerable<T, K extends Enumerable<keyof T> | keyof T> = Prisma__Pick<T, MaybeTupleToUnion<K>>

  /**
   * Exclude all keys with underscores
   */
  type ExcludeUnderscoreKeys<T extends string> = T extends `_${string}` ? never : T


  export type FieldRef<Model, FieldType> = runtime.FieldRef<Model, FieldType>

  type FieldRefInputType<Model, FieldType> = Model extends never ? never : FieldRef<Model, FieldType>


  export const ModelName: {
    AnalyticsConnection: 'AnalyticsConnection',
    AnalyticsSyncState: 'AnalyticsSyncState',
    AnalyticsProduct: 'AnalyticsProduct',
    AnalyticsRegion: 'AnalyticsRegion',
    AnalyticsDailySummary: 'AnalyticsDailySummary'
  };

  export type ModelName = (typeof ModelName)[keyof typeof ModelName]


  export type Datasources = {
    db?: Datasource
  }

  interface TypeMapCb<ClientOptions = {}> extends $Utils.Fn<{extArgs: $Extensions.InternalArgs }, $Utils.Record<string, any>> {
    returns: Prisma.TypeMap<this['params']['extArgs'], ClientOptions extends { omit: infer OmitOptions } ? OmitOptions : {}>
  }

  export type TypeMap<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> = {
    globalOmitOptions: {
      omit: GlobalOmitOptions
    }
    meta: {
      modelProps: "analyticsConnection" | "analyticsSyncState" | "analyticsProduct" | "analyticsRegion" | "analyticsDailySummary"
      txIsolationLevel: Prisma.TransactionIsolationLevel
    }
    model: {
      AnalyticsConnection: {
        payload: Prisma.$AnalyticsConnectionPayload<ExtArgs>
        fields: Prisma.AnalyticsConnectionFieldRefs
        operations: {
          findUnique: {
            args: Prisma.AnalyticsConnectionFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AnalyticsConnectionPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.AnalyticsConnectionFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AnalyticsConnectionPayload>
          }
          findFirst: {
            args: Prisma.AnalyticsConnectionFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AnalyticsConnectionPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.AnalyticsConnectionFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AnalyticsConnectionPayload>
          }
          findMany: {
            args: Prisma.AnalyticsConnectionFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AnalyticsConnectionPayload>[]
          }
          create: {
            args: Prisma.AnalyticsConnectionCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AnalyticsConnectionPayload>
          }
          createMany: {
            args: Prisma.AnalyticsConnectionCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.AnalyticsConnectionCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AnalyticsConnectionPayload>[]
          }
          delete: {
            args: Prisma.AnalyticsConnectionDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AnalyticsConnectionPayload>
          }
          update: {
            args: Prisma.AnalyticsConnectionUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AnalyticsConnectionPayload>
          }
          deleteMany: {
            args: Prisma.AnalyticsConnectionDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.AnalyticsConnectionUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.AnalyticsConnectionUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AnalyticsConnectionPayload>[]
          }
          upsert: {
            args: Prisma.AnalyticsConnectionUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AnalyticsConnectionPayload>
          }
          aggregate: {
            args: Prisma.AnalyticsConnectionAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateAnalyticsConnection>
          }
          groupBy: {
            args: Prisma.AnalyticsConnectionGroupByArgs<ExtArgs>
            result: $Utils.Optional<AnalyticsConnectionGroupByOutputType>[]
          }
          count: {
            args: Prisma.AnalyticsConnectionCountArgs<ExtArgs>
            result: $Utils.Optional<AnalyticsConnectionCountAggregateOutputType> | number
          }
        }
      }
      AnalyticsSyncState: {
        payload: Prisma.$AnalyticsSyncStatePayload<ExtArgs>
        fields: Prisma.AnalyticsSyncStateFieldRefs
        operations: {
          findUnique: {
            args: Prisma.AnalyticsSyncStateFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AnalyticsSyncStatePayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.AnalyticsSyncStateFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AnalyticsSyncStatePayload>
          }
          findFirst: {
            args: Prisma.AnalyticsSyncStateFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AnalyticsSyncStatePayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.AnalyticsSyncStateFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AnalyticsSyncStatePayload>
          }
          findMany: {
            args: Prisma.AnalyticsSyncStateFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AnalyticsSyncStatePayload>[]
          }
          create: {
            args: Prisma.AnalyticsSyncStateCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AnalyticsSyncStatePayload>
          }
          createMany: {
            args: Prisma.AnalyticsSyncStateCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.AnalyticsSyncStateCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AnalyticsSyncStatePayload>[]
          }
          delete: {
            args: Prisma.AnalyticsSyncStateDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AnalyticsSyncStatePayload>
          }
          update: {
            args: Prisma.AnalyticsSyncStateUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AnalyticsSyncStatePayload>
          }
          deleteMany: {
            args: Prisma.AnalyticsSyncStateDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.AnalyticsSyncStateUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.AnalyticsSyncStateUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AnalyticsSyncStatePayload>[]
          }
          upsert: {
            args: Prisma.AnalyticsSyncStateUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AnalyticsSyncStatePayload>
          }
          aggregate: {
            args: Prisma.AnalyticsSyncStateAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateAnalyticsSyncState>
          }
          groupBy: {
            args: Prisma.AnalyticsSyncStateGroupByArgs<ExtArgs>
            result: $Utils.Optional<AnalyticsSyncStateGroupByOutputType>[]
          }
          count: {
            args: Prisma.AnalyticsSyncStateCountArgs<ExtArgs>
            result: $Utils.Optional<AnalyticsSyncStateCountAggregateOutputType> | number
          }
        }
      }
      AnalyticsProduct: {
        payload: Prisma.$AnalyticsProductPayload<ExtArgs>
        fields: Prisma.AnalyticsProductFieldRefs
        operations: {
          findUnique: {
            args: Prisma.AnalyticsProductFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AnalyticsProductPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.AnalyticsProductFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AnalyticsProductPayload>
          }
          findFirst: {
            args: Prisma.AnalyticsProductFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AnalyticsProductPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.AnalyticsProductFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AnalyticsProductPayload>
          }
          findMany: {
            args: Prisma.AnalyticsProductFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AnalyticsProductPayload>[]
          }
          create: {
            args: Prisma.AnalyticsProductCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AnalyticsProductPayload>
          }
          createMany: {
            args: Prisma.AnalyticsProductCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.AnalyticsProductCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AnalyticsProductPayload>[]
          }
          delete: {
            args: Prisma.AnalyticsProductDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AnalyticsProductPayload>
          }
          update: {
            args: Prisma.AnalyticsProductUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AnalyticsProductPayload>
          }
          deleteMany: {
            args: Prisma.AnalyticsProductDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.AnalyticsProductUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.AnalyticsProductUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AnalyticsProductPayload>[]
          }
          upsert: {
            args: Prisma.AnalyticsProductUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AnalyticsProductPayload>
          }
          aggregate: {
            args: Prisma.AnalyticsProductAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateAnalyticsProduct>
          }
          groupBy: {
            args: Prisma.AnalyticsProductGroupByArgs<ExtArgs>
            result: $Utils.Optional<AnalyticsProductGroupByOutputType>[]
          }
          count: {
            args: Prisma.AnalyticsProductCountArgs<ExtArgs>
            result: $Utils.Optional<AnalyticsProductCountAggregateOutputType> | number
          }
        }
      }
      AnalyticsRegion: {
        payload: Prisma.$AnalyticsRegionPayload<ExtArgs>
        fields: Prisma.AnalyticsRegionFieldRefs
        operations: {
          findUnique: {
            args: Prisma.AnalyticsRegionFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AnalyticsRegionPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.AnalyticsRegionFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AnalyticsRegionPayload>
          }
          findFirst: {
            args: Prisma.AnalyticsRegionFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AnalyticsRegionPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.AnalyticsRegionFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AnalyticsRegionPayload>
          }
          findMany: {
            args: Prisma.AnalyticsRegionFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AnalyticsRegionPayload>[]
          }
          create: {
            args: Prisma.AnalyticsRegionCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AnalyticsRegionPayload>
          }
          createMany: {
            args: Prisma.AnalyticsRegionCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.AnalyticsRegionCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AnalyticsRegionPayload>[]
          }
          delete: {
            args: Prisma.AnalyticsRegionDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AnalyticsRegionPayload>
          }
          update: {
            args: Prisma.AnalyticsRegionUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AnalyticsRegionPayload>
          }
          deleteMany: {
            args: Prisma.AnalyticsRegionDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.AnalyticsRegionUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.AnalyticsRegionUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AnalyticsRegionPayload>[]
          }
          upsert: {
            args: Prisma.AnalyticsRegionUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AnalyticsRegionPayload>
          }
          aggregate: {
            args: Prisma.AnalyticsRegionAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateAnalyticsRegion>
          }
          groupBy: {
            args: Prisma.AnalyticsRegionGroupByArgs<ExtArgs>
            result: $Utils.Optional<AnalyticsRegionGroupByOutputType>[]
          }
          count: {
            args: Prisma.AnalyticsRegionCountArgs<ExtArgs>
            result: $Utils.Optional<AnalyticsRegionCountAggregateOutputType> | number
          }
        }
      }
      AnalyticsDailySummary: {
        payload: Prisma.$AnalyticsDailySummaryPayload<ExtArgs>
        fields: Prisma.AnalyticsDailySummaryFieldRefs
        operations: {
          findUnique: {
            args: Prisma.AnalyticsDailySummaryFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AnalyticsDailySummaryPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.AnalyticsDailySummaryFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AnalyticsDailySummaryPayload>
          }
          findFirst: {
            args: Prisma.AnalyticsDailySummaryFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AnalyticsDailySummaryPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.AnalyticsDailySummaryFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AnalyticsDailySummaryPayload>
          }
          findMany: {
            args: Prisma.AnalyticsDailySummaryFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AnalyticsDailySummaryPayload>[]
          }
          create: {
            args: Prisma.AnalyticsDailySummaryCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AnalyticsDailySummaryPayload>
          }
          createMany: {
            args: Prisma.AnalyticsDailySummaryCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.AnalyticsDailySummaryCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AnalyticsDailySummaryPayload>[]
          }
          delete: {
            args: Prisma.AnalyticsDailySummaryDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AnalyticsDailySummaryPayload>
          }
          update: {
            args: Prisma.AnalyticsDailySummaryUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AnalyticsDailySummaryPayload>
          }
          deleteMany: {
            args: Prisma.AnalyticsDailySummaryDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.AnalyticsDailySummaryUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.AnalyticsDailySummaryUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AnalyticsDailySummaryPayload>[]
          }
          upsert: {
            args: Prisma.AnalyticsDailySummaryUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AnalyticsDailySummaryPayload>
          }
          aggregate: {
            args: Prisma.AnalyticsDailySummaryAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateAnalyticsDailySummary>
          }
          groupBy: {
            args: Prisma.AnalyticsDailySummaryGroupByArgs<ExtArgs>
            result: $Utils.Optional<AnalyticsDailySummaryGroupByOutputType>[]
          }
          count: {
            args: Prisma.AnalyticsDailySummaryCountArgs<ExtArgs>
            result: $Utils.Optional<AnalyticsDailySummaryCountAggregateOutputType> | number
          }
        }
      }
    }
  } & {
    other: {
      payload: any
      operations: {
        $executeRaw: {
          args: [query: TemplateStringsArray | Prisma.Sql, ...values: any[]],
          result: any
        }
        $executeRawUnsafe: {
          args: [query: string, ...values: any[]],
          result: any
        }
        $queryRaw: {
          args: [query: TemplateStringsArray | Prisma.Sql, ...values: any[]],
          result: any
        }
        $queryRawUnsafe: {
          args: [query: string, ...values: any[]],
          result: any
        }
      }
    }
  }
  export const defineExtension: $Extensions.ExtendsHook<"define", Prisma.TypeMapCb, $Extensions.DefaultArgs>
  export type DefaultPrismaClient = PrismaClient
  export type ErrorFormat = 'pretty' | 'colorless' | 'minimal'
  export interface PrismaClientOptions {
    /**
     * Overwrites the datasource url from your schema.prisma file
     */
    datasources?: Datasources
    /**
     * Overwrites the datasource url from your schema.prisma file
     */
    datasourceUrl?: string
    /**
     * @default "colorless"
     */
    errorFormat?: ErrorFormat
    /**
     * @example
     * ```
     * // Shorthand for `emit: 'stdout'`
     * log: ['query', 'info', 'warn', 'error']
     * 
     * // Emit as events only
     * log: [
     *   { emit: 'event', level: 'query' },
     *   { emit: 'event', level: 'info' },
     *   { emit: 'event', level: 'warn' }
     *   { emit: 'event', level: 'error' }
     * ]
     * 
     * / Emit as events and log to stdout
     * og: [
     *  { emit: 'stdout', level: 'query' },
     *  { emit: 'stdout', level: 'info' },
     *  { emit: 'stdout', level: 'warn' }
     *  { emit: 'stdout', level: 'error' }
     * 
     * ```
     * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/logging#the-log-option).
     */
    log?: (LogLevel | LogDefinition)[]
    /**
     * The default values for transactionOptions
     * maxWait ?= 2000
     * timeout ?= 5000
     */
    transactionOptions?: {
      maxWait?: number
      timeout?: number
      isolationLevel?: Prisma.TransactionIsolationLevel
    }
    /**
     * Instance of a Driver Adapter, e.g., like one provided by `@prisma/adapter-planetscale`
     */
    adapter?: runtime.SqlDriverAdapterFactory | null
    /**
     * Global configuration for omitting model fields by default.
     * 
     * @example
     * ```
     * const prisma = new PrismaClient({
     *   omit: {
     *     user: {
     *       password: true
     *     }
     *   }
     * })
     * ```
     */
    omit?: Prisma.GlobalOmitConfig
  }
  export type GlobalOmitConfig = {
    analyticsConnection?: AnalyticsConnectionOmit
    analyticsSyncState?: AnalyticsSyncStateOmit
    analyticsProduct?: AnalyticsProductOmit
    analyticsRegion?: AnalyticsRegionOmit
    analyticsDailySummary?: AnalyticsDailySummaryOmit
  }

  /* Types for Logging */
  export type LogLevel = 'info' | 'query' | 'warn' | 'error'
  export type LogDefinition = {
    level: LogLevel
    emit: 'stdout' | 'event'
  }

  export type CheckIsLogLevel<T> = T extends LogLevel ? T : never;

  export type GetLogType<T> = CheckIsLogLevel<
    T extends LogDefinition ? T['level'] : T
  >;

  export type GetEvents<T extends any[]> = T extends Array<LogLevel | LogDefinition>
    ? GetLogType<T[number]>
    : never;

  export type QueryEvent = {
    timestamp: Date
    query: string
    params: string
    duration: number
    target: string
  }

  export type LogEvent = {
    timestamp: Date
    message: string
    target: string
  }
  /* End Types for Logging */


  export type PrismaAction =
    | 'findUnique'
    | 'findUniqueOrThrow'
    | 'findMany'
    | 'findFirst'
    | 'findFirstOrThrow'
    | 'create'
    | 'createMany'
    | 'createManyAndReturn'
    | 'update'
    | 'updateMany'
    | 'updateManyAndReturn'
    | 'upsert'
    | 'delete'
    | 'deleteMany'
    | 'executeRaw'
    | 'queryRaw'
    | 'aggregate'
    | 'count'
    | 'runCommandRaw'
    | 'findRaw'
    | 'groupBy'

  // tested in getLogLevel.test.ts
  export function getLogLevel(log: Array<LogLevel | LogDefinition>): LogLevel | undefined;

  /**
   * `PrismaClient` proxy available in interactive transactions.
   */
  export type TransactionClient = Omit<Prisma.DefaultPrismaClient, runtime.ITXClientDenyList>

  export type Datasource = {
    url?: string
  }

  /**
   * Count Types
   */



  /**
   * Models
   */

  /**
   * Model AnalyticsConnection
   */

  export type AggregateAnalyticsConnection = {
    _count: AnalyticsConnectionCountAggregateOutputType | null
    _min: AnalyticsConnectionMinAggregateOutputType | null
    _max: AnalyticsConnectionMaxAggregateOutputType | null
  }

  export type AnalyticsConnectionMinAggregateOutputType = {
    clientId: string | null
    marketplace: string | null
    accountName: string | null
    sellerSid: string | null
    apiKeyEncrypted: string | null
    isActive: boolean | null
    lastVerifiedAt: Date | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type AnalyticsConnectionMaxAggregateOutputType = {
    clientId: string | null
    marketplace: string | null
    accountName: string | null
    sellerSid: string | null
    apiKeyEncrypted: string | null
    isActive: boolean | null
    lastVerifiedAt: Date | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type AnalyticsConnectionCountAggregateOutputType = {
    clientId: number
    marketplace: number
    accountName: number
    sellerSid: number
    apiKeyEncrypted: number
    isActive: number
    lastVerifiedAt: number
    createdAt: number
    updatedAt: number
    _all: number
  }


  export type AnalyticsConnectionMinAggregateInputType = {
    clientId?: true
    marketplace?: true
    accountName?: true
    sellerSid?: true
    apiKeyEncrypted?: true
    isActive?: true
    lastVerifiedAt?: true
    createdAt?: true
    updatedAt?: true
  }

  export type AnalyticsConnectionMaxAggregateInputType = {
    clientId?: true
    marketplace?: true
    accountName?: true
    sellerSid?: true
    apiKeyEncrypted?: true
    isActive?: true
    lastVerifiedAt?: true
    createdAt?: true
    updatedAt?: true
  }

  export type AnalyticsConnectionCountAggregateInputType = {
    clientId?: true
    marketplace?: true
    accountName?: true
    sellerSid?: true
    apiKeyEncrypted?: true
    isActive?: true
    lastVerifiedAt?: true
    createdAt?: true
    updatedAt?: true
    _all?: true
  }

  export type AnalyticsConnectionAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which AnalyticsConnection to aggregate.
     */
    where?: AnalyticsConnectionWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of AnalyticsConnections to fetch.
     */
    orderBy?: AnalyticsConnectionOrderByWithRelationInput | AnalyticsConnectionOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: AnalyticsConnectionWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` AnalyticsConnections from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` AnalyticsConnections.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned AnalyticsConnections
    **/
    _count?: true | AnalyticsConnectionCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: AnalyticsConnectionMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: AnalyticsConnectionMaxAggregateInputType
  }

  export type GetAnalyticsConnectionAggregateType<T extends AnalyticsConnectionAggregateArgs> = {
        [P in keyof T & keyof AggregateAnalyticsConnection]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateAnalyticsConnection[P]>
      : GetScalarType<T[P], AggregateAnalyticsConnection[P]>
  }




  export type AnalyticsConnectionGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: AnalyticsConnectionWhereInput
    orderBy?: AnalyticsConnectionOrderByWithAggregationInput | AnalyticsConnectionOrderByWithAggregationInput[]
    by: AnalyticsConnectionScalarFieldEnum[] | AnalyticsConnectionScalarFieldEnum
    having?: AnalyticsConnectionScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: AnalyticsConnectionCountAggregateInputType | true
    _min?: AnalyticsConnectionMinAggregateInputType
    _max?: AnalyticsConnectionMaxAggregateInputType
  }

  export type AnalyticsConnectionGroupByOutputType = {
    clientId: string
    marketplace: string
    accountName: string | null
    sellerSid: string | null
    apiKeyEncrypted: string
    isActive: boolean
    lastVerifiedAt: Date | null
    createdAt: Date
    updatedAt: Date
    _count: AnalyticsConnectionCountAggregateOutputType | null
    _min: AnalyticsConnectionMinAggregateOutputType | null
    _max: AnalyticsConnectionMaxAggregateOutputType | null
  }

  type GetAnalyticsConnectionGroupByPayload<T extends AnalyticsConnectionGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<AnalyticsConnectionGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof AnalyticsConnectionGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], AnalyticsConnectionGroupByOutputType[P]>
            : GetScalarType<T[P], AnalyticsConnectionGroupByOutputType[P]>
        }
      >
    >


  export type AnalyticsConnectionSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    clientId?: boolean
    marketplace?: boolean
    accountName?: boolean
    sellerSid?: boolean
    apiKeyEncrypted?: boolean
    isActive?: boolean
    lastVerifiedAt?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }, ExtArgs["result"]["analyticsConnection"]>

  export type AnalyticsConnectionSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    clientId?: boolean
    marketplace?: boolean
    accountName?: boolean
    sellerSid?: boolean
    apiKeyEncrypted?: boolean
    isActive?: boolean
    lastVerifiedAt?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }, ExtArgs["result"]["analyticsConnection"]>

  export type AnalyticsConnectionSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    clientId?: boolean
    marketplace?: boolean
    accountName?: boolean
    sellerSid?: boolean
    apiKeyEncrypted?: boolean
    isActive?: boolean
    lastVerifiedAt?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }, ExtArgs["result"]["analyticsConnection"]>

  export type AnalyticsConnectionSelectScalar = {
    clientId?: boolean
    marketplace?: boolean
    accountName?: boolean
    sellerSid?: boolean
    apiKeyEncrypted?: boolean
    isActive?: boolean
    lastVerifiedAt?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }

  export type AnalyticsConnectionOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"clientId" | "marketplace" | "accountName" | "sellerSid" | "apiKeyEncrypted" | "isActive" | "lastVerifiedAt" | "createdAt" | "updatedAt", ExtArgs["result"]["analyticsConnection"]>

  export type $AnalyticsConnectionPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "AnalyticsConnection"
    objects: {}
    scalars: $Extensions.GetPayloadResult<{
      clientId: string
      marketplace: string
      accountName: string | null
      sellerSid: string | null
      apiKeyEncrypted: string
      isActive: boolean
      lastVerifiedAt: Date | null
      createdAt: Date
      updatedAt: Date
    }, ExtArgs["result"]["analyticsConnection"]>
    composites: {}
  }

  type AnalyticsConnectionGetPayload<S extends boolean | null | undefined | AnalyticsConnectionDefaultArgs> = $Result.GetResult<Prisma.$AnalyticsConnectionPayload, S>

  type AnalyticsConnectionCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<AnalyticsConnectionFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: AnalyticsConnectionCountAggregateInputType | true
    }

  export interface AnalyticsConnectionDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['AnalyticsConnection'], meta: { name: 'AnalyticsConnection' } }
    /**
     * Find zero or one AnalyticsConnection that matches the filter.
     * @param {AnalyticsConnectionFindUniqueArgs} args - Arguments to find a AnalyticsConnection
     * @example
     * // Get one AnalyticsConnection
     * const analyticsConnection = await prisma.analyticsConnection.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends AnalyticsConnectionFindUniqueArgs>(args: SelectSubset<T, AnalyticsConnectionFindUniqueArgs<ExtArgs>>): Prisma__AnalyticsConnectionClient<$Result.GetResult<Prisma.$AnalyticsConnectionPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one AnalyticsConnection that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {AnalyticsConnectionFindUniqueOrThrowArgs} args - Arguments to find a AnalyticsConnection
     * @example
     * // Get one AnalyticsConnection
     * const analyticsConnection = await prisma.analyticsConnection.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends AnalyticsConnectionFindUniqueOrThrowArgs>(args: SelectSubset<T, AnalyticsConnectionFindUniqueOrThrowArgs<ExtArgs>>): Prisma__AnalyticsConnectionClient<$Result.GetResult<Prisma.$AnalyticsConnectionPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first AnalyticsConnection that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AnalyticsConnectionFindFirstArgs} args - Arguments to find a AnalyticsConnection
     * @example
     * // Get one AnalyticsConnection
     * const analyticsConnection = await prisma.analyticsConnection.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends AnalyticsConnectionFindFirstArgs>(args?: SelectSubset<T, AnalyticsConnectionFindFirstArgs<ExtArgs>>): Prisma__AnalyticsConnectionClient<$Result.GetResult<Prisma.$AnalyticsConnectionPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first AnalyticsConnection that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AnalyticsConnectionFindFirstOrThrowArgs} args - Arguments to find a AnalyticsConnection
     * @example
     * // Get one AnalyticsConnection
     * const analyticsConnection = await prisma.analyticsConnection.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends AnalyticsConnectionFindFirstOrThrowArgs>(args?: SelectSubset<T, AnalyticsConnectionFindFirstOrThrowArgs<ExtArgs>>): Prisma__AnalyticsConnectionClient<$Result.GetResult<Prisma.$AnalyticsConnectionPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more AnalyticsConnections that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AnalyticsConnectionFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all AnalyticsConnections
     * const analyticsConnections = await prisma.analyticsConnection.findMany()
     * 
     * // Get first 10 AnalyticsConnections
     * const analyticsConnections = await prisma.analyticsConnection.findMany({ take: 10 })
     * 
     * // Only select the `clientId`
     * const analyticsConnectionWithClientIdOnly = await prisma.analyticsConnection.findMany({ select: { clientId: true } })
     * 
     */
    findMany<T extends AnalyticsConnectionFindManyArgs>(args?: SelectSubset<T, AnalyticsConnectionFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$AnalyticsConnectionPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a AnalyticsConnection.
     * @param {AnalyticsConnectionCreateArgs} args - Arguments to create a AnalyticsConnection.
     * @example
     * // Create one AnalyticsConnection
     * const AnalyticsConnection = await prisma.analyticsConnection.create({
     *   data: {
     *     // ... data to create a AnalyticsConnection
     *   }
     * })
     * 
     */
    create<T extends AnalyticsConnectionCreateArgs>(args: SelectSubset<T, AnalyticsConnectionCreateArgs<ExtArgs>>): Prisma__AnalyticsConnectionClient<$Result.GetResult<Prisma.$AnalyticsConnectionPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many AnalyticsConnections.
     * @param {AnalyticsConnectionCreateManyArgs} args - Arguments to create many AnalyticsConnections.
     * @example
     * // Create many AnalyticsConnections
     * const analyticsConnection = await prisma.analyticsConnection.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends AnalyticsConnectionCreateManyArgs>(args?: SelectSubset<T, AnalyticsConnectionCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many AnalyticsConnections and returns the data saved in the database.
     * @param {AnalyticsConnectionCreateManyAndReturnArgs} args - Arguments to create many AnalyticsConnections.
     * @example
     * // Create many AnalyticsConnections
     * const analyticsConnection = await prisma.analyticsConnection.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many AnalyticsConnections and only return the `clientId`
     * const analyticsConnectionWithClientIdOnly = await prisma.analyticsConnection.createManyAndReturn({
     *   select: { clientId: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends AnalyticsConnectionCreateManyAndReturnArgs>(args?: SelectSubset<T, AnalyticsConnectionCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$AnalyticsConnectionPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a AnalyticsConnection.
     * @param {AnalyticsConnectionDeleteArgs} args - Arguments to delete one AnalyticsConnection.
     * @example
     * // Delete one AnalyticsConnection
     * const AnalyticsConnection = await prisma.analyticsConnection.delete({
     *   where: {
     *     // ... filter to delete one AnalyticsConnection
     *   }
     * })
     * 
     */
    delete<T extends AnalyticsConnectionDeleteArgs>(args: SelectSubset<T, AnalyticsConnectionDeleteArgs<ExtArgs>>): Prisma__AnalyticsConnectionClient<$Result.GetResult<Prisma.$AnalyticsConnectionPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one AnalyticsConnection.
     * @param {AnalyticsConnectionUpdateArgs} args - Arguments to update one AnalyticsConnection.
     * @example
     * // Update one AnalyticsConnection
     * const analyticsConnection = await prisma.analyticsConnection.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends AnalyticsConnectionUpdateArgs>(args: SelectSubset<T, AnalyticsConnectionUpdateArgs<ExtArgs>>): Prisma__AnalyticsConnectionClient<$Result.GetResult<Prisma.$AnalyticsConnectionPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more AnalyticsConnections.
     * @param {AnalyticsConnectionDeleteManyArgs} args - Arguments to filter AnalyticsConnections to delete.
     * @example
     * // Delete a few AnalyticsConnections
     * const { count } = await prisma.analyticsConnection.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends AnalyticsConnectionDeleteManyArgs>(args?: SelectSubset<T, AnalyticsConnectionDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more AnalyticsConnections.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AnalyticsConnectionUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many AnalyticsConnections
     * const analyticsConnection = await prisma.analyticsConnection.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends AnalyticsConnectionUpdateManyArgs>(args: SelectSubset<T, AnalyticsConnectionUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more AnalyticsConnections and returns the data updated in the database.
     * @param {AnalyticsConnectionUpdateManyAndReturnArgs} args - Arguments to update many AnalyticsConnections.
     * @example
     * // Update many AnalyticsConnections
     * const analyticsConnection = await prisma.analyticsConnection.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more AnalyticsConnections and only return the `clientId`
     * const analyticsConnectionWithClientIdOnly = await prisma.analyticsConnection.updateManyAndReturn({
     *   select: { clientId: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends AnalyticsConnectionUpdateManyAndReturnArgs>(args: SelectSubset<T, AnalyticsConnectionUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$AnalyticsConnectionPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one AnalyticsConnection.
     * @param {AnalyticsConnectionUpsertArgs} args - Arguments to update or create a AnalyticsConnection.
     * @example
     * // Update or create a AnalyticsConnection
     * const analyticsConnection = await prisma.analyticsConnection.upsert({
     *   create: {
     *     // ... data to create a AnalyticsConnection
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the AnalyticsConnection we want to update
     *   }
     * })
     */
    upsert<T extends AnalyticsConnectionUpsertArgs>(args: SelectSubset<T, AnalyticsConnectionUpsertArgs<ExtArgs>>): Prisma__AnalyticsConnectionClient<$Result.GetResult<Prisma.$AnalyticsConnectionPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of AnalyticsConnections.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AnalyticsConnectionCountArgs} args - Arguments to filter AnalyticsConnections to count.
     * @example
     * // Count the number of AnalyticsConnections
     * const count = await prisma.analyticsConnection.count({
     *   where: {
     *     // ... the filter for the AnalyticsConnections we want to count
     *   }
     * })
    **/
    count<T extends AnalyticsConnectionCountArgs>(
      args?: Subset<T, AnalyticsConnectionCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], AnalyticsConnectionCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a AnalyticsConnection.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AnalyticsConnectionAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends AnalyticsConnectionAggregateArgs>(args: Subset<T, AnalyticsConnectionAggregateArgs>): Prisma.PrismaPromise<GetAnalyticsConnectionAggregateType<T>>

    /**
     * Group by AnalyticsConnection.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AnalyticsConnectionGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends AnalyticsConnectionGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: AnalyticsConnectionGroupByArgs['orderBy'] }
        : { orderBy?: AnalyticsConnectionGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, AnalyticsConnectionGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetAnalyticsConnectionGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the AnalyticsConnection model
   */
  readonly fields: AnalyticsConnectionFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for AnalyticsConnection.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__AnalyticsConnectionClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the AnalyticsConnection model
   */
  interface AnalyticsConnectionFieldRefs {
    readonly clientId: FieldRef<"AnalyticsConnection", 'String'>
    readonly marketplace: FieldRef<"AnalyticsConnection", 'String'>
    readonly accountName: FieldRef<"AnalyticsConnection", 'String'>
    readonly sellerSid: FieldRef<"AnalyticsConnection", 'String'>
    readonly apiKeyEncrypted: FieldRef<"AnalyticsConnection", 'String'>
    readonly isActive: FieldRef<"AnalyticsConnection", 'Boolean'>
    readonly lastVerifiedAt: FieldRef<"AnalyticsConnection", 'DateTime'>
    readonly createdAt: FieldRef<"AnalyticsConnection", 'DateTime'>
    readonly updatedAt: FieldRef<"AnalyticsConnection", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * AnalyticsConnection findUnique
   */
  export type AnalyticsConnectionFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AnalyticsConnection
     */
    select?: AnalyticsConnectionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AnalyticsConnection
     */
    omit?: AnalyticsConnectionOmit<ExtArgs> | null
    /**
     * Filter, which AnalyticsConnection to fetch.
     */
    where: AnalyticsConnectionWhereUniqueInput
  }

  /**
   * AnalyticsConnection findUniqueOrThrow
   */
  export type AnalyticsConnectionFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AnalyticsConnection
     */
    select?: AnalyticsConnectionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AnalyticsConnection
     */
    omit?: AnalyticsConnectionOmit<ExtArgs> | null
    /**
     * Filter, which AnalyticsConnection to fetch.
     */
    where: AnalyticsConnectionWhereUniqueInput
  }

  /**
   * AnalyticsConnection findFirst
   */
  export type AnalyticsConnectionFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AnalyticsConnection
     */
    select?: AnalyticsConnectionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AnalyticsConnection
     */
    omit?: AnalyticsConnectionOmit<ExtArgs> | null
    /**
     * Filter, which AnalyticsConnection to fetch.
     */
    where?: AnalyticsConnectionWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of AnalyticsConnections to fetch.
     */
    orderBy?: AnalyticsConnectionOrderByWithRelationInput | AnalyticsConnectionOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for AnalyticsConnections.
     */
    cursor?: AnalyticsConnectionWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` AnalyticsConnections from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` AnalyticsConnections.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of AnalyticsConnections.
     */
    distinct?: AnalyticsConnectionScalarFieldEnum | AnalyticsConnectionScalarFieldEnum[]
  }

  /**
   * AnalyticsConnection findFirstOrThrow
   */
  export type AnalyticsConnectionFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AnalyticsConnection
     */
    select?: AnalyticsConnectionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AnalyticsConnection
     */
    omit?: AnalyticsConnectionOmit<ExtArgs> | null
    /**
     * Filter, which AnalyticsConnection to fetch.
     */
    where?: AnalyticsConnectionWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of AnalyticsConnections to fetch.
     */
    orderBy?: AnalyticsConnectionOrderByWithRelationInput | AnalyticsConnectionOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for AnalyticsConnections.
     */
    cursor?: AnalyticsConnectionWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` AnalyticsConnections from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` AnalyticsConnections.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of AnalyticsConnections.
     */
    distinct?: AnalyticsConnectionScalarFieldEnum | AnalyticsConnectionScalarFieldEnum[]
  }

  /**
   * AnalyticsConnection findMany
   */
  export type AnalyticsConnectionFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AnalyticsConnection
     */
    select?: AnalyticsConnectionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AnalyticsConnection
     */
    omit?: AnalyticsConnectionOmit<ExtArgs> | null
    /**
     * Filter, which AnalyticsConnections to fetch.
     */
    where?: AnalyticsConnectionWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of AnalyticsConnections to fetch.
     */
    orderBy?: AnalyticsConnectionOrderByWithRelationInput | AnalyticsConnectionOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing AnalyticsConnections.
     */
    cursor?: AnalyticsConnectionWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` AnalyticsConnections from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` AnalyticsConnections.
     */
    skip?: number
    distinct?: AnalyticsConnectionScalarFieldEnum | AnalyticsConnectionScalarFieldEnum[]
  }

  /**
   * AnalyticsConnection create
   */
  export type AnalyticsConnectionCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AnalyticsConnection
     */
    select?: AnalyticsConnectionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AnalyticsConnection
     */
    omit?: AnalyticsConnectionOmit<ExtArgs> | null
    /**
     * The data needed to create a AnalyticsConnection.
     */
    data: XOR<AnalyticsConnectionCreateInput, AnalyticsConnectionUncheckedCreateInput>
  }

  /**
   * AnalyticsConnection createMany
   */
  export type AnalyticsConnectionCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many AnalyticsConnections.
     */
    data: AnalyticsConnectionCreateManyInput | AnalyticsConnectionCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * AnalyticsConnection createManyAndReturn
   */
  export type AnalyticsConnectionCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AnalyticsConnection
     */
    select?: AnalyticsConnectionSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the AnalyticsConnection
     */
    omit?: AnalyticsConnectionOmit<ExtArgs> | null
    /**
     * The data used to create many AnalyticsConnections.
     */
    data: AnalyticsConnectionCreateManyInput | AnalyticsConnectionCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * AnalyticsConnection update
   */
  export type AnalyticsConnectionUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AnalyticsConnection
     */
    select?: AnalyticsConnectionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AnalyticsConnection
     */
    omit?: AnalyticsConnectionOmit<ExtArgs> | null
    /**
     * The data needed to update a AnalyticsConnection.
     */
    data: XOR<AnalyticsConnectionUpdateInput, AnalyticsConnectionUncheckedUpdateInput>
    /**
     * Choose, which AnalyticsConnection to update.
     */
    where: AnalyticsConnectionWhereUniqueInput
  }

  /**
   * AnalyticsConnection updateMany
   */
  export type AnalyticsConnectionUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update AnalyticsConnections.
     */
    data: XOR<AnalyticsConnectionUpdateManyMutationInput, AnalyticsConnectionUncheckedUpdateManyInput>
    /**
     * Filter which AnalyticsConnections to update
     */
    where?: AnalyticsConnectionWhereInput
    /**
     * Limit how many AnalyticsConnections to update.
     */
    limit?: number
  }

  /**
   * AnalyticsConnection updateManyAndReturn
   */
  export type AnalyticsConnectionUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AnalyticsConnection
     */
    select?: AnalyticsConnectionSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the AnalyticsConnection
     */
    omit?: AnalyticsConnectionOmit<ExtArgs> | null
    /**
     * The data used to update AnalyticsConnections.
     */
    data: XOR<AnalyticsConnectionUpdateManyMutationInput, AnalyticsConnectionUncheckedUpdateManyInput>
    /**
     * Filter which AnalyticsConnections to update
     */
    where?: AnalyticsConnectionWhereInput
    /**
     * Limit how many AnalyticsConnections to update.
     */
    limit?: number
  }

  /**
   * AnalyticsConnection upsert
   */
  export type AnalyticsConnectionUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AnalyticsConnection
     */
    select?: AnalyticsConnectionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AnalyticsConnection
     */
    omit?: AnalyticsConnectionOmit<ExtArgs> | null
    /**
     * The filter to search for the AnalyticsConnection to update in case it exists.
     */
    where: AnalyticsConnectionWhereUniqueInput
    /**
     * In case the AnalyticsConnection found by the `where` argument doesn't exist, create a new AnalyticsConnection with this data.
     */
    create: XOR<AnalyticsConnectionCreateInput, AnalyticsConnectionUncheckedCreateInput>
    /**
     * In case the AnalyticsConnection was found with the provided `where` argument, update it with this data.
     */
    update: XOR<AnalyticsConnectionUpdateInput, AnalyticsConnectionUncheckedUpdateInput>
  }

  /**
   * AnalyticsConnection delete
   */
  export type AnalyticsConnectionDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AnalyticsConnection
     */
    select?: AnalyticsConnectionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AnalyticsConnection
     */
    omit?: AnalyticsConnectionOmit<ExtArgs> | null
    /**
     * Filter which AnalyticsConnection to delete.
     */
    where: AnalyticsConnectionWhereUniqueInput
  }

  /**
   * AnalyticsConnection deleteMany
   */
  export type AnalyticsConnectionDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which AnalyticsConnections to delete
     */
    where?: AnalyticsConnectionWhereInput
    /**
     * Limit how many AnalyticsConnections to delete.
     */
    limit?: number
  }

  /**
   * AnalyticsConnection without action
   */
  export type AnalyticsConnectionDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AnalyticsConnection
     */
    select?: AnalyticsConnectionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AnalyticsConnection
     */
    omit?: AnalyticsConnectionOmit<ExtArgs> | null
  }


  /**
   * Model AnalyticsSyncState
   */

  export type AggregateAnalyticsSyncState = {
    _count: AnalyticsSyncStateCountAggregateOutputType | null
    _avg: AnalyticsSyncStateAvgAggregateOutputType | null
    _sum: AnalyticsSyncStateSumAggregateOutputType | null
    _min: AnalyticsSyncStateMinAggregateOutputType | null
    _max: AnalyticsSyncStateMaxAggregateOutputType | null
  }

  export type AnalyticsSyncStateAvgAggregateOutputType = {
    periodDays: number | null
    productCount: number | null
  }

  export type AnalyticsSyncStateSumAggregateOutputType = {
    periodDays: number | null
    productCount: number | null
  }

  export type AnalyticsSyncStateMinAggregateOutputType = {
    clientId: string | null
    marketplace: string | null
    status: string | null
    periodDays: number | null
    currency: string | null
    productCount: number | null
    lastStartedAt: Date | null
    lastSyncedAt: Date | null
    lastError: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type AnalyticsSyncStateMaxAggregateOutputType = {
    clientId: string | null
    marketplace: string | null
    status: string | null
    periodDays: number | null
    currency: string | null
    productCount: number | null
    lastStartedAt: Date | null
    lastSyncedAt: Date | null
    lastError: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type AnalyticsSyncStateCountAggregateOutputType = {
    clientId: number
    marketplace: number
    status: number
    periodDays: number
    currency: number
    productCount: number
    lastStartedAt: number
    lastSyncedAt: number
    lastError: number
    sourceStatus: number
    createdAt: number
    updatedAt: number
    _all: number
  }


  export type AnalyticsSyncStateAvgAggregateInputType = {
    periodDays?: true
    productCount?: true
  }

  export type AnalyticsSyncStateSumAggregateInputType = {
    periodDays?: true
    productCount?: true
  }

  export type AnalyticsSyncStateMinAggregateInputType = {
    clientId?: true
    marketplace?: true
    status?: true
    periodDays?: true
    currency?: true
    productCount?: true
    lastStartedAt?: true
    lastSyncedAt?: true
    lastError?: true
    createdAt?: true
    updatedAt?: true
  }

  export type AnalyticsSyncStateMaxAggregateInputType = {
    clientId?: true
    marketplace?: true
    status?: true
    periodDays?: true
    currency?: true
    productCount?: true
    lastStartedAt?: true
    lastSyncedAt?: true
    lastError?: true
    createdAt?: true
    updatedAt?: true
  }

  export type AnalyticsSyncStateCountAggregateInputType = {
    clientId?: true
    marketplace?: true
    status?: true
    periodDays?: true
    currency?: true
    productCount?: true
    lastStartedAt?: true
    lastSyncedAt?: true
    lastError?: true
    sourceStatus?: true
    createdAt?: true
    updatedAt?: true
    _all?: true
  }

  export type AnalyticsSyncStateAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which AnalyticsSyncState to aggregate.
     */
    where?: AnalyticsSyncStateWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of AnalyticsSyncStates to fetch.
     */
    orderBy?: AnalyticsSyncStateOrderByWithRelationInput | AnalyticsSyncStateOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: AnalyticsSyncStateWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` AnalyticsSyncStates from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` AnalyticsSyncStates.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned AnalyticsSyncStates
    **/
    _count?: true | AnalyticsSyncStateCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: AnalyticsSyncStateAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: AnalyticsSyncStateSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: AnalyticsSyncStateMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: AnalyticsSyncStateMaxAggregateInputType
  }

  export type GetAnalyticsSyncStateAggregateType<T extends AnalyticsSyncStateAggregateArgs> = {
        [P in keyof T & keyof AggregateAnalyticsSyncState]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateAnalyticsSyncState[P]>
      : GetScalarType<T[P], AggregateAnalyticsSyncState[P]>
  }




  export type AnalyticsSyncStateGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: AnalyticsSyncStateWhereInput
    orderBy?: AnalyticsSyncStateOrderByWithAggregationInput | AnalyticsSyncStateOrderByWithAggregationInput[]
    by: AnalyticsSyncStateScalarFieldEnum[] | AnalyticsSyncStateScalarFieldEnum
    having?: AnalyticsSyncStateScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: AnalyticsSyncStateCountAggregateInputType | true
    _avg?: AnalyticsSyncStateAvgAggregateInputType
    _sum?: AnalyticsSyncStateSumAggregateInputType
    _min?: AnalyticsSyncStateMinAggregateInputType
    _max?: AnalyticsSyncStateMaxAggregateInputType
  }

  export type AnalyticsSyncStateGroupByOutputType = {
    clientId: string
    marketplace: string
    status: string
    periodDays: number
    currency: string
    productCount: number
    lastStartedAt: Date | null
    lastSyncedAt: Date | null
    lastError: string | null
    sourceStatus: JsonValue | null
    createdAt: Date
    updatedAt: Date
    _count: AnalyticsSyncStateCountAggregateOutputType | null
    _avg: AnalyticsSyncStateAvgAggregateOutputType | null
    _sum: AnalyticsSyncStateSumAggregateOutputType | null
    _min: AnalyticsSyncStateMinAggregateOutputType | null
    _max: AnalyticsSyncStateMaxAggregateOutputType | null
  }

  type GetAnalyticsSyncStateGroupByPayload<T extends AnalyticsSyncStateGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<AnalyticsSyncStateGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof AnalyticsSyncStateGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], AnalyticsSyncStateGroupByOutputType[P]>
            : GetScalarType<T[P], AnalyticsSyncStateGroupByOutputType[P]>
        }
      >
    >


  export type AnalyticsSyncStateSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    clientId?: boolean
    marketplace?: boolean
    status?: boolean
    periodDays?: boolean
    currency?: boolean
    productCount?: boolean
    lastStartedAt?: boolean
    lastSyncedAt?: boolean
    lastError?: boolean
    sourceStatus?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }, ExtArgs["result"]["analyticsSyncState"]>

  export type AnalyticsSyncStateSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    clientId?: boolean
    marketplace?: boolean
    status?: boolean
    periodDays?: boolean
    currency?: boolean
    productCount?: boolean
    lastStartedAt?: boolean
    lastSyncedAt?: boolean
    lastError?: boolean
    sourceStatus?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }, ExtArgs["result"]["analyticsSyncState"]>

  export type AnalyticsSyncStateSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    clientId?: boolean
    marketplace?: boolean
    status?: boolean
    periodDays?: boolean
    currency?: boolean
    productCount?: boolean
    lastStartedAt?: boolean
    lastSyncedAt?: boolean
    lastError?: boolean
    sourceStatus?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }, ExtArgs["result"]["analyticsSyncState"]>

  export type AnalyticsSyncStateSelectScalar = {
    clientId?: boolean
    marketplace?: boolean
    status?: boolean
    periodDays?: boolean
    currency?: boolean
    productCount?: boolean
    lastStartedAt?: boolean
    lastSyncedAt?: boolean
    lastError?: boolean
    sourceStatus?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }

  export type AnalyticsSyncStateOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"clientId" | "marketplace" | "status" | "periodDays" | "currency" | "productCount" | "lastStartedAt" | "lastSyncedAt" | "lastError" | "sourceStatus" | "createdAt" | "updatedAt", ExtArgs["result"]["analyticsSyncState"]>

  export type $AnalyticsSyncStatePayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "AnalyticsSyncState"
    objects: {}
    scalars: $Extensions.GetPayloadResult<{
      clientId: string
      marketplace: string
      status: string
      periodDays: number
      currency: string
      productCount: number
      lastStartedAt: Date | null
      lastSyncedAt: Date | null
      lastError: string | null
      sourceStatus: Prisma.JsonValue | null
      createdAt: Date
      updatedAt: Date
    }, ExtArgs["result"]["analyticsSyncState"]>
    composites: {}
  }

  type AnalyticsSyncStateGetPayload<S extends boolean | null | undefined | AnalyticsSyncStateDefaultArgs> = $Result.GetResult<Prisma.$AnalyticsSyncStatePayload, S>

  type AnalyticsSyncStateCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<AnalyticsSyncStateFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: AnalyticsSyncStateCountAggregateInputType | true
    }

  export interface AnalyticsSyncStateDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['AnalyticsSyncState'], meta: { name: 'AnalyticsSyncState' } }
    /**
     * Find zero or one AnalyticsSyncState that matches the filter.
     * @param {AnalyticsSyncStateFindUniqueArgs} args - Arguments to find a AnalyticsSyncState
     * @example
     * // Get one AnalyticsSyncState
     * const analyticsSyncState = await prisma.analyticsSyncState.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends AnalyticsSyncStateFindUniqueArgs>(args: SelectSubset<T, AnalyticsSyncStateFindUniqueArgs<ExtArgs>>): Prisma__AnalyticsSyncStateClient<$Result.GetResult<Prisma.$AnalyticsSyncStatePayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one AnalyticsSyncState that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {AnalyticsSyncStateFindUniqueOrThrowArgs} args - Arguments to find a AnalyticsSyncState
     * @example
     * // Get one AnalyticsSyncState
     * const analyticsSyncState = await prisma.analyticsSyncState.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends AnalyticsSyncStateFindUniqueOrThrowArgs>(args: SelectSubset<T, AnalyticsSyncStateFindUniqueOrThrowArgs<ExtArgs>>): Prisma__AnalyticsSyncStateClient<$Result.GetResult<Prisma.$AnalyticsSyncStatePayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first AnalyticsSyncState that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AnalyticsSyncStateFindFirstArgs} args - Arguments to find a AnalyticsSyncState
     * @example
     * // Get one AnalyticsSyncState
     * const analyticsSyncState = await prisma.analyticsSyncState.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends AnalyticsSyncStateFindFirstArgs>(args?: SelectSubset<T, AnalyticsSyncStateFindFirstArgs<ExtArgs>>): Prisma__AnalyticsSyncStateClient<$Result.GetResult<Prisma.$AnalyticsSyncStatePayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first AnalyticsSyncState that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AnalyticsSyncStateFindFirstOrThrowArgs} args - Arguments to find a AnalyticsSyncState
     * @example
     * // Get one AnalyticsSyncState
     * const analyticsSyncState = await prisma.analyticsSyncState.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends AnalyticsSyncStateFindFirstOrThrowArgs>(args?: SelectSubset<T, AnalyticsSyncStateFindFirstOrThrowArgs<ExtArgs>>): Prisma__AnalyticsSyncStateClient<$Result.GetResult<Prisma.$AnalyticsSyncStatePayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more AnalyticsSyncStates that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AnalyticsSyncStateFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all AnalyticsSyncStates
     * const analyticsSyncStates = await prisma.analyticsSyncState.findMany()
     * 
     * // Get first 10 AnalyticsSyncStates
     * const analyticsSyncStates = await prisma.analyticsSyncState.findMany({ take: 10 })
     * 
     * // Only select the `clientId`
     * const analyticsSyncStateWithClientIdOnly = await prisma.analyticsSyncState.findMany({ select: { clientId: true } })
     * 
     */
    findMany<T extends AnalyticsSyncStateFindManyArgs>(args?: SelectSubset<T, AnalyticsSyncStateFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$AnalyticsSyncStatePayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a AnalyticsSyncState.
     * @param {AnalyticsSyncStateCreateArgs} args - Arguments to create a AnalyticsSyncState.
     * @example
     * // Create one AnalyticsSyncState
     * const AnalyticsSyncState = await prisma.analyticsSyncState.create({
     *   data: {
     *     // ... data to create a AnalyticsSyncState
     *   }
     * })
     * 
     */
    create<T extends AnalyticsSyncStateCreateArgs>(args: SelectSubset<T, AnalyticsSyncStateCreateArgs<ExtArgs>>): Prisma__AnalyticsSyncStateClient<$Result.GetResult<Prisma.$AnalyticsSyncStatePayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many AnalyticsSyncStates.
     * @param {AnalyticsSyncStateCreateManyArgs} args - Arguments to create many AnalyticsSyncStates.
     * @example
     * // Create many AnalyticsSyncStates
     * const analyticsSyncState = await prisma.analyticsSyncState.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends AnalyticsSyncStateCreateManyArgs>(args?: SelectSubset<T, AnalyticsSyncStateCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many AnalyticsSyncStates and returns the data saved in the database.
     * @param {AnalyticsSyncStateCreateManyAndReturnArgs} args - Arguments to create many AnalyticsSyncStates.
     * @example
     * // Create many AnalyticsSyncStates
     * const analyticsSyncState = await prisma.analyticsSyncState.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many AnalyticsSyncStates and only return the `clientId`
     * const analyticsSyncStateWithClientIdOnly = await prisma.analyticsSyncState.createManyAndReturn({
     *   select: { clientId: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends AnalyticsSyncStateCreateManyAndReturnArgs>(args?: SelectSubset<T, AnalyticsSyncStateCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$AnalyticsSyncStatePayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a AnalyticsSyncState.
     * @param {AnalyticsSyncStateDeleteArgs} args - Arguments to delete one AnalyticsSyncState.
     * @example
     * // Delete one AnalyticsSyncState
     * const AnalyticsSyncState = await prisma.analyticsSyncState.delete({
     *   where: {
     *     // ... filter to delete one AnalyticsSyncState
     *   }
     * })
     * 
     */
    delete<T extends AnalyticsSyncStateDeleteArgs>(args: SelectSubset<T, AnalyticsSyncStateDeleteArgs<ExtArgs>>): Prisma__AnalyticsSyncStateClient<$Result.GetResult<Prisma.$AnalyticsSyncStatePayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one AnalyticsSyncState.
     * @param {AnalyticsSyncStateUpdateArgs} args - Arguments to update one AnalyticsSyncState.
     * @example
     * // Update one AnalyticsSyncState
     * const analyticsSyncState = await prisma.analyticsSyncState.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends AnalyticsSyncStateUpdateArgs>(args: SelectSubset<T, AnalyticsSyncStateUpdateArgs<ExtArgs>>): Prisma__AnalyticsSyncStateClient<$Result.GetResult<Prisma.$AnalyticsSyncStatePayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more AnalyticsSyncStates.
     * @param {AnalyticsSyncStateDeleteManyArgs} args - Arguments to filter AnalyticsSyncStates to delete.
     * @example
     * // Delete a few AnalyticsSyncStates
     * const { count } = await prisma.analyticsSyncState.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends AnalyticsSyncStateDeleteManyArgs>(args?: SelectSubset<T, AnalyticsSyncStateDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more AnalyticsSyncStates.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AnalyticsSyncStateUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many AnalyticsSyncStates
     * const analyticsSyncState = await prisma.analyticsSyncState.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends AnalyticsSyncStateUpdateManyArgs>(args: SelectSubset<T, AnalyticsSyncStateUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more AnalyticsSyncStates and returns the data updated in the database.
     * @param {AnalyticsSyncStateUpdateManyAndReturnArgs} args - Arguments to update many AnalyticsSyncStates.
     * @example
     * // Update many AnalyticsSyncStates
     * const analyticsSyncState = await prisma.analyticsSyncState.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more AnalyticsSyncStates and only return the `clientId`
     * const analyticsSyncStateWithClientIdOnly = await prisma.analyticsSyncState.updateManyAndReturn({
     *   select: { clientId: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends AnalyticsSyncStateUpdateManyAndReturnArgs>(args: SelectSubset<T, AnalyticsSyncStateUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$AnalyticsSyncStatePayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one AnalyticsSyncState.
     * @param {AnalyticsSyncStateUpsertArgs} args - Arguments to update or create a AnalyticsSyncState.
     * @example
     * // Update or create a AnalyticsSyncState
     * const analyticsSyncState = await prisma.analyticsSyncState.upsert({
     *   create: {
     *     // ... data to create a AnalyticsSyncState
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the AnalyticsSyncState we want to update
     *   }
     * })
     */
    upsert<T extends AnalyticsSyncStateUpsertArgs>(args: SelectSubset<T, AnalyticsSyncStateUpsertArgs<ExtArgs>>): Prisma__AnalyticsSyncStateClient<$Result.GetResult<Prisma.$AnalyticsSyncStatePayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of AnalyticsSyncStates.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AnalyticsSyncStateCountArgs} args - Arguments to filter AnalyticsSyncStates to count.
     * @example
     * // Count the number of AnalyticsSyncStates
     * const count = await prisma.analyticsSyncState.count({
     *   where: {
     *     // ... the filter for the AnalyticsSyncStates we want to count
     *   }
     * })
    **/
    count<T extends AnalyticsSyncStateCountArgs>(
      args?: Subset<T, AnalyticsSyncStateCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], AnalyticsSyncStateCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a AnalyticsSyncState.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AnalyticsSyncStateAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends AnalyticsSyncStateAggregateArgs>(args: Subset<T, AnalyticsSyncStateAggregateArgs>): Prisma.PrismaPromise<GetAnalyticsSyncStateAggregateType<T>>

    /**
     * Group by AnalyticsSyncState.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AnalyticsSyncStateGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends AnalyticsSyncStateGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: AnalyticsSyncStateGroupByArgs['orderBy'] }
        : { orderBy?: AnalyticsSyncStateGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, AnalyticsSyncStateGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetAnalyticsSyncStateGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the AnalyticsSyncState model
   */
  readonly fields: AnalyticsSyncStateFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for AnalyticsSyncState.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__AnalyticsSyncStateClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the AnalyticsSyncState model
   */
  interface AnalyticsSyncStateFieldRefs {
    readonly clientId: FieldRef<"AnalyticsSyncState", 'String'>
    readonly marketplace: FieldRef<"AnalyticsSyncState", 'String'>
    readonly status: FieldRef<"AnalyticsSyncState", 'String'>
    readonly periodDays: FieldRef<"AnalyticsSyncState", 'Int'>
    readonly currency: FieldRef<"AnalyticsSyncState", 'String'>
    readonly productCount: FieldRef<"AnalyticsSyncState", 'Int'>
    readonly lastStartedAt: FieldRef<"AnalyticsSyncState", 'DateTime'>
    readonly lastSyncedAt: FieldRef<"AnalyticsSyncState", 'DateTime'>
    readonly lastError: FieldRef<"AnalyticsSyncState", 'String'>
    readonly sourceStatus: FieldRef<"AnalyticsSyncState", 'Json'>
    readonly createdAt: FieldRef<"AnalyticsSyncState", 'DateTime'>
    readonly updatedAt: FieldRef<"AnalyticsSyncState", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * AnalyticsSyncState findUnique
   */
  export type AnalyticsSyncStateFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AnalyticsSyncState
     */
    select?: AnalyticsSyncStateSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AnalyticsSyncState
     */
    omit?: AnalyticsSyncStateOmit<ExtArgs> | null
    /**
     * Filter, which AnalyticsSyncState to fetch.
     */
    where: AnalyticsSyncStateWhereUniqueInput
  }

  /**
   * AnalyticsSyncState findUniqueOrThrow
   */
  export type AnalyticsSyncStateFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AnalyticsSyncState
     */
    select?: AnalyticsSyncStateSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AnalyticsSyncState
     */
    omit?: AnalyticsSyncStateOmit<ExtArgs> | null
    /**
     * Filter, which AnalyticsSyncState to fetch.
     */
    where: AnalyticsSyncStateWhereUniqueInput
  }

  /**
   * AnalyticsSyncState findFirst
   */
  export type AnalyticsSyncStateFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AnalyticsSyncState
     */
    select?: AnalyticsSyncStateSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AnalyticsSyncState
     */
    omit?: AnalyticsSyncStateOmit<ExtArgs> | null
    /**
     * Filter, which AnalyticsSyncState to fetch.
     */
    where?: AnalyticsSyncStateWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of AnalyticsSyncStates to fetch.
     */
    orderBy?: AnalyticsSyncStateOrderByWithRelationInput | AnalyticsSyncStateOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for AnalyticsSyncStates.
     */
    cursor?: AnalyticsSyncStateWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` AnalyticsSyncStates from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` AnalyticsSyncStates.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of AnalyticsSyncStates.
     */
    distinct?: AnalyticsSyncStateScalarFieldEnum | AnalyticsSyncStateScalarFieldEnum[]
  }

  /**
   * AnalyticsSyncState findFirstOrThrow
   */
  export type AnalyticsSyncStateFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AnalyticsSyncState
     */
    select?: AnalyticsSyncStateSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AnalyticsSyncState
     */
    omit?: AnalyticsSyncStateOmit<ExtArgs> | null
    /**
     * Filter, which AnalyticsSyncState to fetch.
     */
    where?: AnalyticsSyncStateWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of AnalyticsSyncStates to fetch.
     */
    orderBy?: AnalyticsSyncStateOrderByWithRelationInput | AnalyticsSyncStateOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for AnalyticsSyncStates.
     */
    cursor?: AnalyticsSyncStateWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` AnalyticsSyncStates from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` AnalyticsSyncStates.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of AnalyticsSyncStates.
     */
    distinct?: AnalyticsSyncStateScalarFieldEnum | AnalyticsSyncStateScalarFieldEnum[]
  }

  /**
   * AnalyticsSyncState findMany
   */
  export type AnalyticsSyncStateFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AnalyticsSyncState
     */
    select?: AnalyticsSyncStateSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AnalyticsSyncState
     */
    omit?: AnalyticsSyncStateOmit<ExtArgs> | null
    /**
     * Filter, which AnalyticsSyncStates to fetch.
     */
    where?: AnalyticsSyncStateWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of AnalyticsSyncStates to fetch.
     */
    orderBy?: AnalyticsSyncStateOrderByWithRelationInput | AnalyticsSyncStateOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing AnalyticsSyncStates.
     */
    cursor?: AnalyticsSyncStateWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` AnalyticsSyncStates from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` AnalyticsSyncStates.
     */
    skip?: number
    distinct?: AnalyticsSyncStateScalarFieldEnum | AnalyticsSyncStateScalarFieldEnum[]
  }

  /**
   * AnalyticsSyncState create
   */
  export type AnalyticsSyncStateCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AnalyticsSyncState
     */
    select?: AnalyticsSyncStateSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AnalyticsSyncState
     */
    omit?: AnalyticsSyncStateOmit<ExtArgs> | null
    /**
     * The data needed to create a AnalyticsSyncState.
     */
    data: XOR<AnalyticsSyncStateCreateInput, AnalyticsSyncStateUncheckedCreateInput>
  }

  /**
   * AnalyticsSyncState createMany
   */
  export type AnalyticsSyncStateCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many AnalyticsSyncStates.
     */
    data: AnalyticsSyncStateCreateManyInput | AnalyticsSyncStateCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * AnalyticsSyncState createManyAndReturn
   */
  export type AnalyticsSyncStateCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AnalyticsSyncState
     */
    select?: AnalyticsSyncStateSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the AnalyticsSyncState
     */
    omit?: AnalyticsSyncStateOmit<ExtArgs> | null
    /**
     * The data used to create many AnalyticsSyncStates.
     */
    data: AnalyticsSyncStateCreateManyInput | AnalyticsSyncStateCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * AnalyticsSyncState update
   */
  export type AnalyticsSyncStateUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AnalyticsSyncState
     */
    select?: AnalyticsSyncStateSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AnalyticsSyncState
     */
    omit?: AnalyticsSyncStateOmit<ExtArgs> | null
    /**
     * The data needed to update a AnalyticsSyncState.
     */
    data: XOR<AnalyticsSyncStateUpdateInput, AnalyticsSyncStateUncheckedUpdateInput>
    /**
     * Choose, which AnalyticsSyncState to update.
     */
    where: AnalyticsSyncStateWhereUniqueInput
  }

  /**
   * AnalyticsSyncState updateMany
   */
  export type AnalyticsSyncStateUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update AnalyticsSyncStates.
     */
    data: XOR<AnalyticsSyncStateUpdateManyMutationInput, AnalyticsSyncStateUncheckedUpdateManyInput>
    /**
     * Filter which AnalyticsSyncStates to update
     */
    where?: AnalyticsSyncStateWhereInput
    /**
     * Limit how many AnalyticsSyncStates to update.
     */
    limit?: number
  }

  /**
   * AnalyticsSyncState updateManyAndReturn
   */
  export type AnalyticsSyncStateUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AnalyticsSyncState
     */
    select?: AnalyticsSyncStateSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the AnalyticsSyncState
     */
    omit?: AnalyticsSyncStateOmit<ExtArgs> | null
    /**
     * The data used to update AnalyticsSyncStates.
     */
    data: XOR<AnalyticsSyncStateUpdateManyMutationInput, AnalyticsSyncStateUncheckedUpdateManyInput>
    /**
     * Filter which AnalyticsSyncStates to update
     */
    where?: AnalyticsSyncStateWhereInput
    /**
     * Limit how many AnalyticsSyncStates to update.
     */
    limit?: number
  }

  /**
   * AnalyticsSyncState upsert
   */
  export type AnalyticsSyncStateUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AnalyticsSyncState
     */
    select?: AnalyticsSyncStateSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AnalyticsSyncState
     */
    omit?: AnalyticsSyncStateOmit<ExtArgs> | null
    /**
     * The filter to search for the AnalyticsSyncState to update in case it exists.
     */
    where: AnalyticsSyncStateWhereUniqueInput
    /**
     * In case the AnalyticsSyncState found by the `where` argument doesn't exist, create a new AnalyticsSyncState with this data.
     */
    create: XOR<AnalyticsSyncStateCreateInput, AnalyticsSyncStateUncheckedCreateInput>
    /**
     * In case the AnalyticsSyncState was found with the provided `where` argument, update it with this data.
     */
    update: XOR<AnalyticsSyncStateUpdateInput, AnalyticsSyncStateUncheckedUpdateInput>
  }

  /**
   * AnalyticsSyncState delete
   */
  export type AnalyticsSyncStateDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AnalyticsSyncState
     */
    select?: AnalyticsSyncStateSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AnalyticsSyncState
     */
    omit?: AnalyticsSyncStateOmit<ExtArgs> | null
    /**
     * Filter which AnalyticsSyncState to delete.
     */
    where: AnalyticsSyncStateWhereUniqueInput
  }

  /**
   * AnalyticsSyncState deleteMany
   */
  export type AnalyticsSyncStateDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which AnalyticsSyncStates to delete
     */
    where?: AnalyticsSyncStateWhereInput
    /**
     * Limit how many AnalyticsSyncStates to delete.
     */
    limit?: number
  }

  /**
   * AnalyticsSyncState without action
   */
  export type AnalyticsSyncStateDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AnalyticsSyncState
     */
    select?: AnalyticsSyncStateSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AnalyticsSyncState
     */
    omit?: AnalyticsSyncStateOmit<ExtArgs> | null
  }


  /**
   * Model AnalyticsProduct
   */

  export type AggregateAnalyticsProduct = {
    _count: AnalyticsProductCountAggregateOutputType | null
    _avg: AnalyticsProductAvgAggregateOutputType | null
    _sum: AnalyticsProductSumAggregateOutputType | null
    _min: AnalyticsProductMinAggregateOutputType | null
    _max: AnalyticsProductMaxAggregateOutputType | null
  }

  export type AnalyticsProductAvgAggregateOutputType = {
    stockCount: number | null
    stockSum: number | null
    avgOrders: number | null
    ordersCount: number | null
    ordersSum: number | null
    buyoutCount: number | null
    buyoutSum: number | null
    buyoutPercent: number | null
    lostOrdersCount: number | null
    lostOrdersSum: number | null
    lostBuyoutsCount: number | null
    lostBuyoutsSum: number | null
    turnoverDays: number | null
    saleRateDays: number | null
    currentPriceMin: number | null
    currentPriceMax: number | null
    openCount: number | null
    cartCount: number | null
    orderCount: number | null
    orderSum: number | null
    funnelBuyoutCount: number | null
    funnelBuyoutSum: number | null
    cancelCount: number | null
    cancelSum: number | null
    addToCartPercent: number | null
    cartToOrderPercent: number | null
    funnelBuyoutPercent: number | null
    orderCountDynamic: number | null
    orderSumDynamic: number | null
    openCountDynamic: number | null
    cartCountDynamic: number | null
  }

  export type AnalyticsProductSumAggregateOutputType = {
    stockCount: number | null
    stockSum: number | null
    avgOrders: number | null
    ordersCount: number | null
    ordersSum: number | null
    buyoutCount: number | null
    buyoutSum: number | null
    buyoutPercent: number | null
    lostOrdersCount: number | null
    lostOrdersSum: number | null
    lostBuyoutsCount: number | null
    lostBuyoutsSum: number | null
    turnoverDays: number | null
    saleRateDays: number | null
    currentPriceMin: number | null
    currentPriceMax: number | null
    openCount: number | null
    cartCount: number | null
    orderCount: number | null
    orderSum: number | null
    funnelBuyoutCount: number | null
    funnelBuyoutSum: number | null
    cancelCount: number | null
    cancelSum: number | null
    addToCartPercent: number | null
    cartToOrderPercent: number | null
    funnelBuyoutPercent: number | null
    orderCountDynamic: number | null
    orderSumDynamic: number | null
    openCountDynamic: number | null
    cartCountDynamic: number | null
  }

  export type AnalyticsProductMinAggregateOutputType = {
    clientId: string | null
    nmId: string | null
    name: string | null
    vendorCode: string | null
    brandName: string | null
    subjectName: string | null
    photoUrl: string | null
    availability: string | null
    stockCount: number | null
    stockSum: number | null
    avgOrders: number | null
    ordersCount: number | null
    ordersSum: number | null
    buyoutCount: number | null
    buyoutSum: number | null
    buyoutPercent: number | null
    lostOrdersCount: number | null
    lostOrdersSum: number | null
    lostBuyoutsCount: number | null
    lostBuyoutsSum: number | null
    turnoverDays: number | null
    saleRateDays: number | null
    currentPriceMin: number | null
    currentPriceMax: number | null
    openCount: number | null
    cartCount: number | null
    orderCount: number | null
    orderSum: number | null
    funnelBuyoutCount: number | null
    funnelBuyoutSum: number | null
    cancelCount: number | null
    cancelSum: number | null
    addToCartPercent: number | null
    cartToOrderPercent: number | null
    funnelBuyoutPercent: number | null
    orderCountDynamic: number | null
    orderSumDynamic: number | null
    openCountDynamic: number | null
    cartCountDynamic: number | null
    syncedAt: Date | null
  }

  export type AnalyticsProductMaxAggregateOutputType = {
    clientId: string | null
    nmId: string | null
    name: string | null
    vendorCode: string | null
    brandName: string | null
    subjectName: string | null
    photoUrl: string | null
    availability: string | null
    stockCount: number | null
    stockSum: number | null
    avgOrders: number | null
    ordersCount: number | null
    ordersSum: number | null
    buyoutCount: number | null
    buyoutSum: number | null
    buyoutPercent: number | null
    lostOrdersCount: number | null
    lostOrdersSum: number | null
    lostBuyoutsCount: number | null
    lostBuyoutsSum: number | null
    turnoverDays: number | null
    saleRateDays: number | null
    currentPriceMin: number | null
    currentPriceMax: number | null
    openCount: number | null
    cartCount: number | null
    orderCount: number | null
    orderSum: number | null
    funnelBuyoutCount: number | null
    funnelBuyoutSum: number | null
    cancelCount: number | null
    cancelSum: number | null
    addToCartPercent: number | null
    cartToOrderPercent: number | null
    funnelBuyoutPercent: number | null
    orderCountDynamic: number | null
    orderSumDynamic: number | null
    openCountDynamic: number | null
    cartCountDynamic: number | null
    syncedAt: Date | null
  }

  export type AnalyticsProductCountAggregateOutputType = {
    clientId: number
    nmId: number
    name: number
    vendorCode: number
    brandName: number
    subjectName: number
    photoUrl: number
    availability: number
    stockCount: number
    stockSum: number
    avgOrders: number
    ordersCount: number
    ordersSum: number
    buyoutCount: number
    buyoutSum: number
    buyoutPercent: number
    lostOrdersCount: number
    lostOrdersSum: number
    lostBuyoutsCount: number
    lostBuyoutsSum: number
    turnoverDays: number
    saleRateDays: number
    currentPriceMin: number
    currentPriceMax: number
    openCount: number
    cartCount: number
    orderCount: number
    orderSum: number
    funnelBuyoutCount: number
    funnelBuyoutSum: number
    cancelCount: number
    cancelSum: number
    addToCartPercent: number
    cartToOrderPercent: number
    funnelBuyoutPercent: number
    orderCountDynamic: number
    orderSumDynamic: number
    openCountDynamic: number
    cartCountDynamic: number
    selectedMetrics: number
    pastMetrics: number
    comparisonMetrics: number
    stockMetrics: number
    syncedAt: number
    _all: number
  }


  export type AnalyticsProductAvgAggregateInputType = {
    stockCount?: true
    stockSum?: true
    avgOrders?: true
    ordersCount?: true
    ordersSum?: true
    buyoutCount?: true
    buyoutSum?: true
    buyoutPercent?: true
    lostOrdersCount?: true
    lostOrdersSum?: true
    lostBuyoutsCount?: true
    lostBuyoutsSum?: true
    turnoverDays?: true
    saleRateDays?: true
    currentPriceMin?: true
    currentPriceMax?: true
    openCount?: true
    cartCount?: true
    orderCount?: true
    orderSum?: true
    funnelBuyoutCount?: true
    funnelBuyoutSum?: true
    cancelCount?: true
    cancelSum?: true
    addToCartPercent?: true
    cartToOrderPercent?: true
    funnelBuyoutPercent?: true
    orderCountDynamic?: true
    orderSumDynamic?: true
    openCountDynamic?: true
    cartCountDynamic?: true
  }

  export type AnalyticsProductSumAggregateInputType = {
    stockCount?: true
    stockSum?: true
    avgOrders?: true
    ordersCount?: true
    ordersSum?: true
    buyoutCount?: true
    buyoutSum?: true
    buyoutPercent?: true
    lostOrdersCount?: true
    lostOrdersSum?: true
    lostBuyoutsCount?: true
    lostBuyoutsSum?: true
    turnoverDays?: true
    saleRateDays?: true
    currentPriceMin?: true
    currentPriceMax?: true
    openCount?: true
    cartCount?: true
    orderCount?: true
    orderSum?: true
    funnelBuyoutCount?: true
    funnelBuyoutSum?: true
    cancelCount?: true
    cancelSum?: true
    addToCartPercent?: true
    cartToOrderPercent?: true
    funnelBuyoutPercent?: true
    orderCountDynamic?: true
    orderSumDynamic?: true
    openCountDynamic?: true
    cartCountDynamic?: true
  }

  export type AnalyticsProductMinAggregateInputType = {
    clientId?: true
    nmId?: true
    name?: true
    vendorCode?: true
    brandName?: true
    subjectName?: true
    photoUrl?: true
    availability?: true
    stockCount?: true
    stockSum?: true
    avgOrders?: true
    ordersCount?: true
    ordersSum?: true
    buyoutCount?: true
    buyoutSum?: true
    buyoutPercent?: true
    lostOrdersCount?: true
    lostOrdersSum?: true
    lostBuyoutsCount?: true
    lostBuyoutsSum?: true
    turnoverDays?: true
    saleRateDays?: true
    currentPriceMin?: true
    currentPriceMax?: true
    openCount?: true
    cartCount?: true
    orderCount?: true
    orderSum?: true
    funnelBuyoutCount?: true
    funnelBuyoutSum?: true
    cancelCount?: true
    cancelSum?: true
    addToCartPercent?: true
    cartToOrderPercent?: true
    funnelBuyoutPercent?: true
    orderCountDynamic?: true
    orderSumDynamic?: true
    openCountDynamic?: true
    cartCountDynamic?: true
    syncedAt?: true
  }

  export type AnalyticsProductMaxAggregateInputType = {
    clientId?: true
    nmId?: true
    name?: true
    vendorCode?: true
    brandName?: true
    subjectName?: true
    photoUrl?: true
    availability?: true
    stockCount?: true
    stockSum?: true
    avgOrders?: true
    ordersCount?: true
    ordersSum?: true
    buyoutCount?: true
    buyoutSum?: true
    buyoutPercent?: true
    lostOrdersCount?: true
    lostOrdersSum?: true
    lostBuyoutsCount?: true
    lostBuyoutsSum?: true
    turnoverDays?: true
    saleRateDays?: true
    currentPriceMin?: true
    currentPriceMax?: true
    openCount?: true
    cartCount?: true
    orderCount?: true
    orderSum?: true
    funnelBuyoutCount?: true
    funnelBuyoutSum?: true
    cancelCount?: true
    cancelSum?: true
    addToCartPercent?: true
    cartToOrderPercent?: true
    funnelBuyoutPercent?: true
    orderCountDynamic?: true
    orderSumDynamic?: true
    openCountDynamic?: true
    cartCountDynamic?: true
    syncedAt?: true
  }

  export type AnalyticsProductCountAggregateInputType = {
    clientId?: true
    nmId?: true
    name?: true
    vendorCode?: true
    brandName?: true
    subjectName?: true
    photoUrl?: true
    availability?: true
    stockCount?: true
    stockSum?: true
    avgOrders?: true
    ordersCount?: true
    ordersSum?: true
    buyoutCount?: true
    buyoutSum?: true
    buyoutPercent?: true
    lostOrdersCount?: true
    lostOrdersSum?: true
    lostBuyoutsCount?: true
    lostBuyoutsSum?: true
    turnoverDays?: true
    saleRateDays?: true
    currentPriceMin?: true
    currentPriceMax?: true
    openCount?: true
    cartCount?: true
    orderCount?: true
    orderSum?: true
    funnelBuyoutCount?: true
    funnelBuyoutSum?: true
    cancelCount?: true
    cancelSum?: true
    addToCartPercent?: true
    cartToOrderPercent?: true
    funnelBuyoutPercent?: true
    orderCountDynamic?: true
    orderSumDynamic?: true
    openCountDynamic?: true
    cartCountDynamic?: true
    selectedMetrics?: true
    pastMetrics?: true
    comparisonMetrics?: true
    stockMetrics?: true
    syncedAt?: true
    _all?: true
  }

  export type AnalyticsProductAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which AnalyticsProduct to aggregate.
     */
    where?: AnalyticsProductWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of AnalyticsProducts to fetch.
     */
    orderBy?: AnalyticsProductOrderByWithRelationInput | AnalyticsProductOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: AnalyticsProductWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` AnalyticsProducts from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` AnalyticsProducts.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned AnalyticsProducts
    **/
    _count?: true | AnalyticsProductCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: AnalyticsProductAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: AnalyticsProductSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: AnalyticsProductMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: AnalyticsProductMaxAggregateInputType
  }

  export type GetAnalyticsProductAggregateType<T extends AnalyticsProductAggregateArgs> = {
        [P in keyof T & keyof AggregateAnalyticsProduct]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateAnalyticsProduct[P]>
      : GetScalarType<T[P], AggregateAnalyticsProduct[P]>
  }




  export type AnalyticsProductGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: AnalyticsProductWhereInput
    orderBy?: AnalyticsProductOrderByWithAggregationInput | AnalyticsProductOrderByWithAggregationInput[]
    by: AnalyticsProductScalarFieldEnum[] | AnalyticsProductScalarFieldEnum
    having?: AnalyticsProductScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: AnalyticsProductCountAggregateInputType | true
    _avg?: AnalyticsProductAvgAggregateInputType
    _sum?: AnalyticsProductSumAggregateInputType
    _min?: AnalyticsProductMinAggregateInputType
    _max?: AnalyticsProductMaxAggregateInputType
  }

  export type AnalyticsProductGroupByOutputType = {
    clientId: string
    nmId: string
    name: string
    vendorCode: string | null
    brandName: string | null
    subjectName: string | null
    photoUrl: string | null
    availability: string | null
    stockCount: number
    stockSum: number
    avgOrders: number
    ordersCount: number
    ordersSum: number
    buyoutCount: number
    buyoutSum: number
    buyoutPercent: number
    lostOrdersCount: number
    lostOrdersSum: number
    lostBuyoutsCount: number
    lostBuyoutsSum: number
    turnoverDays: number | null
    saleRateDays: number | null
    currentPriceMin: number | null
    currentPriceMax: number | null
    openCount: number
    cartCount: number
    orderCount: number
    orderSum: number
    funnelBuyoutCount: number
    funnelBuyoutSum: number
    cancelCount: number
    cancelSum: number
    addToCartPercent: number
    cartToOrderPercent: number
    funnelBuyoutPercent: number
    orderCountDynamic: number
    orderSumDynamic: number
    openCountDynamic: number
    cartCountDynamic: number
    selectedMetrics: JsonValue | null
    pastMetrics: JsonValue | null
    comparisonMetrics: JsonValue | null
    stockMetrics: JsonValue | null
    syncedAt: Date
    _count: AnalyticsProductCountAggregateOutputType | null
    _avg: AnalyticsProductAvgAggregateOutputType | null
    _sum: AnalyticsProductSumAggregateOutputType | null
    _min: AnalyticsProductMinAggregateOutputType | null
    _max: AnalyticsProductMaxAggregateOutputType | null
  }

  type GetAnalyticsProductGroupByPayload<T extends AnalyticsProductGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<AnalyticsProductGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof AnalyticsProductGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], AnalyticsProductGroupByOutputType[P]>
            : GetScalarType<T[P], AnalyticsProductGroupByOutputType[P]>
        }
      >
    >


  export type AnalyticsProductSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    clientId?: boolean
    nmId?: boolean
    name?: boolean
    vendorCode?: boolean
    brandName?: boolean
    subjectName?: boolean
    photoUrl?: boolean
    availability?: boolean
    stockCount?: boolean
    stockSum?: boolean
    avgOrders?: boolean
    ordersCount?: boolean
    ordersSum?: boolean
    buyoutCount?: boolean
    buyoutSum?: boolean
    buyoutPercent?: boolean
    lostOrdersCount?: boolean
    lostOrdersSum?: boolean
    lostBuyoutsCount?: boolean
    lostBuyoutsSum?: boolean
    turnoverDays?: boolean
    saleRateDays?: boolean
    currentPriceMin?: boolean
    currentPriceMax?: boolean
    openCount?: boolean
    cartCount?: boolean
    orderCount?: boolean
    orderSum?: boolean
    funnelBuyoutCount?: boolean
    funnelBuyoutSum?: boolean
    cancelCount?: boolean
    cancelSum?: boolean
    addToCartPercent?: boolean
    cartToOrderPercent?: boolean
    funnelBuyoutPercent?: boolean
    orderCountDynamic?: boolean
    orderSumDynamic?: boolean
    openCountDynamic?: boolean
    cartCountDynamic?: boolean
    selectedMetrics?: boolean
    pastMetrics?: boolean
    comparisonMetrics?: boolean
    stockMetrics?: boolean
    syncedAt?: boolean
  }, ExtArgs["result"]["analyticsProduct"]>

  export type AnalyticsProductSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    clientId?: boolean
    nmId?: boolean
    name?: boolean
    vendorCode?: boolean
    brandName?: boolean
    subjectName?: boolean
    photoUrl?: boolean
    availability?: boolean
    stockCount?: boolean
    stockSum?: boolean
    avgOrders?: boolean
    ordersCount?: boolean
    ordersSum?: boolean
    buyoutCount?: boolean
    buyoutSum?: boolean
    buyoutPercent?: boolean
    lostOrdersCount?: boolean
    lostOrdersSum?: boolean
    lostBuyoutsCount?: boolean
    lostBuyoutsSum?: boolean
    turnoverDays?: boolean
    saleRateDays?: boolean
    currentPriceMin?: boolean
    currentPriceMax?: boolean
    openCount?: boolean
    cartCount?: boolean
    orderCount?: boolean
    orderSum?: boolean
    funnelBuyoutCount?: boolean
    funnelBuyoutSum?: boolean
    cancelCount?: boolean
    cancelSum?: boolean
    addToCartPercent?: boolean
    cartToOrderPercent?: boolean
    funnelBuyoutPercent?: boolean
    orderCountDynamic?: boolean
    orderSumDynamic?: boolean
    openCountDynamic?: boolean
    cartCountDynamic?: boolean
    selectedMetrics?: boolean
    pastMetrics?: boolean
    comparisonMetrics?: boolean
    stockMetrics?: boolean
    syncedAt?: boolean
  }, ExtArgs["result"]["analyticsProduct"]>

  export type AnalyticsProductSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    clientId?: boolean
    nmId?: boolean
    name?: boolean
    vendorCode?: boolean
    brandName?: boolean
    subjectName?: boolean
    photoUrl?: boolean
    availability?: boolean
    stockCount?: boolean
    stockSum?: boolean
    avgOrders?: boolean
    ordersCount?: boolean
    ordersSum?: boolean
    buyoutCount?: boolean
    buyoutSum?: boolean
    buyoutPercent?: boolean
    lostOrdersCount?: boolean
    lostOrdersSum?: boolean
    lostBuyoutsCount?: boolean
    lostBuyoutsSum?: boolean
    turnoverDays?: boolean
    saleRateDays?: boolean
    currentPriceMin?: boolean
    currentPriceMax?: boolean
    openCount?: boolean
    cartCount?: boolean
    orderCount?: boolean
    orderSum?: boolean
    funnelBuyoutCount?: boolean
    funnelBuyoutSum?: boolean
    cancelCount?: boolean
    cancelSum?: boolean
    addToCartPercent?: boolean
    cartToOrderPercent?: boolean
    funnelBuyoutPercent?: boolean
    orderCountDynamic?: boolean
    orderSumDynamic?: boolean
    openCountDynamic?: boolean
    cartCountDynamic?: boolean
    selectedMetrics?: boolean
    pastMetrics?: boolean
    comparisonMetrics?: boolean
    stockMetrics?: boolean
    syncedAt?: boolean
  }, ExtArgs["result"]["analyticsProduct"]>

  export type AnalyticsProductSelectScalar = {
    clientId?: boolean
    nmId?: boolean
    name?: boolean
    vendorCode?: boolean
    brandName?: boolean
    subjectName?: boolean
    photoUrl?: boolean
    availability?: boolean
    stockCount?: boolean
    stockSum?: boolean
    avgOrders?: boolean
    ordersCount?: boolean
    ordersSum?: boolean
    buyoutCount?: boolean
    buyoutSum?: boolean
    buyoutPercent?: boolean
    lostOrdersCount?: boolean
    lostOrdersSum?: boolean
    lostBuyoutsCount?: boolean
    lostBuyoutsSum?: boolean
    turnoverDays?: boolean
    saleRateDays?: boolean
    currentPriceMin?: boolean
    currentPriceMax?: boolean
    openCount?: boolean
    cartCount?: boolean
    orderCount?: boolean
    orderSum?: boolean
    funnelBuyoutCount?: boolean
    funnelBuyoutSum?: boolean
    cancelCount?: boolean
    cancelSum?: boolean
    addToCartPercent?: boolean
    cartToOrderPercent?: boolean
    funnelBuyoutPercent?: boolean
    orderCountDynamic?: boolean
    orderSumDynamic?: boolean
    openCountDynamic?: boolean
    cartCountDynamic?: boolean
    selectedMetrics?: boolean
    pastMetrics?: boolean
    comparisonMetrics?: boolean
    stockMetrics?: boolean
    syncedAt?: boolean
  }

  export type AnalyticsProductOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"clientId" | "nmId" | "name" | "vendorCode" | "brandName" | "subjectName" | "photoUrl" | "availability" | "stockCount" | "stockSum" | "avgOrders" | "ordersCount" | "ordersSum" | "buyoutCount" | "buyoutSum" | "buyoutPercent" | "lostOrdersCount" | "lostOrdersSum" | "lostBuyoutsCount" | "lostBuyoutsSum" | "turnoverDays" | "saleRateDays" | "currentPriceMin" | "currentPriceMax" | "openCount" | "cartCount" | "orderCount" | "orderSum" | "funnelBuyoutCount" | "funnelBuyoutSum" | "cancelCount" | "cancelSum" | "addToCartPercent" | "cartToOrderPercent" | "funnelBuyoutPercent" | "orderCountDynamic" | "orderSumDynamic" | "openCountDynamic" | "cartCountDynamic" | "selectedMetrics" | "pastMetrics" | "comparisonMetrics" | "stockMetrics" | "syncedAt", ExtArgs["result"]["analyticsProduct"]>

  export type $AnalyticsProductPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "AnalyticsProduct"
    objects: {}
    scalars: $Extensions.GetPayloadResult<{
      clientId: string
      nmId: string
      name: string
      vendorCode: string | null
      brandName: string | null
      subjectName: string | null
      photoUrl: string | null
      availability: string | null
      stockCount: number
      stockSum: number
      avgOrders: number
      ordersCount: number
      ordersSum: number
      buyoutCount: number
      buyoutSum: number
      buyoutPercent: number
      lostOrdersCount: number
      lostOrdersSum: number
      lostBuyoutsCount: number
      lostBuyoutsSum: number
      turnoverDays: number | null
      saleRateDays: number | null
      currentPriceMin: number | null
      currentPriceMax: number | null
      openCount: number
      cartCount: number
      orderCount: number
      orderSum: number
      funnelBuyoutCount: number
      funnelBuyoutSum: number
      cancelCount: number
      cancelSum: number
      addToCartPercent: number
      cartToOrderPercent: number
      funnelBuyoutPercent: number
      orderCountDynamic: number
      orderSumDynamic: number
      openCountDynamic: number
      cartCountDynamic: number
      selectedMetrics: Prisma.JsonValue | null
      pastMetrics: Prisma.JsonValue | null
      comparisonMetrics: Prisma.JsonValue | null
      stockMetrics: Prisma.JsonValue | null
      syncedAt: Date
    }, ExtArgs["result"]["analyticsProduct"]>
    composites: {}
  }

  type AnalyticsProductGetPayload<S extends boolean | null | undefined | AnalyticsProductDefaultArgs> = $Result.GetResult<Prisma.$AnalyticsProductPayload, S>

  type AnalyticsProductCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<AnalyticsProductFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: AnalyticsProductCountAggregateInputType | true
    }

  export interface AnalyticsProductDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['AnalyticsProduct'], meta: { name: 'AnalyticsProduct' } }
    /**
     * Find zero or one AnalyticsProduct that matches the filter.
     * @param {AnalyticsProductFindUniqueArgs} args - Arguments to find a AnalyticsProduct
     * @example
     * // Get one AnalyticsProduct
     * const analyticsProduct = await prisma.analyticsProduct.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends AnalyticsProductFindUniqueArgs>(args: SelectSubset<T, AnalyticsProductFindUniqueArgs<ExtArgs>>): Prisma__AnalyticsProductClient<$Result.GetResult<Prisma.$AnalyticsProductPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one AnalyticsProduct that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {AnalyticsProductFindUniqueOrThrowArgs} args - Arguments to find a AnalyticsProduct
     * @example
     * // Get one AnalyticsProduct
     * const analyticsProduct = await prisma.analyticsProduct.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends AnalyticsProductFindUniqueOrThrowArgs>(args: SelectSubset<T, AnalyticsProductFindUniqueOrThrowArgs<ExtArgs>>): Prisma__AnalyticsProductClient<$Result.GetResult<Prisma.$AnalyticsProductPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first AnalyticsProduct that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AnalyticsProductFindFirstArgs} args - Arguments to find a AnalyticsProduct
     * @example
     * // Get one AnalyticsProduct
     * const analyticsProduct = await prisma.analyticsProduct.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends AnalyticsProductFindFirstArgs>(args?: SelectSubset<T, AnalyticsProductFindFirstArgs<ExtArgs>>): Prisma__AnalyticsProductClient<$Result.GetResult<Prisma.$AnalyticsProductPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first AnalyticsProduct that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AnalyticsProductFindFirstOrThrowArgs} args - Arguments to find a AnalyticsProduct
     * @example
     * // Get one AnalyticsProduct
     * const analyticsProduct = await prisma.analyticsProduct.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends AnalyticsProductFindFirstOrThrowArgs>(args?: SelectSubset<T, AnalyticsProductFindFirstOrThrowArgs<ExtArgs>>): Prisma__AnalyticsProductClient<$Result.GetResult<Prisma.$AnalyticsProductPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more AnalyticsProducts that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AnalyticsProductFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all AnalyticsProducts
     * const analyticsProducts = await prisma.analyticsProduct.findMany()
     * 
     * // Get first 10 AnalyticsProducts
     * const analyticsProducts = await prisma.analyticsProduct.findMany({ take: 10 })
     * 
     * // Only select the `clientId`
     * const analyticsProductWithClientIdOnly = await prisma.analyticsProduct.findMany({ select: { clientId: true } })
     * 
     */
    findMany<T extends AnalyticsProductFindManyArgs>(args?: SelectSubset<T, AnalyticsProductFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$AnalyticsProductPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a AnalyticsProduct.
     * @param {AnalyticsProductCreateArgs} args - Arguments to create a AnalyticsProduct.
     * @example
     * // Create one AnalyticsProduct
     * const AnalyticsProduct = await prisma.analyticsProduct.create({
     *   data: {
     *     // ... data to create a AnalyticsProduct
     *   }
     * })
     * 
     */
    create<T extends AnalyticsProductCreateArgs>(args: SelectSubset<T, AnalyticsProductCreateArgs<ExtArgs>>): Prisma__AnalyticsProductClient<$Result.GetResult<Prisma.$AnalyticsProductPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many AnalyticsProducts.
     * @param {AnalyticsProductCreateManyArgs} args - Arguments to create many AnalyticsProducts.
     * @example
     * // Create many AnalyticsProducts
     * const analyticsProduct = await prisma.analyticsProduct.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends AnalyticsProductCreateManyArgs>(args?: SelectSubset<T, AnalyticsProductCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many AnalyticsProducts and returns the data saved in the database.
     * @param {AnalyticsProductCreateManyAndReturnArgs} args - Arguments to create many AnalyticsProducts.
     * @example
     * // Create many AnalyticsProducts
     * const analyticsProduct = await prisma.analyticsProduct.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many AnalyticsProducts and only return the `clientId`
     * const analyticsProductWithClientIdOnly = await prisma.analyticsProduct.createManyAndReturn({
     *   select: { clientId: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends AnalyticsProductCreateManyAndReturnArgs>(args?: SelectSubset<T, AnalyticsProductCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$AnalyticsProductPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a AnalyticsProduct.
     * @param {AnalyticsProductDeleteArgs} args - Arguments to delete one AnalyticsProduct.
     * @example
     * // Delete one AnalyticsProduct
     * const AnalyticsProduct = await prisma.analyticsProduct.delete({
     *   where: {
     *     // ... filter to delete one AnalyticsProduct
     *   }
     * })
     * 
     */
    delete<T extends AnalyticsProductDeleteArgs>(args: SelectSubset<T, AnalyticsProductDeleteArgs<ExtArgs>>): Prisma__AnalyticsProductClient<$Result.GetResult<Prisma.$AnalyticsProductPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one AnalyticsProduct.
     * @param {AnalyticsProductUpdateArgs} args - Arguments to update one AnalyticsProduct.
     * @example
     * // Update one AnalyticsProduct
     * const analyticsProduct = await prisma.analyticsProduct.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends AnalyticsProductUpdateArgs>(args: SelectSubset<T, AnalyticsProductUpdateArgs<ExtArgs>>): Prisma__AnalyticsProductClient<$Result.GetResult<Prisma.$AnalyticsProductPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more AnalyticsProducts.
     * @param {AnalyticsProductDeleteManyArgs} args - Arguments to filter AnalyticsProducts to delete.
     * @example
     * // Delete a few AnalyticsProducts
     * const { count } = await prisma.analyticsProduct.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends AnalyticsProductDeleteManyArgs>(args?: SelectSubset<T, AnalyticsProductDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more AnalyticsProducts.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AnalyticsProductUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many AnalyticsProducts
     * const analyticsProduct = await prisma.analyticsProduct.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends AnalyticsProductUpdateManyArgs>(args: SelectSubset<T, AnalyticsProductUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more AnalyticsProducts and returns the data updated in the database.
     * @param {AnalyticsProductUpdateManyAndReturnArgs} args - Arguments to update many AnalyticsProducts.
     * @example
     * // Update many AnalyticsProducts
     * const analyticsProduct = await prisma.analyticsProduct.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more AnalyticsProducts and only return the `clientId`
     * const analyticsProductWithClientIdOnly = await prisma.analyticsProduct.updateManyAndReturn({
     *   select: { clientId: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends AnalyticsProductUpdateManyAndReturnArgs>(args: SelectSubset<T, AnalyticsProductUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$AnalyticsProductPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one AnalyticsProduct.
     * @param {AnalyticsProductUpsertArgs} args - Arguments to update or create a AnalyticsProduct.
     * @example
     * // Update or create a AnalyticsProduct
     * const analyticsProduct = await prisma.analyticsProduct.upsert({
     *   create: {
     *     // ... data to create a AnalyticsProduct
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the AnalyticsProduct we want to update
     *   }
     * })
     */
    upsert<T extends AnalyticsProductUpsertArgs>(args: SelectSubset<T, AnalyticsProductUpsertArgs<ExtArgs>>): Prisma__AnalyticsProductClient<$Result.GetResult<Prisma.$AnalyticsProductPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of AnalyticsProducts.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AnalyticsProductCountArgs} args - Arguments to filter AnalyticsProducts to count.
     * @example
     * // Count the number of AnalyticsProducts
     * const count = await prisma.analyticsProduct.count({
     *   where: {
     *     // ... the filter for the AnalyticsProducts we want to count
     *   }
     * })
    **/
    count<T extends AnalyticsProductCountArgs>(
      args?: Subset<T, AnalyticsProductCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], AnalyticsProductCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a AnalyticsProduct.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AnalyticsProductAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends AnalyticsProductAggregateArgs>(args: Subset<T, AnalyticsProductAggregateArgs>): Prisma.PrismaPromise<GetAnalyticsProductAggregateType<T>>

    /**
     * Group by AnalyticsProduct.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AnalyticsProductGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends AnalyticsProductGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: AnalyticsProductGroupByArgs['orderBy'] }
        : { orderBy?: AnalyticsProductGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, AnalyticsProductGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetAnalyticsProductGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the AnalyticsProduct model
   */
  readonly fields: AnalyticsProductFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for AnalyticsProduct.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__AnalyticsProductClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the AnalyticsProduct model
   */
  interface AnalyticsProductFieldRefs {
    readonly clientId: FieldRef<"AnalyticsProduct", 'String'>
    readonly nmId: FieldRef<"AnalyticsProduct", 'String'>
    readonly name: FieldRef<"AnalyticsProduct", 'String'>
    readonly vendorCode: FieldRef<"AnalyticsProduct", 'String'>
    readonly brandName: FieldRef<"AnalyticsProduct", 'String'>
    readonly subjectName: FieldRef<"AnalyticsProduct", 'String'>
    readonly photoUrl: FieldRef<"AnalyticsProduct", 'String'>
    readonly availability: FieldRef<"AnalyticsProduct", 'String'>
    readonly stockCount: FieldRef<"AnalyticsProduct", 'Float'>
    readonly stockSum: FieldRef<"AnalyticsProduct", 'Float'>
    readonly avgOrders: FieldRef<"AnalyticsProduct", 'Float'>
    readonly ordersCount: FieldRef<"AnalyticsProduct", 'Float'>
    readonly ordersSum: FieldRef<"AnalyticsProduct", 'Float'>
    readonly buyoutCount: FieldRef<"AnalyticsProduct", 'Float'>
    readonly buyoutSum: FieldRef<"AnalyticsProduct", 'Float'>
    readonly buyoutPercent: FieldRef<"AnalyticsProduct", 'Float'>
    readonly lostOrdersCount: FieldRef<"AnalyticsProduct", 'Float'>
    readonly lostOrdersSum: FieldRef<"AnalyticsProduct", 'Float'>
    readonly lostBuyoutsCount: FieldRef<"AnalyticsProduct", 'Float'>
    readonly lostBuyoutsSum: FieldRef<"AnalyticsProduct", 'Float'>
    readonly turnoverDays: FieldRef<"AnalyticsProduct", 'Float'>
    readonly saleRateDays: FieldRef<"AnalyticsProduct", 'Float'>
    readonly currentPriceMin: FieldRef<"AnalyticsProduct", 'Float'>
    readonly currentPriceMax: FieldRef<"AnalyticsProduct", 'Float'>
    readonly openCount: FieldRef<"AnalyticsProduct", 'Float'>
    readonly cartCount: FieldRef<"AnalyticsProduct", 'Float'>
    readonly orderCount: FieldRef<"AnalyticsProduct", 'Float'>
    readonly orderSum: FieldRef<"AnalyticsProduct", 'Float'>
    readonly funnelBuyoutCount: FieldRef<"AnalyticsProduct", 'Float'>
    readonly funnelBuyoutSum: FieldRef<"AnalyticsProduct", 'Float'>
    readonly cancelCount: FieldRef<"AnalyticsProduct", 'Float'>
    readonly cancelSum: FieldRef<"AnalyticsProduct", 'Float'>
    readonly addToCartPercent: FieldRef<"AnalyticsProduct", 'Float'>
    readonly cartToOrderPercent: FieldRef<"AnalyticsProduct", 'Float'>
    readonly funnelBuyoutPercent: FieldRef<"AnalyticsProduct", 'Float'>
    readonly orderCountDynamic: FieldRef<"AnalyticsProduct", 'Float'>
    readonly orderSumDynamic: FieldRef<"AnalyticsProduct", 'Float'>
    readonly openCountDynamic: FieldRef<"AnalyticsProduct", 'Float'>
    readonly cartCountDynamic: FieldRef<"AnalyticsProduct", 'Float'>
    readonly selectedMetrics: FieldRef<"AnalyticsProduct", 'Json'>
    readonly pastMetrics: FieldRef<"AnalyticsProduct", 'Json'>
    readonly comparisonMetrics: FieldRef<"AnalyticsProduct", 'Json'>
    readonly stockMetrics: FieldRef<"AnalyticsProduct", 'Json'>
    readonly syncedAt: FieldRef<"AnalyticsProduct", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * AnalyticsProduct findUnique
   */
  export type AnalyticsProductFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AnalyticsProduct
     */
    select?: AnalyticsProductSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AnalyticsProduct
     */
    omit?: AnalyticsProductOmit<ExtArgs> | null
    /**
     * Filter, which AnalyticsProduct to fetch.
     */
    where: AnalyticsProductWhereUniqueInput
  }

  /**
   * AnalyticsProduct findUniqueOrThrow
   */
  export type AnalyticsProductFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AnalyticsProduct
     */
    select?: AnalyticsProductSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AnalyticsProduct
     */
    omit?: AnalyticsProductOmit<ExtArgs> | null
    /**
     * Filter, which AnalyticsProduct to fetch.
     */
    where: AnalyticsProductWhereUniqueInput
  }

  /**
   * AnalyticsProduct findFirst
   */
  export type AnalyticsProductFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AnalyticsProduct
     */
    select?: AnalyticsProductSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AnalyticsProduct
     */
    omit?: AnalyticsProductOmit<ExtArgs> | null
    /**
     * Filter, which AnalyticsProduct to fetch.
     */
    where?: AnalyticsProductWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of AnalyticsProducts to fetch.
     */
    orderBy?: AnalyticsProductOrderByWithRelationInput | AnalyticsProductOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for AnalyticsProducts.
     */
    cursor?: AnalyticsProductWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` AnalyticsProducts from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` AnalyticsProducts.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of AnalyticsProducts.
     */
    distinct?: AnalyticsProductScalarFieldEnum | AnalyticsProductScalarFieldEnum[]
  }

  /**
   * AnalyticsProduct findFirstOrThrow
   */
  export type AnalyticsProductFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AnalyticsProduct
     */
    select?: AnalyticsProductSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AnalyticsProduct
     */
    omit?: AnalyticsProductOmit<ExtArgs> | null
    /**
     * Filter, which AnalyticsProduct to fetch.
     */
    where?: AnalyticsProductWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of AnalyticsProducts to fetch.
     */
    orderBy?: AnalyticsProductOrderByWithRelationInput | AnalyticsProductOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for AnalyticsProducts.
     */
    cursor?: AnalyticsProductWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` AnalyticsProducts from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` AnalyticsProducts.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of AnalyticsProducts.
     */
    distinct?: AnalyticsProductScalarFieldEnum | AnalyticsProductScalarFieldEnum[]
  }

  /**
   * AnalyticsProduct findMany
   */
  export type AnalyticsProductFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AnalyticsProduct
     */
    select?: AnalyticsProductSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AnalyticsProduct
     */
    omit?: AnalyticsProductOmit<ExtArgs> | null
    /**
     * Filter, which AnalyticsProducts to fetch.
     */
    where?: AnalyticsProductWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of AnalyticsProducts to fetch.
     */
    orderBy?: AnalyticsProductOrderByWithRelationInput | AnalyticsProductOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing AnalyticsProducts.
     */
    cursor?: AnalyticsProductWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` AnalyticsProducts from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` AnalyticsProducts.
     */
    skip?: number
    distinct?: AnalyticsProductScalarFieldEnum | AnalyticsProductScalarFieldEnum[]
  }

  /**
   * AnalyticsProduct create
   */
  export type AnalyticsProductCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AnalyticsProduct
     */
    select?: AnalyticsProductSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AnalyticsProduct
     */
    omit?: AnalyticsProductOmit<ExtArgs> | null
    /**
     * The data needed to create a AnalyticsProduct.
     */
    data: XOR<AnalyticsProductCreateInput, AnalyticsProductUncheckedCreateInput>
  }

  /**
   * AnalyticsProduct createMany
   */
  export type AnalyticsProductCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many AnalyticsProducts.
     */
    data: AnalyticsProductCreateManyInput | AnalyticsProductCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * AnalyticsProduct createManyAndReturn
   */
  export type AnalyticsProductCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AnalyticsProduct
     */
    select?: AnalyticsProductSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the AnalyticsProduct
     */
    omit?: AnalyticsProductOmit<ExtArgs> | null
    /**
     * The data used to create many AnalyticsProducts.
     */
    data: AnalyticsProductCreateManyInput | AnalyticsProductCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * AnalyticsProduct update
   */
  export type AnalyticsProductUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AnalyticsProduct
     */
    select?: AnalyticsProductSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AnalyticsProduct
     */
    omit?: AnalyticsProductOmit<ExtArgs> | null
    /**
     * The data needed to update a AnalyticsProduct.
     */
    data: XOR<AnalyticsProductUpdateInput, AnalyticsProductUncheckedUpdateInput>
    /**
     * Choose, which AnalyticsProduct to update.
     */
    where: AnalyticsProductWhereUniqueInput
  }

  /**
   * AnalyticsProduct updateMany
   */
  export type AnalyticsProductUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update AnalyticsProducts.
     */
    data: XOR<AnalyticsProductUpdateManyMutationInput, AnalyticsProductUncheckedUpdateManyInput>
    /**
     * Filter which AnalyticsProducts to update
     */
    where?: AnalyticsProductWhereInput
    /**
     * Limit how many AnalyticsProducts to update.
     */
    limit?: number
  }

  /**
   * AnalyticsProduct updateManyAndReturn
   */
  export type AnalyticsProductUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AnalyticsProduct
     */
    select?: AnalyticsProductSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the AnalyticsProduct
     */
    omit?: AnalyticsProductOmit<ExtArgs> | null
    /**
     * The data used to update AnalyticsProducts.
     */
    data: XOR<AnalyticsProductUpdateManyMutationInput, AnalyticsProductUncheckedUpdateManyInput>
    /**
     * Filter which AnalyticsProducts to update
     */
    where?: AnalyticsProductWhereInput
    /**
     * Limit how many AnalyticsProducts to update.
     */
    limit?: number
  }

  /**
   * AnalyticsProduct upsert
   */
  export type AnalyticsProductUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AnalyticsProduct
     */
    select?: AnalyticsProductSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AnalyticsProduct
     */
    omit?: AnalyticsProductOmit<ExtArgs> | null
    /**
     * The filter to search for the AnalyticsProduct to update in case it exists.
     */
    where: AnalyticsProductWhereUniqueInput
    /**
     * In case the AnalyticsProduct found by the `where` argument doesn't exist, create a new AnalyticsProduct with this data.
     */
    create: XOR<AnalyticsProductCreateInput, AnalyticsProductUncheckedCreateInput>
    /**
     * In case the AnalyticsProduct was found with the provided `where` argument, update it with this data.
     */
    update: XOR<AnalyticsProductUpdateInput, AnalyticsProductUncheckedUpdateInput>
  }

  /**
   * AnalyticsProduct delete
   */
  export type AnalyticsProductDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AnalyticsProduct
     */
    select?: AnalyticsProductSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AnalyticsProduct
     */
    omit?: AnalyticsProductOmit<ExtArgs> | null
    /**
     * Filter which AnalyticsProduct to delete.
     */
    where: AnalyticsProductWhereUniqueInput
  }

  /**
   * AnalyticsProduct deleteMany
   */
  export type AnalyticsProductDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which AnalyticsProducts to delete
     */
    where?: AnalyticsProductWhereInput
    /**
     * Limit how many AnalyticsProducts to delete.
     */
    limit?: number
  }

  /**
   * AnalyticsProduct without action
   */
  export type AnalyticsProductDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AnalyticsProduct
     */
    select?: AnalyticsProductSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AnalyticsProduct
     */
    omit?: AnalyticsProductOmit<ExtArgs> | null
  }


  /**
   * Model AnalyticsRegion
   */

  export type AggregateAnalyticsRegion = {
    _count: AnalyticsRegionCountAggregateOutputType | null
    _avg: AnalyticsRegionAvgAggregateOutputType | null
    _sum: AnalyticsRegionSumAggregateOutputType | null
    _min: AnalyticsRegionMinAggregateOutputType | null
    _max: AnalyticsRegionMaxAggregateOutputType | null
  }

  export type AnalyticsRegionAvgAggregateOutputType = {
    stockCount: number | null
    stockSum: number | null
    toClientCount: number | null
    fromClientCount: number | null
    saleRateDays: number | null
  }

  export type AnalyticsRegionSumAggregateOutputType = {
    stockCount: number | null
    stockSum: number | null
    toClientCount: number | null
    fromClientCount: number | null
    saleRateDays: number | null
  }

  export type AnalyticsRegionMinAggregateOutputType = {
    clientId: string | null
    regionKey: string | null
    regionName: string | null
    officeId: string | null
    officeName: string | null
    stockCount: number | null
    stockSum: number | null
    toClientCount: number | null
    fromClientCount: number | null
    saleRateDays: number | null
    syncedAt: Date | null
  }

  export type AnalyticsRegionMaxAggregateOutputType = {
    clientId: string | null
    regionKey: string | null
    regionName: string | null
    officeId: string | null
    officeName: string | null
    stockCount: number | null
    stockSum: number | null
    toClientCount: number | null
    fromClientCount: number | null
    saleRateDays: number | null
    syncedAt: Date | null
  }

  export type AnalyticsRegionCountAggregateOutputType = {
    clientId: number
    regionKey: number
    regionName: number
    officeId: number
    officeName: number
    stockCount: number
    stockSum: number
    toClientCount: number
    fromClientCount: number
    saleRateDays: number
    metrics: number
    syncedAt: number
    _all: number
  }


  export type AnalyticsRegionAvgAggregateInputType = {
    stockCount?: true
    stockSum?: true
    toClientCount?: true
    fromClientCount?: true
    saleRateDays?: true
  }

  export type AnalyticsRegionSumAggregateInputType = {
    stockCount?: true
    stockSum?: true
    toClientCount?: true
    fromClientCount?: true
    saleRateDays?: true
  }

  export type AnalyticsRegionMinAggregateInputType = {
    clientId?: true
    regionKey?: true
    regionName?: true
    officeId?: true
    officeName?: true
    stockCount?: true
    stockSum?: true
    toClientCount?: true
    fromClientCount?: true
    saleRateDays?: true
    syncedAt?: true
  }

  export type AnalyticsRegionMaxAggregateInputType = {
    clientId?: true
    regionKey?: true
    regionName?: true
    officeId?: true
    officeName?: true
    stockCount?: true
    stockSum?: true
    toClientCount?: true
    fromClientCount?: true
    saleRateDays?: true
    syncedAt?: true
  }

  export type AnalyticsRegionCountAggregateInputType = {
    clientId?: true
    regionKey?: true
    regionName?: true
    officeId?: true
    officeName?: true
    stockCount?: true
    stockSum?: true
    toClientCount?: true
    fromClientCount?: true
    saleRateDays?: true
    metrics?: true
    syncedAt?: true
    _all?: true
  }

  export type AnalyticsRegionAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which AnalyticsRegion to aggregate.
     */
    where?: AnalyticsRegionWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of AnalyticsRegions to fetch.
     */
    orderBy?: AnalyticsRegionOrderByWithRelationInput | AnalyticsRegionOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: AnalyticsRegionWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` AnalyticsRegions from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` AnalyticsRegions.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned AnalyticsRegions
    **/
    _count?: true | AnalyticsRegionCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: AnalyticsRegionAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: AnalyticsRegionSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: AnalyticsRegionMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: AnalyticsRegionMaxAggregateInputType
  }

  export type GetAnalyticsRegionAggregateType<T extends AnalyticsRegionAggregateArgs> = {
        [P in keyof T & keyof AggregateAnalyticsRegion]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateAnalyticsRegion[P]>
      : GetScalarType<T[P], AggregateAnalyticsRegion[P]>
  }




  export type AnalyticsRegionGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: AnalyticsRegionWhereInput
    orderBy?: AnalyticsRegionOrderByWithAggregationInput | AnalyticsRegionOrderByWithAggregationInput[]
    by: AnalyticsRegionScalarFieldEnum[] | AnalyticsRegionScalarFieldEnum
    having?: AnalyticsRegionScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: AnalyticsRegionCountAggregateInputType | true
    _avg?: AnalyticsRegionAvgAggregateInputType
    _sum?: AnalyticsRegionSumAggregateInputType
    _min?: AnalyticsRegionMinAggregateInputType
    _max?: AnalyticsRegionMaxAggregateInputType
  }

  export type AnalyticsRegionGroupByOutputType = {
    clientId: string
    regionKey: string
    regionName: string
    officeId: string | null
    officeName: string | null
    stockCount: number
    stockSum: number
    toClientCount: number
    fromClientCount: number
    saleRateDays: number | null
    metrics: JsonValue | null
    syncedAt: Date
    _count: AnalyticsRegionCountAggregateOutputType | null
    _avg: AnalyticsRegionAvgAggregateOutputType | null
    _sum: AnalyticsRegionSumAggregateOutputType | null
    _min: AnalyticsRegionMinAggregateOutputType | null
    _max: AnalyticsRegionMaxAggregateOutputType | null
  }

  type GetAnalyticsRegionGroupByPayload<T extends AnalyticsRegionGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<AnalyticsRegionGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof AnalyticsRegionGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], AnalyticsRegionGroupByOutputType[P]>
            : GetScalarType<T[P], AnalyticsRegionGroupByOutputType[P]>
        }
      >
    >


  export type AnalyticsRegionSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    clientId?: boolean
    regionKey?: boolean
    regionName?: boolean
    officeId?: boolean
    officeName?: boolean
    stockCount?: boolean
    stockSum?: boolean
    toClientCount?: boolean
    fromClientCount?: boolean
    saleRateDays?: boolean
    metrics?: boolean
    syncedAt?: boolean
  }, ExtArgs["result"]["analyticsRegion"]>

  export type AnalyticsRegionSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    clientId?: boolean
    regionKey?: boolean
    regionName?: boolean
    officeId?: boolean
    officeName?: boolean
    stockCount?: boolean
    stockSum?: boolean
    toClientCount?: boolean
    fromClientCount?: boolean
    saleRateDays?: boolean
    metrics?: boolean
    syncedAt?: boolean
  }, ExtArgs["result"]["analyticsRegion"]>

  export type AnalyticsRegionSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    clientId?: boolean
    regionKey?: boolean
    regionName?: boolean
    officeId?: boolean
    officeName?: boolean
    stockCount?: boolean
    stockSum?: boolean
    toClientCount?: boolean
    fromClientCount?: boolean
    saleRateDays?: boolean
    metrics?: boolean
    syncedAt?: boolean
  }, ExtArgs["result"]["analyticsRegion"]>

  export type AnalyticsRegionSelectScalar = {
    clientId?: boolean
    regionKey?: boolean
    regionName?: boolean
    officeId?: boolean
    officeName?: boolean
    stockCount?: boolean
    stockSum?: boolean
    toClientCount?: boolean
    fromClientCount?: boolean
    saleRateDays?: boolean
    metrics?: boolean
    syncedAt?: boolean
  }

  export type AnalyticsRegionOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"clientId" | "regionKey" | "regionName" | "officeId" | "officeName" | "stockCount" | "stockSum" | "toClientCount" | "fromClientCount" | "saleRateDays" | "metrics" | "syncedAt", ExtArgs["result"]["analyticsRegion"]>

  export type $AnalyticsRegionPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "AnalyticsRegion"
    objects: {}
    scalars: $Extensions.GetPayloadResult<{
      clientId: string
      regionKey: string
      regionName: string
      officeId: string | null
      officeName: string | null
      stockCount: number
      stockSum: number
      toClientCount: number
      fromClientCount: number
      saleRateDays: number | null
      metrics: Prisma.JsonValue | null
      syncedAt: Date
    }, ExtArgs["result"]["analyticsRegion"]>
    composites: {}
  }

  type AnalyticsRegionGetPayload<S extends boolean | null | undefined | AnalyticsRegionDefaultArgs> = $Result.GetResult<Prisma.$AnalyticsRegionPayload, S>

  type AnalyticsRegionCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<AnalyticsRegionFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: AnalyticsRegionCountAggregateInputType | true
    }

  export interface AnalyticsRegionDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['AnalyticsRegion'], meta: { name: 'AnalyticsRegion' } }
    /**
     * Find zero or one AnalyticsRegion that matches the filter.
     * @param {AnalyticsRegionFindUniqueArgs} args - Arguments to find a AnalyticsRegion
     * @example
     * // Get one AnalyticsRegion
     * const analyticsRegion = await prisma.analyticsRegion.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends AnalyticsRegionFindUniqueArgs>(args: SelectSubset<T, AnalyticsRegionFindUniqueArgs<ExtArgs>>): Prisma__AnalyticsRegionClient<$Result.GetResult<Prisma.$AnalyticsRegionPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one AnalyticsRegion that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {AnalyticsRegionFindUniqueOrThrowArgs} args - Arguments to find a AnalyticsRegion
     * @example
     * // Get one AnalyticsRegion
     * const analyticsRegion = await prisma.analyticsRegion.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends AnalyticsRegionFindUniqueOrThrowArgs>(args: SelectSubset<T, AnalyticsRegionFindUniqueOrThrowArgs<ExtArgs>>): Prisma__AnalyticsRegionClient<$Result.GetResult<Prisma.$AnalyticsRegionPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first AnalyticsRegion that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AnalyticsRegionFindFirstArgs} args - Arguments to find a AnalyticsRegion
     * @example
     * // Get one AnalyticsRegion
     * const analyticsRegion = await prisma.analyticsRegion.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends AnalyticsRegionFindFirstArgs>(args?: SelectSubset<T, AnalyticsRegionFindFirstArgs<ExtArgs>>): Prisma__AnalyticsRegionClient<$Result.GetResult<Prisma.$AnalyticsRegionPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first AnalyticsRegion that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AnalyticsRegionFindFirstOrThrowArgs} args - Arguments to find a AnalyticsRegion
     * @example
     * // Get one AnalyticsRegion
     * const analyticsRegion = await prisma.analyticsRegion.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends AnalyticsRegionFindFirstOrThrowArgs>(args?: SelectSubset<T, AnalyticsRegionFindFirstOrThrowArgs<ExtArgs>>): Prisma__AnalyticsRegionClient<$Result.GetResult<Prisma.$AnalyticsRegionPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more AnalyticsRegions that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AnalyticsRegionFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all AnalyticsRegions
     * const analyticsRegions = await prisma.analyticsRegion.findMany()
     * 
     * // Get first 10 AnalyticsRegions
     * const analyticsRegions = await prisma.analyticsRegion.findMany({ take: 10 })
     * 
     * // Only select the `clientId`
     * const analyticsRegionWithClientIdOnly = await prisma.analyticsRegion.findMany({ select: { clientId: true } })
     * 
     */
    findMany<T extends AnalyticsRegionFindManyArgs>(args?: SelectSubset<T, AnalyticsRegionFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$AnalyticsRegionPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a AnalyticsRegion.
     * @param {AnalyticsRegionCreateArgs} args - Arguments to create a AnalyticsRegion.
     * @example
     * // Create one AnalyticsRegion
     * const AnalyticsRegion = await prisma.analyticsRegion.create({
     *   data: {
     *     // ... data to create a AnalyticsRegion
     *   }
     * })
     * 
     */
    create<T extends AnalyticsRegionCreateArgs>(args: SelectSubset<T, AnalyticsRegionCreateArgs<ExtArgs>>): Prisma__AnalyticsRegionClient<$Result.GetResult<Prisma.$AnalyticsRegionPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many AnalyticsRegions.
     * @param {AnalyticsRegionCreateManyArgs} args - Arguments to create many AnalyticsRegions.
     * @example
     * // Create many AnalyticsRegions
     * const analyticsRegion = await prisma.analyticsRegion.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends AnalyticsRegionCreateManyArgs>(args?: SelectSubset<T, AnalyticsRegionCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many AnalyticsRegions and returns the data saved in the database.
     * @param {AnalyticsRegionCreateManyAndReturnArgs} args - Arguments to create many AnalyticsRegions.
     * @example
     * // Create many AnalyticsRegions
     * const analyticsRegion = await prisma.analyticsRegion.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many AnalyticsRegions and only return the `clientId`
     * const analyticsRegionWithClientIdOnly = await prisma.analyticsRegion.createManyAndReturn({
     *   select: { clientId: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends AnalyticsRegionCreateManyAndReturnArgs>(args?: SelectSubset<T, AnalyticsRegionCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$AnalyticsRegionPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a AnalyticsRegion.
     * @param {AnalyticsRegionDeleteArgs} args - Arguments to delete one AnalyticsRegion.
     * @example
     * // Delete one AnalyticsRegion
     * const AnalyticsRegion = await prisma.analyticsRegion.delete({
     *   where: {
     *     // ... filter to delete one AnalyticsRegion
     *   }
     * })
     * 
     */
    delete<T extends AnalyticsRegionDeleteArgs>(args: SelectSubset<T, AnalyticsRegionDeleteArgs<ExtArgs>>): Prisma__AnalyticsRegionClient<$Result.GetResult<Prisma.$AnalyticsRegionPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one AnalyticsRegion.
     * @param {AnalyticsRegionUpdateArgs} args - Arguments to update one AnalyticsRegion.
     * @example
     * // Update one AnalyticsRegion
     * const analyticsRegion = await prisma.analyticsRegion.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends AnalyticsRegionUpdateArgs>(args: SelectSubset<T, AnalyticsRegionUpdateArgs<ExtArgs>>): Prisma__AnalyticsRegionClient<$Result.GetResult<Prisma.$AnalyticsRegionPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more AnalyticsRegions.
     * @param {AnalyticsRegionDeleteManyArgs} args - Arguments to filter AnalyticsRegions to delete.
     * @example
     * // Delete a few AnalyticsRegions
     * const { count } = await prisma.analyticsRegion.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends AnalyticsRegionDeleteManyArgs>(args?: SelectSubset<T, AnalyticsRegionDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more AnalyticsRegions.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AnalyticsRegionUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many AnalyticsRegions
     * const analyticsRegion = await prisma.analyticsRegion.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends AnalyticsRegionUpdateManyArgs>(args: SelectSubset<T, AnalyticsRegionUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more AnalyticsRegions and returns the data updated in the database.
     * @param {AnalyticsRegionUpdateManyAndReturnArgs} args - Arguments to update many AnalyticsRegions.
     * @example
     * // Update many AnalyticsRegions
     * const analyticsRegion = await prisma.analyticsRegion.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more AnalyticsRegions and only return the `clientId`
     * const analyticsRegionWithClientIdOnly = await prisma.analyticsRegion.updateManyAndReturn({
     *   select: { clientId: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends AnalyticsRegionUpdateManyAndReturnArgs>(args: SelectSubset<T, AnalyticsRegionUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$AnalyticsRegionPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one AnalyticsRegion.
     * @param {AnalyticsRegionUpsertArgs} args - Arguments to update or create a AnalyticsRegion.
     * @example
     * // Update or create a AnalyticsRegion
     * const analyticsRegion = await prisma.analyticsRegion.upsert({
     *   create: {
     *     // ... data to create a AnalyticsRegion
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the AnalyticsRegion we want to update
     *   }
     * })
     */
    upsert<T extends AnalyticsRegionUpsertArgs>(args: SelectSubset<T, AnalyticsRegionUpsertArgs<ExtArgs>>): Prisma__AnalyticsRegionClient<$Result.GetResult<Prisma.$AnalyticsRegionPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of AnalyticsRegions.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AnalyticsRegionCountArgs} args - Arguments to filter AnalyticsRegions to count.
     * @example
     * // Count the number of AnalyticsRegions
     * const count = await prisma.analyticsRegion.count({
     *   where: {
     *     // ... the filter for the AnalyticsRegions we want to count
     *   }
     * })
    **/
    count<T extends AnalyticsRegionCountArgs>(
      args?: Subset<T, AnalyticsRegionCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], AnalyticsRegionCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a AnalyticsRegion.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AnalyticsRegionAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends AnalyticsRegionAggregateArgs>(args: Subset<T, AnalyticsRegionAggregateArgs>): Prisma.PrismaPromise<GetAnalyticsRegionAggregateType<T>>

    /**
     * Group by AnalyticsRegion.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AnalyticsRegionGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends AnalyticsRegionGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: AnalyticsRegionGroupByArgs['orderBy'] }
        : { orderBy?: AnalyticsRegionGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, AnalyticsRegionGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetAnalyticsRegionGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the AnalyticsRegion model
   */
  readonly fields: AnalyticsRegionFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for AnalyticsRegion.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__AnalyticsRegionClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the AnalyticsRegion model
   */
  interface AnalyticsRegionFieldRefs {
    readonly clientId: FieldRef<"AnalyticsRegion", 'String'>
    readonly regionKey: FieldRef<"AnalyticsRegion", 'String'>
    readonly regionName: FieldRef<"AnalyticsRegion", 'String'>
    readonly officeId: FieldRef<"AnalyticsRegion", 'String'>
    readonly officeName: FieldRef<"AnalyticsRegion", 'String'>
    readonly stockCount: FieldRef<"AnalyticsRegion", 'Float'>
    readonly stockSum: FieldRef<"AnalyticsRegion", 'Float'>
    readonly toClientCount: FieldRef<"AnalyticsRegion", 'Float'>
    readonly fromClientCount: FieldRef<"AnalyticsRegion", 'Float'>
    readonly saleRateDays: FieldRef<"AnalyticsRegion", 'Float'>
    readonly metrics: FieldRef<"AnalyticsRegion", 'Json'>
    readonly syncedAt: FieldRef<"AnalyticsRegion", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * AnalyticsRegion findUnique
   */
  export type AnalyticsRegionFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AnalyticsRegion
     */
    select?: AnalyticsRegionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AnalyticsRegion
     */
    omit?: AnalyticsRegionOmit<ExtArgs> | null
    /**
     * Filter, which AnalyticsRegion to fetch.
     */
    where: AnalyticsRegionWhereUniqueInput
  }

  /**
   * AnalyticsRegion findUniqueOrThrow
   */
  export type AnalyticsRegionFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AnalyticsRegion
     */
    select?: AnalyticsRegionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AnalyticsRegion
     */
    omit?: AnalyticsRegionOmit<ExtArgs> | null
    /**
     * Filter, which AnalyticsRegion to fetch.
     */
    where: AnalyticsRegionWhereUniqueInput
  }

  /**
   * AnalyticsRegion findFirst
   */
  export type AnalyticsRegionFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AnalyticsRegion
     */
    select?: AnalyticsRegionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AnalyticsRegion
     */
    omit?: AnalyticsRegionOmit<ExtArgs> | null
    /**
     * Filter, which AnalyticsRegion to fetch.
     */
    where?: AnalyticsRegionWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of AnalyticsRegions to fetch.
     */
    orderBy?: AnalyticsRegionOrderByWithRelationInput | AnalyticsRegionOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for AnalyticsRegions.
     */
    cursor?: AnalyticsRegionWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` AnalyticsRegions from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` AnalyticsRegions.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of AnalyticsRegions.
     */
    distinct?: AnalyticsRegionScalarFieldEnum | AnalyticsRegionScalarFieldEnum[]
  }

  /**
   * AnalyticsRegion findFirstOrThrow
   */
  export type AnalyticsRegionFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AnalyticsRegion
     */
    select?: AnalyticsRegionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AnalyticsRegion
     */
    omit?: AnalyticsRegionOmit<ExtArgs> | null
    /**
     * Filter, which AnalyticsRegion to fetch.
     */
    where?: AnalyticsRegionWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of AnalyticsRegions to fetch.
     */
    orderBy?: AnalyticsRegionOrderByWithRelationInput | AnalyticsRegionOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for AnalyticsRegions.
     */
    cursor?: AnalyticsRegionWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` AnalyticsRegions from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` AnalyticsRegions.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of AnalyticsRegions.
     */
    distinct?: AnalyticsRegionScalarFieldEnum | AnalyticsRegionScalarFieldEnum[]
  }

  /**
   * AnalyticsRegion findMany
   */
  export type AnalyticsRegionFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AnalyticsRegion
     */
    select?: AnalyticsRegionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AnalyticsRegion
     */
    omit?: AnalyticsRegionOmit<ExtArgs> | null
    /**
     * Filter, which AnalyticsRegions to fetch.
     */
    where?: AnalyticsRegionWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of AnalyticsRegions to fetch.
     */
    orderBy?: AnalyticsRegionOrderByWithRelationInput | AnalyticsRegionOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing AnalyticsRegions.
     */
    cursor?: AnalyticsRegionWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` AnalyticsRegions from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` AnalyticsRegions.
     */
    skip?: number
    distinct?: AnalyticsRegionScalarFieldEnum | AnalyticsRegionScalarFieldEnum[]
  }

  /**
   * AnalyticsRegion create
   */
  export type AnalyticsRegionCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AnalyticsRegion
     */
    select?: AnalyticsRegionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AnalyticsRegion
     */
    omit?: AnalyticsRegionOmit<ExtArgs> | null
    /**
     * The data needed to create a AnalyticsRegion.
     */
    data: XOR<AnalyticsRegionCreateInput, AnalyticsRegionUncheckedCreateInput>
  }

  /**
   * AnalyticsRegion createMany
   */
  export type AnalyticsRegionCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many AnalyticsRegions.
     */
    data: AnalyticsRegionCreateManyInput | AnalyticsRegionCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * AnalyticsRegion createManyAndReturn
   */
  export type AnalyticsRegionCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AnalyticsRegion
     */
    select?: AnalyticsRegionSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the AnalyticsRegion
     */
    omit?: AnalyticsRegionOmit<ExtArgs> | null
    /**
     * The data used to create many AnalyticsRegions.
     */
    data: AnalyticsRegionCreateManyInput | AnalyticsRegionCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * AnalyticsRegion update
   */
  export type AnalyticsRegionUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AnalyticsRegion
     */
    select?: AnalyticsRegionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AnalyticsRegion
     */
    omit?: AnalyticsRegionOmit<ExtArgs> | null
    /**
     * The data needed to update a AnalyticsRegion.
     */
    data: XOR<AnalyticsRegionUpdateInput, AnalyticsRegionUncheckedUpdateInput>
    /**
     * Choose, which AnalyticsRegion to update.
     */
    where: AnalyticsRegionWhereUniqueInput
  }

  /**
   * AnalyticsRegion updateMany
   */
  export type AnalyticsRegionUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update AnalyticsRegions.
     */
    data: XOR<AnalyticsRegionUpdateManyMutationInput, AnalyticsRegionUncheckedUpdateManyInput>
    /**
     * Filter which AnalyticsRegions to update
     */
    where?: AnalyticsRegionWhereInput
    /**
     * Limit how many AnalyticsRegions to update.
     */
    limit?: number
  }

  /**
   * AnalyticsRegion updateManyAndReturn
   */
  export type AnalyticsRegionUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AnalyticsRegion
     */
    select?: AnalyticsRegionSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the AnalyticsRegion
     */
    omit?: AnalyticsRegionOmit<ExtArgs> | null
    /**
     * The data used to update AnalyticsRegions.
     */
    data: XOR<AnalyticsRegionUpdateManyMutationInput, AnalyticsRegionUncheckedUpdateManyInput>
    /**
     * Filter which AnalyticsRegions to update
     */
    where?: AnalyticsRegionWhereInput
    /**
     * Limit how many AnalyticsRegions to update.
     */
    limit?: number
  }

  /**
   * AnalyticsRegion upsert
   */
  export type AnalyticsRegionUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AnalyticsRegion
     */
    select?: AnalyticsRegionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AnalyticsRegion
     */
    omit?: AnalyticsRegionOmit<ExtArgs> | null
    /**
     * The filter to search for the AnalyticsRegion to update in case it exists.
     */
    where: AnalyticsRegionWhereUniqueInput
    /**
     * In case the AnalyticsRegion found by the `where` argument doesn't exist, create a new AnalyticsRegion with this data.
     */
    create: XOR<AnalyticsRegionCreateInput, AnalyticsRegionUncheckedCreateInput>
    /**
     * In case the AnalyticsRegion was found with the provided `where` argument, update it with this data.
     */
    update: XOR<AnalyticsRegionUpdateInput, AnalyticsRegionUncheckedUpdateInput>
  }

  /**
   * AnalyticsRegion delete
   */
  export type AnalyticsRegionDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AnalyticsRegion
     */
    select?: AnalyticsRegionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AnalyticsRegion
     */
    omit?: AnalyticsRegionOmit<ExtArgs> | null
    /**
     * Filter which AnalyticsRegion to delete.
     */
    where: AnalyticsRegionWhereUniqueInput
  }

  /**
   * AnalyticsRegion deleteMany
   */
  export type AnalyticsRegionDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which AnalyticsRegions to delete
     */
    where?: AnalyticsRegionWhereInput
    /**
     * Limit how many AnalyticsRegions to delete.
     */
    limit?: number
  }

  /**
   * AnalyticsRegion without action
   */
  export type AnalyticsRegionDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AnalyticsRegion
     */
    select?: AnalyticsRegionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AnalyticsRegion
     */
    omit?: AnalyticsRegionOmit<ExtArgs> | null
  }


  /**
   * Model AnalyticsDailySummary
   */

  export type AggregateAnalyticsDailySummary = {
    _count: AnalyticsDailySummaryCountAggregateOutputType | null
    _avg: AnalyticsDailySummaryAvgAggregateOutputType | null
    _sum: AnalyticsDailySummarySumAggregateOutputType | null
    _min: AnalyticsDailySummaryMinAggregateOutputType | null
    _max: AnalyticsDailySummaryMaxAggregateOutputType | null
  }

  export type AnalyticsDailySummaryAvgAggregateOutputType = {
    periodDays: number | null
    productCount: number | null
    stockCount: number | null
    stockSum: number | null
    ordersCount: number | null
    ordersSum: number | null
    buyoutCount: number | null
    buyoutSum: number | null
    lostOrdersSum: number | null
  }

  export type AnalyticsDailySummarySumAggregateOutputType = {
    periodDays: number | null
    productCount: number | null
    stockCount: number | null
    stockSum: number | null
    ordersCount: number | null
    ordersSum: number | null
    buyoutCount: number | null
    buyoutSum: number | null
    lostOrdersSum: number | null
  }

  export type AnalyticsDailySummaryMinAggregateOutputType = {
    clientId: string | null
    snapshotDate: Date | null
    periodDays: number | null
    productCount: number | null
    stockCount: number | null
    stockSum: number | null
    ordersCount: number | null
    ordersSum: number | null
    buyoutCount: number | null
    buyoutSum: number | null
    lostOrdersSum: number | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type AnalyticsDailySummaryMaxAggregateOutputType = {
    clientId: string | null
    snapshotDate: Date | null
    periodDays: number | null
    productCount: number | null
    stockCount: number | null
    stockSum: number | null
    ordersCount: number | null
    ordersSum: number | null
    buyoutCount: number | null
    buyoutSum: number | null
    lostOrdersSum: number | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type AnalyticsDailySummaryCountAggregateOutputType = {
    clientId: number
    snapshotDate: number
    periodDays: number
    productCount: number
    stockCount: number
    stockSum: number
    ordersCount: number
    ordersSum: number
    buyoutCount: number
    buyoutSum: number
    lostOrdersSum: number
    createdAt: number
    updatedAt: number
    _all: number
  }


  export type AnalyticsDailySummaryAvgAggregateInputType = {
    periodDays?: true
    productCount?: true
    stockCount?: true
    stockSum?: true
    ordersCount?: true
    ordersSum?: true
    buyoutCount?: true
    buyoutSum?: true
    lostOrdersSum?: true
  }

  export type AnalyticsDailySummarySumAggregateInputType = {
    periodDays?: true
    productCount?: true
    stockCount?: true
    stockSum?: true
    ordersCount?: true
    ordersSum?: true
    buyoutCount?: true
    buyoutSum?: true
    lostOrdersSum?: true
  }

  export type AnalyticsDailySummaryMinAggregateInputType = {
    clientId?: true
    snapshotDate?: true
    periodDays?: true
    productCount?: true
    stockCount?: true
    stockSum?: true
    ordersCount?: true
    ordersSum?: true
    buyoutCount?: true
    buyoutSum?: true
    lostOrdersSum?: true
    createdAt?: true
    updatedAt?: true
  }

  export type AnalyticsDailySummaryMaxAggregateInputType = {
    clientId?: true
    snapshotDate?: true
    periodDays?: true
    productCount?: true
    stockCount?: true
    stockSum?: true
    ordersCount?: true
    ordersSum?: true
    buyoutCount?: true
    buyoutSum?: true
    lostOrdersSum?: true
    createdAt?: true
    updatedAt?: true
  }

  export type AnalyticsDailySummaryCountAggregateInputType = {
    clientId?: true
    snapshotDate?: true
    periodDays?: true
    productCount?: true
    stockCount?: true
    stockSum?: true
    ordersCount?: true
    ordersSum?: true
    buyoutCount?: true
    buyoutSum?: true
    lostOrdersSum?: true
    createdAt?: true
    updatedAt?: true
    _all?: true
  }

  export type AnalyticsDailySummaryAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which AnalyticsDailySummary to aggregate.
     */
    where?: AnalyticsDailySummaryWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of AnalyticsDailySummaries to fetch.
     */
    orderBy?: AnalyticsDailySummaryOrderByWithRelationInput | AnalyticsDailySummaryOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: AnalyticsDailySummaryWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` AnalyticsDailySummaries from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` AnalyticsDailySummaries.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned AnalyticsDailySummaries
    **/
    _count?: true | AnalyticsDailySummaryCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: AnalyticsDailySummaryAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: AnalyticsDailySummarySumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: AnalyticsDailySummaryMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: AnalyticsDailySummaryMaxAggregateInputType
  }

  export type GetAnalyticsDailySummaryAggregateType<T extends AnalyticsDailySummaryAggregateArgs> = {
        [P in keyof T & keyof AggregateAnalyticsDailySummary]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateAnalyticsDailySummary[P]>
      : GetScalarType<T[P], AggregateAnalyticsDailySummary[P]>
  }




  export type AnalyticsDailySummaryGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: AnalyticsDailySummaryWhereInput
    orderBy?: AnalyticsDailySummaryOrderByWithAggregationInput | AnalyticsDailySummaryOrderByWithAggregationInput[]
    by: AnalyticsDailySummaryScalarFieldEnum[] | AnalyticsDailySummaryScalarFieldEnum
    having?: AnalyticsDailySummaryScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: AnalyticsDailySummaryCountAggregateInputType | true
    _avg?: AnalyticsDailySummaryAvgAggregateInputType
    _sum?: AnalyticsDailySummarySumAggregateInputType
    _min?: AnalyticsDailySummaryMinAggregateInputType
    _max?: AnalyticsDailySummaryMaxAggregateInputType
  }

  export type AnalyticsDailySummaryGroupByOutputType = {
    clientId: string
    snapshotDate: Date
    periodDays: number
    productCount: number
    stockCount: number
    stockSum: number
    ordersCount: number
    ordersSum: number
    buyoutCount: number
    buyoutSum: number
    lostOrdersSum: number
    createdAt: Date
    updatedAt: Date
    _count: AnalyticsDailySummaryCountAggregateOutputType | null
    _avg: AnalyticsDailySummaryAvgAggregateOutputType | null
    _sum: AnalyticsDailySummarySumAggregateOutputType | null
    _min: AnalyticsDailySummaryMinAggregateOutputType | null
    _max: AnalyticsDailySummaryMaxAggregateOutputType | null
  }

  type GetAnalyticsDailySummaryGroupByPayload<T extends AnalyticsDailySummaryGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<AnalyticsDailySummaryGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof AnalyticsDailySummaryGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], AnalyticsDailySummaryGroupByOutputType[P]>
            : GetScalarType<T[P], AnalyticsDailySummaryGroupByOutputType[P]>
        }
      >
    >


  export type AnalyticsDailySummarySelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    clientId?: boolean
    snapshotDate?: boolean
    periodDays?: boolean
    productCount?: boolean
    stockCount?: boolean
    stockSum?: boolean
    ordersCount?: boolean
    ordersSum?: boolean
    buyoutCount?: boolean
    buyoutSum?: boolean
    lostOrdersSum?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }, ExtArgs["result"]["analyticsDailySummary"]>

  export type AnalyticsDailySummarySelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    clientId?: boolean
    snapshotDate?: boolean
    periodDays?: boolean
    productCount?: boolean
    stockCount?: boolean
    stockSum?: boolean
    ordersCount?: boolean
    ordersSum?: boolean
    buyoutCount?: boolean
    buyoutSum?: boolean
    lostOrdersSum?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }, ExtArgs["result"]["analyticsDailySummary"]>

  export type AnalyticsDailySummarySelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    clientId?: boolean
    snapshotDate?: boolean
    periodDays?: boolean
    productCount?: boolean
    stockCount?: boolean
    stockSum?: boolean
    ordersCount?: boolean
    ordersSum?: boolean
    buyoutCount?: boolean
    buyoutSum?: boolean
    lostOrdersSum?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }, ExtArgs["result"]["analyticsDailySummary"]>

  export type AnalyticsDailySummarySelectScalar = {
    clientId?: boolean
    snapshotDate?: boolean
    periodDays?: boolean
    productCount?: boolean
    stockCount?: boolean
    stockSum?: boolean
    ordersCount?: boolean
    ordersSum?: boolean
    buyoutCount?: boolean
    buyoutSum?: boolean
    lostOrdersSum?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }

  export type AnalyticsDailySummaryOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"clientId" | "snapshotDate" | "periodDays" | "productCount" | "stockCount" | "stockSum" | "ordersCount" | "ordersSum" | "buyoutCount" | "buyoutSum" | "lostOrdersSum" | "createdAt" | "updatedAt", ExtArgs["result"]["analyticsDailySummary"]>

  export type $AnalyticsDailySummaryPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "AnalyticsDailySummary"
    objects: {}
    scalars: $Extensions.GetPayloadResult<{
      clientId: string
      snapshotDate: Date
      periodDays: number
      productCount: number
      stockCount: number
      stockSum: number
      ordersCount: number
      ordersSum: number
      buyoutCount: number
      buyoutSum: number
      lostOrdersSum: number
      createdAt: Date
      updatedAt: Date
    }, ExtArgs["result"]["analyticsDailySummary"]>
    composites: {}
  }

  type AnalyticsDailySummaryGetPayload<S extends boolean | null | undefined | AnalyticsDailySummaryDefaultArgs> = $Result.GetResult<Prisma.$AnalyticsDailySummaryPayload, S>

  type AnalyticsDailySummaryCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<AnalyticsDailySummaryFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: AnalyticsDailySummaryCountAggregateInputType | true
    }

  export interface AnalyticsDailySummaryDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['AnalyticsDailySummary'], meta: { name: 'AnalyticsDailySummary' } }
    /**
     * Find zero or one AnalyticsDailySummary that matches the filter.
     * @param {AnalyticsDailySummaryFindUniqueArgs} args - Arguments to find a AnalyticsDailySummary
     * @example
     * // Get one AnalyticsDailySummary
     * const analyticsDailySummary = await prisma.analyticsDailySummary.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends AnalyticsDailySummaryFindUniqueArgs>(args: SelectSubset<T, AnalyticsDailySummaryFindUniqueArgs<ExtArgs>>): Prisma__AnalyticsDailySummaryClient<$Result.GetResult<Prisma.$AnalyticsDailySummaryPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one AnalyticsDailySummary that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {AnalyticsDailySummaryFindUniqueOrThrowArgs} args - Arguments to find a AnalyticsDailySummary
     * @example
     * // Get one AnalyticsDailySummary
     * const analyticsDailySummary = await prisma.analyticsDailySummary.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends AnalyticsDailySummaryFindUniqueOrThrowArgs>(args: SelectSubset<T, AnalyticsDailySummaryFindUniqueOrThrowArgs<ExtArgs>>): Prisma__AnalyticsDailySummaryClient<$Result.GetResult<Prisma.$AnalyticsDailySummaryPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first AnalyticsDailySummary that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AnalyticsDailySummaryFindFirstArgs} args - Arguments to find a AnalyticsDailySummary
     * @example
     * // Get one AnalyticsDailySummary
     * const analyticsDailySummary = await prisma.analyticsDailySummary.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends AnalyticsDailySummaryFindFirstArgs>(args?: SelectSubset<T, AnalyticsDailySummaryFindFirstArgs<ExtArgs>>): Prisma__AnalyticsDailySummaryClient<$Result.GetResult<Prisma.$AnalyticsDailySummaryPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first AnalyticsDailySummary that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AnalyticsDailySummaryFindFirstOrThrowArgs} args - Arguments to find a AnalyticsDailySummary
     * @example
     * // Get one AnalyticsDailySummary
     * const analyticsDailySummary = await prisma.analyticsDailySummary.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends AnalyticsDailySummaryFindFirstOrThrowArgs>(args?: SelectSubset<T, AnalyticsDailySummaryFindFirstOrThrowArgs<ExtArgs>>): Prisma__AnalyticsDailySummaryClient<$Result.GetResult<Prisma.$AnalyticsDailySummaryPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more AnalyticsDailySummaries that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AnalyticsDailySummaryFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all AnalyticsDailySummaries
     * const analyticsDailySummaries = await prisma.analyticsDailySummary.findMany()
     * 
     * // Get first 10 AnalyticsDailySummaries
     * const analyticsDailySummaries = await prisma.analyticsDailySummary.findMany({ take: 10 })
     * 
     * // Only select the `clientId`
     * const analyticsDailySummaryWithClientIdOnly = await prisma.analyticsDailySummary.findMany({ select: { clientId: true } })
     * 
     */
    findMany<T extends AnalyticsDailySummaryFindManyArgs>(args?: SelectSubset<T, AnalyticsDailySummaryFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$AnalyticsDailySummaryPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a AnalyticsDailySummary.
     * @param {AnalyticsDailySummaryCreateArgs} args - Arguments to create a AnalyticsDailySummary.
     * @example
     * // Create one AnalyticsDailySummary
     * const AnalyticsDailySummary = await prisma.analyticsDailySummary.create({
     *   data: {
     *     // ... data to create a AnalyticsDailySummary
     *   }
     * })
     * 
     */
    create<T extends AnalyticsDailySummaryCreateArgs>(args: SelectSubset<T, AnalyticsDailySummaryCreateArgs<ExtArgs>>): Prisma__AnalyticsDailySummaryClient<$Result.GetResult<Prisma.$AnalyticsDailySummaryPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many AnalyticsDailySummaries.
     * @param {AnalyticsDailySummaryCreateManyArgs} args - Arguments to create many AnalyticsDailySummaries.
     * @example
     * // Create many AnalyticsDailySummaries
     * const analyticsDailySummary = await prisma.analyticsDailySummary.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends AnalyticsDailySummaryCreateManyArgs>(args?: SelectSubset<T, AnalyticsDailySummaryCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many AnalyticsDailySummaries and returns the data saved in the database.
     * @param {AnalyticsDailySummaryCreateManyAndReturnArgs} args - Arguments to create many AnalyticsDailySummaries.
     * @example
     * // Create many AnalyticsDailySummaries
     * const analyticsDailySummary = await prisma.analyticsDailySummary.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many AnalyticsDailySummaries and only return the `clientId`
     * const analyticsDailySummaryWithClientIdOnly = await prisma.analyticsDailySummary.createManyAndReturn({
     *   select: { clientId: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends AnalyticsDailySummaryCreateManyAndReturnArgs>(args?: SelectSubset<T, AnalyticsDailySummaryCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$AnalyticsDailySummaryPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a AnalyticsDailySummary.
     * @param {AnalyticsDailySummaryDeleteArgs} args - Arguments to delete one AnalyticsDailySummary.
     * @example
     * // Delete one AnalyticsDailySummary
     * const AnalyticsDailySummary = await prisma.analyticsDailySummary.delete({
     *   where: {
     *     // ... filter to delete one AnalyticsDailySummary
     *   }
     * })
     * 
     */
    delete<T extends AnalyticsDailySummaryDeleteArgs>(args: SelectSubset<T, AnalyticsDailySummaryDeleteArgs<ExtArgs>>): Prisma__AnalyticsDailySummaryClient<$Result.GetResult<Prisma.$AnalyticsDailySummaryPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one AnalyticsDailySummary.
     * @param {AnalyticsDailySummaryUpdateArgs} args - Arguments to update one AnalyticsDailySummary.
     * @example
     * // Update one AnalyticsDailySummary
     * const analyticsDailySummary = await prisma.analyticsDailySummary.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends AnalyticsDailySummaryUpdateArgs>(args: SelectSubset<T, AnalyticsDailySummaryUpdateArgs<ExtArgs>>): Prisma__AnalyticsDailySummaryClient<$Result.GetResult<Prisma.$AnalyticsDailySummaryPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more AnalyticsDailySummaries.
     * @param {AnalyticsDailySummaryDeleteManyArgs} args - Arguments to filter AnalyticsDailySummaries to delete.
     * @example
     * // Delete a few AnalyticsDailySummaries
     * const { count } = await prisma.analyticsDailySummary.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends AnalyticsDailySummaryDeleteManyArgs>(args?: SelectSubset<T, AnalyticsDailySummaryDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more AnalyticsDailySummaries.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AnalyticsDailySummaryUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many AnalyticsDailySummaries
     * const analyticsDailySummary = await prisma.analyticsDailySummary.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends AnalyticsDailySummaryUpdateManyArgs>(args: SelectSubset<T, AnalyticsDailySummaryUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more AnalyticsDailySummaries and returns the data updated in the database.
     * @param {AnalyticsDailySummaryUpdateManyAndReturnArgs} args - Arguments to update many AnalyticsDailySummaries.
     * @example
     * // Update many AnalyticsDailySummaries
     * const analyticsDailySummary = await prisma.analyticsDailySummary.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more AnalyticsDailySummaries and only return the `clientId`
     * const analyticsDailySummaryWithClientIdOnly = await prisma.analyticsDailySummary.updateManyAndReturn({
     *   select: { clientId: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends AnalyticsDailySummaryUpdateManyAndReturnArgs>(args: SelectSubset<T, AnalyticsDailySummaryUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$AnalyticsDailySummaryPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one AnalyticsDailySummary.
     * @param {AnalyticsDailySummaryUpsertArgs} args - Arguments to update or create a AnalyticsDailySummary.
     * @example
     * // Update or create a AnalyticsDailySummary
     * const analyticsDailySummary = await prisma.analyticsDailySummary.upsert({
     *   create: {
     *     // ... data to create a AnalyticsDailySummary
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the AnalyticsDailySummary we want to update
     *   }
     * })
     */
    upsert<T extends AnalyticsDailySummaryUpsertArgs>(args: SelectSubset<T, AnalyticsDailySummaryUpsertArgs<ExtArgs>>): Prisma__AnalyticsDailySummaryClient<$Result.GetResult<Prisma.$AnalyticsDailySummaryPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of AnalyticsDailySummaries.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AnalyticsDailySummaryCountArgs} args - Arguments to filter AnalyticsDailySummaries to count.
     * @example
     * // Count the number of AnalyticsDailySummaries
     * const count = await prisma.analyticsDailySummary.count({
     *   where: {
     *     // ... the filter for the AnalyticsDailySummaries we want to count
     *   }
     * })
    **/
    count<T extends AnalyticsDailySummaryCountArgs>(
      args?: Subset<T, AnalyticsDailySummaryCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], AnalyticsDailySummaryCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a AnalyticsDailySummary.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AnalyticsDailySummaryAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends AnalyticsDailySummaryAggregateArgs>(args: Subset<T, AnalyticsDailySummaryAggregateArgs>): Prisma.PrismaPromise<GetAnalyticsDailySummaryAggregateType<T>>

    /**
     * Group by AnalyticsDailySummary.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AnalyticsDailySummaryGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends AnalyticsDailySummaryGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: AnalyticsDailySummaryGroupByArgs['orderBy'] }
        : { orderBy?: AnalyticsDailySummaryGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, AnalyticsDailySummaryGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetAnalyticsDailySummaryGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the AnalyticsDailySummary model
   */
  readonly fields: AnalyticsDailySummaryFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for AnalyticsDailySummary.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__AnalyticsDailySummaryClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the AnalyticsDailySummary model
   */
  interface AnalyticsDailySummaryFieldRefs {
    readonly clientId: FieldRef<"AnalyticsDailySummary", 'String'>
    readonly snapshotDate: FieldRef<"AnalyticsDailySummary", 'DateTime'>
    readonly periodDays: FieldRef<"AnalyticsDailySummary", 'Int'>
    readonly productCount: FieldRef<"AnalyticsDailySummary", 'Int'>
    readonly stockCount: FieldRef<"AnalyticsDailySummary", 'Float'>
    readonly stockSum: FieldRef<"AnalyticsDailySummary", 'Float'>
    readonly ordersCount: FieldRef<"AnalyticsDailySummary", 'Float'>
    readonly ordersSum: FieldRef<"AnalyticsDailySummary", 'Float'>
    readonly buyoutCount: FieldRef<"AnalyticsDailySummary", 'Float'>
    readonly buyoutSum: FieldRef<"AnalyticsDailySummary", 'Float'>
    readonly lostOrdersSum: FieldRef<"AnalyticsDailySummary", 'Float'>
    readonly createdAt: FieldRef<"AnalyticsDailySummary", 'DateTime'>
    readonly updatedAt: FieldRef<"AnalyticsDailySummary", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * AnalyticsDailySummary findUnique
   */
  export type AnalyticsDailySummaryFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AnalyticsDailySummary
     */
    select?: AnalyticsDailySummarySelect<ExtArgs> | null
    /**
     * Omit specific fields from the AnalyticsDailySummary
     */
    omit?: AnalyticsDailySummaryOmit<ExtArgs> | null
    /**
     * Filter, which AnalyticsDailySummary to fetch.
     */
    where: AnalyticsDailySummaryWhereUniqueInput
  }

  /**
   * AnalyticsDailySummary findUniqueOrThrow
   */
  export type AnalyticsDailySummaryFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AnalyticsDailySummary
     */
    select?: AnalyticsDailySummarySelect<ExtArgs> | null
    /**
     * Omit specific fields from the AnalyticsDailySummary
     */
    omit?: AnalyticsDailySummaryOmit<ExtArgs> | null
    /**
     * Filter, which AnalyticsDailySummary to fetch.
     */
    where: AnalyticsDailySummaryWhereUniqueInput
  }

  /**
   * AnalyticsDailySummary findFirst
   */
  export type AnalyticsDailySummaryFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AnalyticsDailySummary
     */
    select?: AnalyticsDailySummarySelect<ExtArgs> | null
    /**
     * Omit specific fields from the AnalyticsDailySummary
     */
    omit?: AnalyticsDailySummaryOmit<ExtArgs> | null
    /**
     * Filter, which AnalyticsDailySummary to fetch.
     */
    where?: AnalyticsDailySummaryWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of AnalyticsDailySummaries to fetch.
     */
    orderBy?: AnalyticsDailySummaryOrderByWithRelationInput | AnalyticsDailySummaryOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for AnalyticsDailySummaries.
     */
    cursor?: AnalyticsDailySummaryWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` AnalyticsDailySummaries from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` AnalyticsDailySummaries.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of AnalyticsDailySummaries.
     */
    distinct?: AnalyticsDailySummaryScalarFieldEnum | AnalyticsDailySummaryScalarFieldEnum[]
  }

  /**
   * AnalyticsDailySummary findFirstOrThrow
   */
  export type AnalyticsDailySummaryFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AnalyticsDailySummary
     */
    select?: AnalyticsDailySummarySelect<ExtArgs> | null
    /**
     * Omit specific fields from the AnalyticsDailySummary
     */
    omit?: AnalyticsDailySummaryOmit<ExtArgs> | null
    /**
     * Filter, which AnalyticsDailySummary to fetch.
     */
    where?: AnalyticsDailySummaryWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of AnalyticsDailySummaries to fetch.
     */
    orderBy?: AnalyticsDailySummaryOrderByWithRelationInput | AnalyticsDailySummaryOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for AnalyticsDailySummaries.
     */
    cursor?: AnalyticsDailySummaryWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` AnalyticsDailySummaries from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` AnalyticsDailySummaries.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of AnalyticsDailySummaries.
     */
    distinct?: AnalyticsDailySummaryScalarFieldEnum | AnalyticsDailySummaryScalarFieldEnum[]
  }

  /**
   * AnalyticsDailySummary findMany
   */
  export type AnalyticsDailySummaryFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AnalyticsDailySummary
     */
    select?: AnalyticsDailySummarySelect<ExtArgs> | null
    /**
     * Omit specific fields from the AnalyticsDailySummary
     */
    omit?: AnalyticsDailySummaryOmit<ExtArgs> | null
    /**
     * Filter, which AnalyticsDailySummaries to fetch.
     */
    where?: AnalyticsDailySummaryWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of AnalyticsDailySummaries to fetch.
     */
    orderBy?: AnalyticsDailySummaryOrderByWithRelationInput | AnalyticsDailySummaryOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing AnalyticsDailySummaries.
     */
    cursor?: AnalyticsDailySummaryWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` AnalyticsDailySummaries from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` AnalyticsDailySummaries.
     */
    skip?: number
    distinct?: AnalyticsDailySummaryScalarFieldEnum | AnalyticsDailySummaryScalarFieldEnum[]
  }

  /**
   * AnalyticsDailySummary create
   */
  export type AnalyticsDailySummaryCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AnalyticsDailySummary
     */
    select?: AnalyticsDailySummarySelect<ExtArgs> | null
    /**
     * Omit specific fields from the AnalyticsDailySummary
     */
    omit?: AnalyticsDailySummaryOmit<ExtArgs> | null
    /**
     * The data needed to create a AnalyticsDailySummary.
     */
    data: XOR<AnalyticsDailySummaryCreateInput, AnalyticsDailySummaryUncheckedCreateInput>
  }

  /**
   * AnalyticsDailySummary createMany
   */
  export type AnalyticsDailySummaryCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many AnalyticsDailySummaries.
     */
    data: AnalyticsDailySummaryCreateManyInput | AnalyticsDailySummaryCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * AnalyticsDailySummary createManyAndReturn
   */
  export type AnalyticsDailySummaryCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AnalyticsDailySummary
     */
    select?: AnalyticsDailySummarySelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the AnalyticsDailySummary
     */
    omit?: AnalyticsDailySummaryOmit<ExtArgs> | null
    /**
     * The data used to create many AnalyticsDailySummaries.
     */
    data: AnalyticsDailySummaryCreateManyInput | AnalyticsDailySummaryCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * AnalyticsDailySummary update
   */
  export type AnalyticsDailySummaryUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AnalyticsDailySummary
     */
    select?: AnalyticsDailySummarySelect<ExtArgs> | null
    /**
     * Omit specific fields from the AnalyticsDailySummary
     */
    omit?: AnalyticsDailySummaryOmit<ExtArgs> | null
    /**
     * The data needed to update a AnalyticsDailySummary.
     */
    data: XOR<AnalyticsDailySummaryUpdateInput, AnalyticsDailySummaryUncheckedUpdateInput>
    /**
     * Choose, which AnalyticsDailySummary to update.
     */
    where: AnalyticsDailySummaryWhereUniqueInput
  }

  /**
   * AnalyticsDailySummary updateMany
   */
  export type AnalyticsDailySummaryUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update AnalyticsDailySummaries.
     */
    data: XOR<AnalyticsDailySummaryUpdateManyMutationInput, AnalyticsDailySummaryUncheckedUpdateManyInput>
    /**
     * Filter which AnalyticsDailySummaries to update
     */
    where?: AnalyticsDailySummaryWhereInput
    /**
     * Limit how many AnalyticsDailySummaries to update.
     */
    limit?: number
  }

  /**
   * AnalyticsDailySummary updateManyAndReturn
   */
  export type AnalyticsDailySummaryUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AnalyticsDailySummary
     */
    select?: AnalyticsDailySummarySelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the AnalyticsDailySummary
     */
    omit?: AnalyticsDailySummaryOmit<ExtArgs> | null
    /**
     * The data used to update AnalyticsDailySummaries.
     */
    data: XOR<AnalyticsDailySummaryUpdateManyMutationInput, AnalyticsDailySummaryUncheckedUpdateManyInput>
    /**
     * Filter which AnalyticsDailySummaries to update
     */
    where?: AnalyticsDailySummaryWhereInput
    /**
     * Limit how many AnalyticsDailySummaries to update.
     */
    limit?: number
  }

  /**
   * AnalyticsDailySummary upsert
   */
  export type AnalyticsDailySummaryUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AnalyticsDailySummary
     */
    select?: AnalyticsDailySummarySelect<ExtArgs> | null
    /**
     * Omit specific fields from the AnalyticsDailySummary
     */
    omit?: AnalyticsDailySummaryOmit<ExtArgs> | null
    /**
     * The filter to search for the AnalyticsDailySummary to update in case it exists.
     */
    where: AnalyticsDailySummaryWhereUniqueInput
    /**
     * In case the AnalyticsDailySummary found by the `where` argument doesn't exist, create a new AnalyticsDailySummary with this data.
     */
    create: XOR<AnalyticsDailySummaryCreateInput, AnalyticsDailySummaryUncheckedCreateInput>
    /**
     * In case the AnalyticsDailySummary was found with the provided `where` argument, update it with this data.
     */
    update: XOR<AnalyticsDailySummaryUpdateInput, AnalyticsDailySummaryUncheckedUpdateInput>
  }

  /**
   * AnalyticsDailySummary delete
   */
  export type AnalyticsDailySummaryDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AnalyticsDailySummary
     */
    select?: AnalyticsDailySummarySelect<ExtArgs> | null
    /**
     * Omit specific fields from the AnalyticsDailySummary
     */
    omit?: AnalyticsDailySummaryOmit<ExtArgs> | null
    /**
     * Filter which AnalyticsDailySummary to delete.
     */
    where: AnalyticsDailySummaryWhereUniqueInput
  }

  /**
   * AnalyticsDailySummary deleteMany
   */
  export type AnalyticsDailySummaryDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which AnalyticsDailySummaries to delete
     */
    where?: AnalyticsDailySummaryWhereInput
    /**
     * Limit how many AnalyticsDailySummaries to delete.
     */
    limit?: number
  }

  /**
   * AnalyticsDailySummary without action
   */
  export type AnalyticsDailySummaryDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AnalyticsDailySummary
     */
    select?: AnalyticsDailySummarySelect<ExtArgs> | null
    /**
     * Omit specific fields from the AnalyticsDailySummary
     */
    omit?: AnalyticsDailySummaryOmit<ExtArgs> | null
  }


  /**
   * Enums
   */

  export const TransactionIsolationLevel: {
    ReadUncommitted: 'ReadUncommitted',
    ReadCommitted: 'ReadCommitted',
    RepeatableRead: 'RepeatableRead',
    Serializable: 'Serializable'
  };

  export type TransactionIsolationLevel = (typeof TransactionIsolationLevel)[keyof typeof TransactionIsolationLevel]


  export const AnalyticsConnectionScalarFieldEnum: {
    clientId: 'clientId',
    marketplace: 'marketplace',
    accountName: 'accountName',
    sellerSid: 'sellerSid',
    apiKeyEncrypted: 'apiKeyEncrypted',
    isActive: 'isActive',
    lastVerifiedAt: 'lastVerifiedAt',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
  };

  export type AnalyticsConnectionScalarFieldEnum = (typeof AnalyticsConnectionScalarFieldEnum)[keyof typeof AnalyticsConnectionScalarFieldEnum]


  export const AnalyticsSyncStateScalarFieldEnum: {
    clientId: 'clientId',
    marketplace: 'marketplace',
    status: 'status',
    periodDays: 'periodDays',
    currency: 'currency',
    productCount: 'productCount',
    lastStartedAt: 'lastStartedAt',
    lastSyncedAt: 'lastSyncedAt',
    lastError: 'lastError',
    sourceStatus: 'sourceStatus',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
  };

  export type AnalyticsSyncStateScalarFieldEnum = (typeof AnalyticsSyncStateScalarFieldEnum)[keyof typeof AnalyticsSyncStateScalarFieldEnum]


  export const AnalyticsProductScalarFieldEnum: {
    clientId: 'clientId',
    nmId: 'nmId',
    name: 'name',
    vendorCode: 'vendorCode',
    brandName: 'brandName',
    subjectName: 'subjectName',
    photoUrl: 'photoUrl',
    availability: 'availability',
    stockCount: 'stockCount',
    stockSum: 'stockSum',
    avgOrders: 'avgOrders',
    ordersCount: 'ordersCount',
    ordersSum: 'ordersSum',
    buyoutCount: 'buyoutCount',
    buyoutSum: 'buyoutSum',
    buyoutPercent: 'buyoutPercent',
    lostOrdersCount: 'lostOrdersCount',
    lostOrdersSum: 'lostOrdersSum',
    lostBuyoutsCount: 'lostBuyoutsCount',
    lostBuyoutsSum: 'lostBuyoutsSum',
    turnoverDays: 'turnoverDays',
    saleRateDays: 'saleRateDays',
    currentPriceMin: 'currentPriceMin',
    currentPriceMax: 'currentPriceMax',
    openCount: 'openCount',
    cartCount: 'cartCount',
    orderCount: 'orderCount',
    orderSum: 'orderSum',
    funnelBuyoutCount: 'funnelBuyoutCount',
    funnelBuyoutSum: 'funnelBuyoutSum',
    cancelCount: 'cancelCount',
    cancelSum: 'cancelSum',
    addToCartPercent: 'addToCartPercent',
    cartToOrderPercent: 'cartToOrderPercent',
    funnelBuyoutPercent: 'funnelBuyoutPercent',
    orderCountDynamic: 'orderCountDynamic',
    orderSumDynamic: 'orderSumDynamic',
    openCountDynamic: 'openCountDynamic',
    cartCountDynamic: 'cartCountDynamic',
    selectedMetrics: 'selectedMetrics',
    pastMetrics: 'pastMetrics',
    comparisonMetrics: 'comparisonMetrics',
    stockMetrics: 'stockMetrics',
    syncedAt: 'syncedAt'
  };

  export type AnalyticsProductScalarFieldEnum = (typeof AnalyticsProductScalarFieldEnum)[keyof typeof AnalyticsProductScalarFieldEnum]


  export const AnalyticsRegionScalarFieldEnum: {
    clientId: 'clientId',
    regionKey: 'regionKey',
    regionName: 'regionName',
    officeId: 'officeId',
    officeName: 'officeName',
    stockCount: 'stockCount',
    stockSum: 'stockSum',
    toClientCount: 'toClientCount',
    fromClientCount: 'fromClientCount',
    saleRateDays: 'saleRateDays',
    metrics: 'metrics',
    syncedAt: 'syncedAt'
  };

  export type AnalyticsRegionScalarFieldEnum = (typeof AnalyticsRegionScalarFieldEnum)[keyof typeof AnalyticsRegionScalarFieldEnum]


  export const AnalyticsDailySummaryScalarFieldEnum: {
    clientId: 'clientId',
    snapshotDate: 'snapshotDate',
    periodDays: 'periodDays',
    productCount: 'productCount',
    stockCount: 'stockCount',
    stockSum: 'stockSum',
    ordersCount: 'ordersCount',
    ordersSum: 'ordersSum',
    buyoutCount: 'buyoutCount',
    buyoutSum: 'buyoutSum',
    lostOrdersSum: 'lostOrdersSum',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
  };

  export type AnalyticsDailySummaryScalarFieldEnum = (typeof AnalyticsDailySummaryScalarFieldEnum)[keyof typeof AnalyticsDailySummaryScalarFieldEnum]


  export const SortOrder: {
    asc: 'asc',
    desc: 'desc'
  };

  export type SortOrder = (typeof SortOrder)[keyof typeof SortOrder]


  export const NullableJsonNullValueInput: {
    DbNull: typeof DbNull,
    JsonNull: typeof JsonNull
  };

  export type NullableJsonNullValueInput = (typeof NullableJsonNullValueInput)[keyof typeof NullableJsonNullValueInput]


  export const QueryMode: {
    default: 'default',
    insensitive: 'insensitive'
  };

  export type QueryMode = (typeof QueryMode)[keyof typeof QueryMode]


  export const NullsOrder: {
    first: 'first',
    last: 'last'
  };

  export type NullsOrder = (typeof NullsOrder)[keyof typeof NullsOrder]


  export const JsonNullValueFilter: {
    DbNull: typeof DbNull,
    JsonNull: typeof JsonNull,
    AnyNull: typeof AnyNull
  };

  export type JsonNullValueFilter = (typeof JsonNullValueFilter)[keyof typeof JsonNullValueFilter]


  /**
   * Field references
   */


  /**
   * Reference to a field of type 'String'
   */
  export type StringFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'String'>
    


  /**
   * Reference to a field of type 'String[]'
   */
  export type ListStringFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'String[]'>
    


  /**
   * Reference to a field of type 'Boolean'
   */
  export type BooleanFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Boolean'>
    


  /**
   * Reference to a field of type 'DateTime'
   */
  export type DateTimeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'DateTime'>
    


  /**
   * Reference to a field of type 'DateTime[]'
   */
  export type ListDateTimeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'DateTime[]'>
    


  /**
   * Reference to a field of type 'Int'
   */
  export type IntFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Int'>
    


  /**
   * Reference to a field of type 'Int[]'
   */
  export type ListIntFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Int[]'>
    


  /**
   * Reference to a field of type 'Json'
   */
  export type JsonFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Json'>
    


  /**
   * Reference to a field of type 'QueryMode'
   */
  export type EnumQueryModeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'QueryMode'>
    


  /**
   * Reference to a field of type 'Float'
   */
  export type FloatFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Float'>
    


  /**
   * Reference to a field of type 'Float[]'
   */
  export type ListFloatFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Float[]'>
    
  /**
   * Deep Input Types
   */


  export type AnalyticsConnectionWhereInput = {
    AND?: AnalyticsConnectionWhereInput | AnalyticsConnectionWhereInput[]
    OR?: AnalyticsConnectionWhereInput[]
    NOT?: AnalyticsConnectionWhereInput | AnalyticsConnectionWhereInput[]
    clientId?: StringFilter<"AnalyticsConnection"> | string
    marketplace?: StringFilter<"AnalyticsConnection"> | string
    accountName?: StringNullableFilter<"AnalyticsConnection"> | string | null
    sellerSid?: StringNullableFilter<"AnalyticsConnection"> | string | null
    apiKeyEncrypted?: StringFilter<"AnalyticsConnection"> | string
    isActive?: BoolFilter<"AnalyticsConnection"> | boolean
    lastVerifiedAt?: DateTimeNullableFilter<"AnalyticsConnection"> | Date | string | null
    createdAt?: DateTimeFilter<"AnalyticsConnection"> | Date | string
    updatedAt?: DateTimeFilter<"AnalyticsConnection"> | Date | string
  }

  export type AnalyticsConnectionOrderByWithRelationInput = {
    clientId?: SortOrder
    marketplace?: SortOrder
    accountName?: SortOrderInput | SortOrder
    sellerSid?: SortOrderInput | SortOrder
    apiKeyEncrypted?: SortOrder
    isActive?: SortOrder
    lastVerifiedAt?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type AnalyticsConnectionWhereUniqueInput = Prisma.AtLeast<{
    clientId?: string
    AND?: AnalyticsConnectionWhereInput | AnalyticsConnectionWhereInput[]
    OR?: AnalyticsConnectionWhereInput[]
    NOT?: AnalyticsConnectionWhereInput | AnalyticsConnectionWhereInput[]
    marketplace?: StringFilter<"AnalyticsConnection"> | string
    accountName?: StringNullableFilter<"AnalyticsConnection"> | string | null
    sellerSid?: StringNullableFilter<"AnalyticsConnection"> | string | null
    apiKeyEncrypted?: StringFilter<"AnalyticsConnection"> | string
    isActive?: BoolFilter<"AnalyticsConnection"> | boolean
    lastVerifiedAt?: DateTimeNullableFilter<"AnalyticsConnection"> | Date | string | null
    createdAt?: DateTimeFilter<"AnalyticsConnection"> | Date | string
    updatedAt?: DateTimeFilter<"AnalyticsConnection"> | Date | string
  }, "clientId">

  export type AnalyticsConnectionOrderByWithAggregationInput = {
    clientId?: SortOrder
    marketplace?: SortOrder
    accountName?: SortOrderInput | SortOrder
    sellerSid?: SortOrderInput | SortOrder
    apiKeyEncrypted?: SortOrder
    isActive?: SortOrder
    lastVerifiedAt?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    _count?: AnalyticsConnectionCountOrderByAggregateInput
    _max?: AnalyticsConnectionMaxOrderByAggregateInput
    _min?: AnalyticsConnectionMinOrderByAggregateInput
  }

  export type AnalyticsConnectionScalarWhereWithAggregatesInput = {
    AND?: AnalyticsConnectionScalarWhereWithAggregatesInput | AnalyticsConnectionScalarWhereWithAggregatesInput[]
    OR?: AnalyticsConnectionScalarWhereWithAggregatesInput[]
    NOT?: AnalyticsConnectionScalarWhereWithAggregatesInput | AnalyticsConnectionScalarWhereWithAggregatesInput[]
    clientId?: StringWithAggregatesFilter<"AnalyticsConnection"> | string
    marketplace?: StringWithAggregatesFilter<"AnalyticsConnection"> | string
    accountName?: StringNullableWithAggregatesFilter<"AnalyticsConnection"> | string | null
    sellerSid?: StringNullableWithAggregatesFilter<"AnalyticsConnection"> | string | null
    apiKeyEncrypted?: StringWithAggregatesFilter<"AnalyticsConnection"> | string
    isActive?: BoolWithAggregatesFilter<"AnalyticsConnection"> | boolean
    lastVerifiedAt?: DateTimeNullableWithAggregatesFilter<"AnalyticsConnection"> | Date | string | null
    createdAt?: DateTimeWithAggregatesFilter<"AnalyticsConnection"> | Date | string
    updatedAt?: DateTimeWithAggregatesFilter<"AnalyticsConnection"> | Date | string
  }

  export type AnalyticsSyncStateWhereInput = {
    AND?: AnalyticsSyncStateWhereInput | AnalyticsSyncStateWhereInput[]
    OR?: AnalyticsSyncStateWhereInput[]
    NOT?: AnalyticsSyncStateWhereInput | AnalyticsSyncStateWhereInput[]
    clientId?: StringFilter<"AnalyticsSyncState"> | string
    marketplace?: StringFilter<"AnalyticsSyncState"> | string
    status?: StringFilter<"AnalyticsSyncState"> | string
    periodDays?: IntFilter<"AnalyticsSyncState"> | number
    currency?: StringFilter<"AnalyticsSyncState"> | string
    productCount?: IntFilter<"AnalyticsSyncState"> | number
    lastStartedAt?: DateTimeNullableFilter<"AnalyticsSyncState"> | Date | string | null
    lastSyncedAt?: DateTimeNullableFilter<"AnalyticsSyncState"> | Date | string | null
    lastError?: StringNullableFilter<"AnalyticsSyncState"> | string | null
    sourceStatus?: JsonNullableFilter<"AnalyticsSyncState">
    createdAt?: DateTimeFilter<"AnalyticsSyncState"> | Date | string
    updatedAt?: DateTimeFilter<"AnalyticsSyncState"> | Date | string
  }

  export type AnalyticsSyncStateOrderByWithRelationInput = {
    clientId?: SortOrder
    marketplace?: SortOrder
    status?: SortOrder
    periodDays?: SortOrder
    currency?: SortOrder
    productCount?: SortOrder
    lastStartedAt?: SortOrderInput | SortOrder
    lastSyncedAt?: SortOrderInput | SortOrder
    lastError?: SortOrderInput | SortOrder
    sourceStatus?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type AnalyticsSyncStateWhereUniqueInput = Prisma.AtLeast<{
    clientId?: string
    AND?: AnalyticsSyncStateWhereInput | AnalyticsSyncStateWhereInput[]
    OR?: AnalyticsSyncStateWhereInput[]
    NOT?: AnalyticsSyncStateWhereInput | AnalyticsSyncStateWhereInput[]
    marketplace?: StringFilter<"AnalyticsSyncState"> | string
    status?: StringFilter<"AnalyticsSyncState"> | string
    periodDays?: IntFilter<"AnalyticsSyncState"> | number
    currency?: StringFilter<"AnalyticsSyncState"> | string
    productCount?: IntFilter<"AnalyticsSyncState"> | number
    lastStartedAt?: DateTimeNullableFilter<"AnalyticsSyncState"> | Date | string | null
    lastSyncedAt?: DateTimeNullableFilter<"AnalyticsSyncState"> | Date | string | null
    lastError?: StringNullableFilter<"AnalyticsSyncState"> | string | null
    sourceStatus?: JsonNullableFilter<"AnalyticsSyncState">
    createdAt?: DateTimeFilter<"AnalyticsSyncState"> | Date | string
    updatedAt?: DateTimeFilter<"AnalyticsSyncState"> | Date | string
  }, "clientId">

  export type AnalyticsSyncStateOrderByWithAggregationInput = {
    clientId?: SortOrder
    marketplace?: SortOrder
    status?: SortOrder
    periodDays?: SortOrder
    currency?: SortOrder
    productCount?: SortOrder
    lastStartedAt?: SortOrderInput | SortOrder
    lastSyncedAt?: SortOrderInput | SortOrder
    lastError?: SortOrderInput | SortOrder
    sourceStatus?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    _count?: AnalyticsSyncStateCountOrderByAggregateInput
    _avg?: AnalyticsSyncStateAvgOrderByAggregateInput
    _max?: AnalyticsSyncStateMaxOrderByAggregateInput
    _min?: AnalyticsSyncStateMinOrderByAggregateInput
    _sum?: AnalyticsSyncStateSumOrderByAggregateInput
  }

  export type AnalyticsSyncStateScalarWhereWithAggregatesInput = {
    AND?: AnalyticsSyncStateScalarWhereWithAggregatesInput | AnalyticsSyncStateScalarWhereWithAggregatesInput[]
    OR?: AnalyticsSyncStateScalarWhereWithAggregatesInput[]
    NOT?: AnalyticsSyncStateScalarWhereWithAggregatesInput | AnalyticsSyncStateScalarWhereWithAggregatesInput[]
    clientId?: StringWithAggregatesFilter<"AnalyticsSyncState"> | string
    marketplace?: StringWithAggregatesFilter<"AnalyticsSyncState"> | string
    status?: StringWithAggregatesFilter<"AnalyticsSyncState"> | string
    periodDays?: IntWithAggregatesFilter<"AnalyticsSyncState"> | number
    currency?: StringWithAggregatesFilter<"AnalyticsSyncState"> | string
    productCount?: IntWithAggregatesFilter<"AnalyticsSyncState"> | number
    lastStartedAt?: DateTimeNullableWithAggregatesFilter<"AnalyticsSyncState"> | Date | string | null
    lastSyncedAt?: DateTimeNullableWithAggregatesFilter<"AnalyticsSyncState"> | Date | string | null
    lastError?: StringNullableWithAggregatesFilter<"AnalyticsSyncState"> | string | null
    sourceStatus?: JsonNullableWithAggregatesFilter<"AnalyticsSyncState">
    createdAt?: DateTimeWithAggregatesFilter<"AnalyticsSyncState"> | Date | string
    updatedAt?: DateTimeWithAggregatesFilter<"AnalyticsSyncState"> | Date | string
  }

  export type AnalyticsProductWhereInput = {
    AND?: AnalyticsProductWhereInput | AnalyticsProductWhereInput[]
    OR?: AnalyticsProductWhereInput[]
    NOT?: AnalyticsProductWhereInput | AnalyticsProductWhereInput[]
    clientId?: StringFilter<"AnalyticsProduct"> | string
    nmId?: StringFilter<"AnalyticsProduct"> | string
    name?: StringFilter<"AnalyticsProduct"> | string
    vendorCode?: StringNullableFilter<"AnalyticsProduct"> | string | null
    brandName?: StringNullableFilter<"AnalyticsProduct"> | string | null
    subjectName?: StringNullableFilter<"AnalyticsProduct"> | string | null
    photoUrl?: StringNullableFilter<"AnalyticsProduct"> | string | null
    availability?: StringNullableFilter<"AnalyticsProduct"> | string | null
    stockCount?: FloatFilter<"AnalyticsProduct"> | number
    stockSum?: FloatFilter<"AnalyticsProduct"> | number
    avgOrders?: FloatFilter<"AnalyticsProduct"> | number
    ordersCount?: FloatFilter<"AnalyticsProduct"> | number
    ordersSum?: FloatFilter<"AnalyticsProduct"> | number
    buyoutCount?: FloatFilter<"AnalyticsProduct"> | number
    buyoutSum?: FloatFilter<"AnalyticsProduct"> | number
    buyoutPercent?: FloatFilter<"AnalyticsProduct"> | number
    lostOrdersCount?: FloatFilter<"AnalyticsProduct"> | number
    lostOrdersSum?: FloatFilter<"AnalyticsProduct"> | number
    lostBuyoutsCount?: FloatFilter<"AnalyticsProduct"> | number
    lostBuyoutsSum?: FloatFilter<"AnalyticsProduct"> | number
    turnoverDays?: FloatNullableFilter<"AnalyticsProduct"> | number | null
    saleRateDays?: FloatNullableFilter<"AnalyticsProduct"> | number | null
    currentPriceMin?: FloatNullableFilter<"AnalyticsProduct"> | number | null
    currentPriceMax?: FloatNullableFilter<"AnalyticsProduct"> | number | null
    openCount?: FloatFilter<"AnalyticsProduct"> | number
    cartCount?: FloatFilter<"AnalyticsProduct"> | number
    orderCount?: FloatFilter<"AnalyticsProduct"> | number
    orderSum?: FloatFilter<"AnalyticsProduct"> | number
    funnelBuyoutCount?: FloatFilter<"AnalyticsProduct"> | number
    funnelBuyoutSum?: FloatFilter<"AnalyticsProduct"> | number
    cancelCount?: FloatFilter<"AnalyticsProduct"> | number
    cancelSum?: FloatFilter<"AnalyticsProduct"> | number
    addToCartPercent?: FloatFilter<"AnalyticsProduct"> | number
    cartToOrderPercent?: FloatFilter<"AnalyticsProduct"> | number
    funnelBuyoutPercent?: FloatFilter<"AnalyticsProduct"> | number
    orderCountDynamic?: FloatFilter<"AnalyticsProduct"> | number
    orderSumDynamic?: FloatFilter<"AnalyticsProduct"> | number
    openCountDynamic?: FloatFilter<"AnalyticsProduct"> | number
    cartCountDynamic?: FloatFilter<"AnalyticsProduct"> | number
    selectedMetrics?: JsonNullableFilter<"AnalyticsProduct">
    pastMetrics?: JsonNullableFilter<"AnalyticsProduct">
    comparisonMetrics?: JsonNullableFilter<"AnalyticsProduct">
    stockMetrics?: JsonNullableFilter<"AnalyticsProduct">
    syncedAt?: DateTimeFilter<"AnalyticsProduct"> | Date | string
  }

  export type AnalyticsProductOrderByWithRelationInput = {
    clientId?: SortOrder
    nmId?: SortOrder
    name?: SortOrder
    vendorCode?: SortOrderInput | SortOrder
    brandName?: SortOrderInput | SortOrder
    subjectName?: SortOrderInput | SortOrder
    photoUrl?: SortOrderInput | SortOrder
    availability?: SortOrderInput | SortOrder
    stockCount?: SortOrder
    stockSum?: SortOrder
    avgOrders?: SortOrder
    ordersCount?: SortOrder
    ordersSum?: SortOrder
    buyoutCount?: SortOrder
    buyoutSum?: SortOrder
    buyoutPercent?: SortOrder
    lostOrdersCount?: SortOrder
    lostOrdersSum?: SortOrder
    lostBuyoutsCount?: SortOrder
    lostBuyoutsSum?: SortOrder
    turnoverDays?: SortOrderInput | SortOrder
    saleRateDays?: SortOrderInput | SortOrder
    currentPriceMin?: SortOrderInput | SortOrder
    currentPriceMax?: SortOrderInput | SortOrder
    openCount?: SortOrder
    cartCount?: SortOrder
    orderCount?: SortOrder
    orderSum?: SortOrder
    funnelBuyoutCount?: SortOrder
    funnelBuyoutSum?: SortOrder
    cancelCount?: SortOrder
    cancelSum?: SortOrder
    addToCartPercent?: SortOrder
    cartToOrderPercent?: SortOrder
    funnelBuyoutPercent?: SortOrder
    orderCountDynamic?: SortOrder
    orderSumDynamic?: SortOrder
    openCountDynamic?: SortOrder
    cartCountDynamic?: SortOrder
    selectedMetrics?: SortOrderInput | SortOrder
    pastMetrics?: SortOrderInput | SortOrder
    comparisonMetrics?: SortOrderInput | SortOrder
    stockMetrics?: SortOrderInput | SortOrder
    syncedAt?: SortOrder
  }

  export type AnalyticsProductWhereUniqueInput = Prisma.AtLeast<{
    clientId_nmId?: AnalyticsProductClientIdNmIdCompoundUniqueInput
    AND?: AnalyticsProductWhereInput | AnalyticsProductWhereInput[]
    OR?: AnalyticsProductWhereInput[]
    NOT?: AnalyticsProductWhereInput | AnalyticsProductWhereInput[]
    clientId?: StringFilter<"AnalyticsProduct"> | string
    nmId?: StringFilter<"AnalyticsProduct"> | string
    name?: StringFilter<"AnalyticsProduct"> | string
    vendorCode?: StringNullableFilter<"AnalyticsProduct"> | string | null
    brandName?: StringNullableFilter<"AnalyticsProduct"> | string | null
    subjectName?: StringNullableFilter<"AnalyticsProduct"> | string | null
    photoUrl?: StringNullableFilter<"AnalyticsProduct"> | string | null
    availability?: StringNullableFilter<"AnalyticsProduct"> | string | null
    stockCount?: FloatFilter<"AnalyticsProduct"> | number
    stockSum?: FloatFilter<"AnalyticsProduct"> | number
    avgOrders?: FloatFilter<"AnalyticsProduct"> | number
    ordersCount?: FloatFilter<"AnalyticsProduct"> | number
    ordersSum?: FloatFilter<"AnalyticsProduct"> | number
    buyoutCount?: FloatFilter<"AnalyticsProduct"> | number
    buyoutSum?: FloatFilter<"AnalyticsProduct"> | number
    buyoutPercent?: FloatFilter<"AnalyticsProduct"> | number
    lostOrdersCount?: FloatFilter<"AnalyticsProduct"> | number
    lostOrdersSum?: FloatFilter<"AnalyticsProduct"> | number
    lostBuyoutsCount?: FloatFilter<"AnalyticsProduct"> | number
    lostBuyoutsSum?: FloatFilter<"AnalyticsProduct"> | number
    turnoverDays?: FloatNullableFilter<"AnalyticsProduct"> | number | null
    saleRateDays?: FloatNullableFilter<"AnalyticsProduct"> | number | null
    currentPriceMin?: FloatNullableFilter<"AnalyticsProduct"> | number | null
    currentPriceMax?: FloatNullableFilter<"AnalyticsProduct"> | number | null
    openCount?: FloatFilter<"AnalyticsProduct"> | number
    cartCount?: FloatFilter<"AnalyticsProduct"> | number
    orderCount?: FloatFilter<"AnalyticsProduct"> | number
    orderSum?: FloatFilter<"AnalyticsProduct"> | number
    funnelBuyoutCount?: FloatFilter<"AnalyticsProduct"> | number
    funnelBuyoutSum?: FloatFilter<"AnalyticsProduct"> | number
    cancelCount?: FloatFilter<"AnalyticsProduct"> | number
    cancelSum?: FloatFilter<"AnalyticsProduct"> | number
    addToCartPercent?: FloatFilter<"AnalyticsProduct"> | number
    cartToOrderPercent?: FloatFilter<"AnalyticsProduct"> | number
    funnelBuyoutPercent?: FloatFilter<"AnalyticsProduct"> | number
    orderCountDynamic?: FloatFilter<"AnalyticsProduct"> | number
    orderSumDynamic?: FloatFilter<"AnalyticsProduct"> | number
    openCountDynamic?: FloatFilter<"AnalyticsProduct"> | number
    cartCountDynamic?: FloatFilter<"AnalyticsProduct"> | number
    selectedMetrics?: JsonNullableFilter<"AnalyticsProduct">
    pastMetrics?: JsonNullableFilter<"AnalyticsProduct">
    comparisonMetrics?: JsonNullableFilter<"AnalyticsProduct">
    stockMetrics?: JsonNullableFilter<"AnalyticsProduct">
    syncedAt?: DateTimeFilter<"AnalyticsProduct"> | Date | string
  }, "clientId_nmId">

  export type AnalyticsProductOrderByWithAggregationInput = {
    clientId?: SortOrder
    nmId?: SortOrder
    name?: SortOrder
    vendorCode?: SortOrderInput | SortOrder
    brandName?: SortOrderInput | SortOrder
    subjectName?: SortOrderInput | SortOrder
    photoUrl?: SortOrderInput | SortOrder
    availability?: SortOrderInput | SortOrder
    stockCount?: SortOrder
    stockSum?: SortOrder
    avgOrders?: SortOrder
    ordersCount?: SortOrder
    ordersSum?: SortOrder
    buyoutCount?: SortOrder
    buyoutSum?: SortOrder
    buyoutPercent?: SortOrder
    lostOrdersCount?: SortOrder
    lostOrdersSum?: SortOrder
    lostBuyoutsCount?: SortOrder
    lostBuyoutsSum?: SortOrder
    turnoverDays?: SortOrderInput | SortOrder
    saleRateDays?: SortOrderInput | SortOrder
    currentPriceMin?: SortOrderInput | SortOrder
    currentPriceMax?: SortOrderInput | SortOrder
    openCount?: SortOrder
    cartCount?: SortOrder
    orderCount?: SortOrder
    orderSum?: SortOrder
    funnelBuyoutCount?: SortOrder
    funnelBuyoutSum?: SortOrder
    cancelCount?: SortOrder
    cancelSum?: SortOrder
    addToCartPercent?: SortOrder
    cartToOrderPercent?: SortOrder
    funnelBuyoutPercent?: SortOrder
    orderCountDynamic?: SortOrder
    orderSumDynamic?: SortOrder
    openCountDynamic?: SortOrder
    cartCountDynamic?: SortOrder
    selectedMetrics?: SortOrderInput | SortOrder
    pastMetrics?: SortOrderInput | SortOrder
    comparisonMetrics?: SortOrderInput | SortOrder
    stockMetrics?: SortOrderInput | SortOrder
    syncedAt?: SortOrder
    _count?: AnalyticsProductCountOrderByAggregateInput
    _avg?: AnalyticsProductAvgOrderByAggregateInput
    _max?: AnalyticsProductMaxOrderByAggregateInput
    _min?: AnalyticsProductMinOrderByAggregateInput
    _sum?: AnalyticsProductSumOrderByAggregateInput
  }

  export type AnalyticsProductScalarWhereWithAggregatesInput = {
    AND?: AnalyticsProductScalarWhereWithAggregatesInput | AnalyticsProductScalarWhereWithAggregatesInput[]
    OR?: AnalyticsProductScalarWhereWithAggregatesInput[]
    NOT?: AnalyticsProductScalarWhereWithAggregatesInput | AnalyticsProductScalarWhereWithAggregatesInput[]
    clientId?: StringWithAggregatesFilter<"AnalyticsProduct"> | string
    nmId?: StringWithAggregatesFilter<"AnalyticsProduct"> | string
    name?: StringWithAggregatesFilter<"AnalyticsProduct"> | string
    vendorCode?: StringNullableWithAggregatesFilter<"AnalyticsProduct"> | string | null
    brandName?: StringNullableWithAggregatesFilter<"AnalyticsProduct"> | string | null
    subjectName?: StringNullableWithAggregatesFilter<"AnalyticsProduct"> | string | null
    photoUrl?: StringNullableWithAggregatesFilter<"AnalyticsProduct"> | string | null
    availability?: StringNullableWithAggregatesFilter<"AnalyticsProduct"> | string | null
    stockCount?: FloatWithAggregatesFilter<"AnalyticsProduct"> | number
    stockSum?: FloatWithAggregatesFilter<"AnalyticsProduct"> | number
    avgOrders?: FloatWithAggregatesFilter<"AnalyticsProduct"> | number
    ordersCount?: FloatWithAggregatesFilter<"AnalyticsProduct"> | number
    ordersSum?: FloatWithAggregatesFilter<"AnalyticsProduct"> | number
    buyoutCount?: FloatWithAggregatesFilter<"AnalyticsProduct"> | number
    buyoutSum?: FloatWithAggregatesFilter<"AnalyticsProduct"> | number
    buyoutPercent?: FloatWithAggregatesFilter<"AnalyticsProduct"> | number
    lostOrdersCount?: FloatWithAggregatesFilter<"AnalyticsProduct"> | number
    lostOrdersSum?: FloatWithAggregatesFilter<"AnalyticsProduct"> | number
    lostBuyoutsCount?: FloatWithAggregatesFilter<"AnalyticsProduct"> | number
    lostBuyoutsSum?: FloatWithAggregatesFilter<"AnalyticsProduct"> | number
    turnoverDays?: FloatNullableWithAggregatesFilter<"AnalyticsProduct"> | number | null
    saleRateDays?: FloatNullableWithAggregatesFilter<"AnalyticsProduct"> | number | null
    currentPriceMin?: FloatNullableWithAggregatesFilter<"AnalyticsProduct"> | number | null
    currentPriceMax?: FloatNullableWithAggregatesFilter<"AnalyticsProduct"> | number | null
    openCount?: FloatWithAggregatesFilter<"AnalyticsProduct"> | number
    cartCount?: FloatWithAggregatesFilter<"AnalyticsProduct"> | number
    orderCount?: FloatWithAggregatesFilter<"AnalyticsProduct"> | number
    orderSum?: FloatWithAggregatesFilter<"AnalyticsProduct"> | number
    funnelBuyoutCount?: FloatWithAggregatesFilter<"AnalyticsProduct"> | number
    funnelBuyoutSum?: FloatWithAggregatesFilter<"AnalyticsProduct"> | number
    cancelCount?: FloatWithAggregatesFilter<"AnalyticsProduct"> | number
    cancelSum?: FloatWithAggregatesFilter<"AnalyticsProduct"> | number
    addToCartPercent?: FloatWithAggregatesFilter<"AnalyticsProduct"> | number
    cartToOrderPercent?: FloatWithAggregatesFilter<"AnalyticsProduct"> | number
    funnelBuyoutPercent?: FloatWithAggregatesFilter<"AnalyticsProduct"> | number
    orderCountDynamic?: FloatWithAggregatesFilter<"AnalyticsProduct"> | number
    orderSumDynamic?: FloatWithAggregatesFilter<"AnalyticsProduct"> | number
    openCountDynamic?: FloatWithAggregatesFilter<"AnalyticsProduct"> | number
    cartCountDynamic?: FloatWithAggregatesFilter<"AnalyticsProduct"> | number
    selectedMetrics?: JsonNullableWithAggregatesFilter<"AnalyticsProduct">
    pastMetrics?: JsonNullableWithAggregatesFilter<"AnalyticsProduct">
    comparisonMetrics?: JsonNullableWithAggregatesFilter<"AnalyticsProduct">
    stockMetrics?: JsonNullableWithAggregatesFilter<"AnalyticsProduct">
    syncedAt?: DateTimeWithAggregatesFilter<"AnalyticsProduct"> | Date | string
  }

  export type AnalyticsRegionWhereInput = {
    AND?: AnalyticsRegionWhereInput | AnalyticsRegionWhereInput[]
    OR?: AnalyticsRegionWhereInput[]
    NOT?: AnalyticsRegionWhereInput | AnalyticsRegionWhereInput[]
    clientId?: StringFilter<"AnalyticsRegion"> | string
    regionKey?: StringFilter<"AnalyticsRegion"> | string
    regionName?: StringFilter<"AnalyticsRegion"> | string
    officeId?: StringNullableFilter<"AnalyticsRegion"> | string | null
    officeName?: StringNullableFilter<"AnalyticsRegion"> | string | null
    stockCount?: FloatFilter<"AnalyticsRegion"> | number
    stockSum?: FloatFilter<"AnalyticsRegion"> | number
    toClientCount?: FloatFilter<"AnalyticsRegion"> | number
    fromClientCount?: FloatFilter<"AnalyticsRegion"> | number
    saleRateDays?: FloatNullableFilter<"AnalyticsRegion"> | number | null
    metrics?: JsonNullableFilter<"AnalyticsRegion">
    syncedAt?: DateTimeFilter<"AnalyticsRegion"> | Date | string
  }

  export type AnalyticsRegionOrderByWithRelationInput = {
    clientId?: SortOrder
    regionKey?: SortOrder
    regionName?: SortOrder
    officeId?: SortOrderInput | SortOrder
    officeName?: SortOrderInput | SortOrder
    stockCount?: SortOrder
    stockSum?: SortOrder
    toClientCount?: SortOrder
    fromClientCount?: SortOrder
    saleRateDays?: SortOrderInput | SortOrder
    metrics?: SortOrderInput | SortOrder
    syncedAt?: SortOrder
  }

  export type AnalyticsRegionWhereUniqueInput = Prisma.AtLeast<{
    clientId_regionKey?: AnalyticsRegionClientIdRegionKeyCompoundUniqueInput
    AND?: AnalyticsRegionWhereInput | AnalyticsRegionWhereInput[]
    OR?: AnalyticsRegionWhereInput[]
    NOT?: AnalyticsRegionWhereInput | AnalyticsRegionWhereInput[]
    clientId?: StringFilter<"AnalyticsRegion"> | string
    regionKey?: StringFilter<"AnalyticsRegion"> | string
    regionName?: StringFilter<"AnalyticsRegion"> | string
    officeId?: StringNullableFilter<"AnalyticsRegion"> | string | null
    officeName?: StringNullableFilter<"AnalyticsRegion"> | string | null
    stockCount?: FloatFilter<"AnalyticsRegion"> | number
    stockSum?: FloatFilter<"AnalyticsRegion"> | number
    toClientCount?: FloatFilter<"AnalyticsRegion"> | number
    fromClientCount?: FloatFilter<"AnalyticsRegion"> | number
    saleRateDays?: FloatNullableFilter<"AnalyticsRegion"> | number | null
    metrics?: JsonNullableFilter<"AnalyticsRegion">
    syncedAt?: DateTimeFilter<"AnalyticsRegion"> | Date | string
  }, "clientId_regionKey">

  export type AnalyticsRegionOrderByWithAggregationInput = {
    clientId?: SortOrder
    regionKey?: SortOrder
    regionName?: SortOrder
    officeId?: SortOrderInput | SortOrder
    officeName?: SortOrderInput | SortOrder
    stockCount?: SortOrder
    stockSum?: SortOrder
    toClientCount?: SortOrder
    fromClientCount?: SortOrder
    saleRateDays?: SortOrderInput | SortOrder
    metrics?: SortOrderInput | SortOrder
    syncedAt?: SortOrder
    _count?: AnalyticsRegionCountOrderByAggregateInput
    _avg?: AnalyticsRegionAvgOrderByAggregateInput
    _max?: AnalyticsRegionMaxOrderByAggregateInput
    _min?: AnalyticsRegionMinOrderByAggregateInput
    _sum?: AnalyticsRegionSumOrderByAggregateInput
  }

  export type AnalyticsRegionScalarWhereWithAggregatesInput = {
    AND?: AnalyticsRegionScalarWhereWithAggregatesInput | AnalyticsRegionScalarWhereWithAggregatesInput[]
    OR?: AnalyticsRegionScalarWhereWithAggregatesInput[]
    NOT?: AnalyticsRegionScalarWhereWithAggregatesInput | AnalyticsRegionScalarWhereWithAggregatesInput[]
    clientId?: StringWithAggregatesFilter<"AnalyticsRegion"> | string
    regionKey?: StringWithAggregatesFilter<"AnalyticsRegion"> | string
    regionName?: StringWithAggregatesFilter<"AnalyticsRegion"> | string
    officeId?: StringNullableWithAggregatesFilter<"AnalyticsRegion"> | string | null
    officeName?: StringNullableWithAggregatesFilter<"AnalyticsRegion"> | string | null
    stockCount?: FloatWithAggregatesFilter<"AnalyticsRegion"> | number
    stockSum?: FloatWithAggregatesFilter<"AnalyticsRegion"> | number
    toClientCount?: FloatWithAggregatesFilter<"AnalyticsRegion"> | number
    fromClientCount?: FloatWithAggregatesFilter<"AnalyticsRegion"> | number
    saleRateDays?: FloatNullableWithAggregatesFilter<"AnalyticsRegion"> | number | null
    metrics?: JsonNullableWithAggregatesFilter<"AnalyticsRegion">
    syncedAt?: DateTimeWithAggregatesFilter<"AnalyticsRegion"> | Date | string
  }

  export type AnalyticsDailySummaryWhereInput = {
    AND?: AnalyticsDailySummaryWhereInput | AnalyticsDailySummaryWhereInput[]
    OR?: AnalyticsDailySummaryWhereInput[]
    NOT?: AnalyticsDailySummaryWhereInput | AnalyticsDailySummaryWhereInput[]
    clientId?: StringFilter<"AnalyticsDailySummary"> | string
    snapshotDate?: DateTimeFilter<"AnalyticsDailySummary"> | Date | string
    periodDays?: IntFilter<"AnalyticsDailySummary"> | number
    productCount?: IntFilter<"AnalyticsDailySummary"> | number
    stockCount?: FloatFilter<"AnalyticsDailySummary"> | number
    stockSum?: FloatFilter<"AnalyticsDailySummary"> | number
    ordersCount?: FloatFilter<"AnalyticsDailySummary"> | number
    ordersSum?: FloatFilter<"AnalyticsDailySummary"> | number
    buyoutCount?: FloatFilter<"AnalyticsDailySummary"> | number
    buyoutSum?: FloatFilter<"AnalyticsDailySummary"> | number
    lostOrdersSum?: FloatFilter<"AnalyticsDailySummary"> | number
    createdAt?: DateTimeFilter<"AnalyticsDailySummary"> | Date | string
    updatedAt?: DateTimeFilter<"AnalyticsDailySummary"> | Date | string
  }

  export type AnalyticsDailySummaryOrderByWithRelationInput = {
    clientId?: SortOrder
    snapshotDate?: SortOrder
    periodDays?: SortOrder
    productCount?: SortOrder
    stockCount?: SortOrder
    stockSum?: SortOrder
    ordersCount?: SortOrder
    ordersSum?: SortOrder
    buyoutCount?: SortOrder
    buyoutSum?: SortOrder
    lostOrdersSum?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type AnalyticsDailySummaryWhereUniqueInput = Prisma.AtLeast<{
    clientId_snapshotDate?: AnalyticsDailySummaryClientIdSnapshotDateCompoundUniqueInput
    AND?: AnalyticsDailySummaryWhereInput | AnalyticsDailySummaryWhereInput[]
    OR?: AnalyticsDailySummaryWhereInput[]
    NOT?: AnalyticsDailySummaryWhereInput | AnalyticsDailySummaryWhereInput[]
    clientId?: StringFilter<"AnalyticsDailySummary"> | string
    snapshotDate?: DateTimeFilter<"AnalyticsDailySummary"> | Date | string
    periodDays?: IntFilter<"AnalyticsDailySummary"> | number
    productCount?: IntFilter<"AnalyticsDailySummary"> | number
    stockCount?: FloatFilter<"AnalyticsDailySummary"> | number
    stockSum?: FloatFilter<"AnalyticsDailySummary"> | number
    ordersCount?: FloatFilter<"AnalyticsDailySummary"> | number
    ordersSum?: FloatFilter<"AnalyticsDailySummary"> | number
    buyoutCount?: FloatFilter<"AnalyticsDailySummary"> | number
    buyoutSum?: FloatFilter<"AnalyticsDailySummary"> | number
    lostOrdersSum?: FloatFilter<"AnalyticsDailySummary"> | number
    createdAt?: DateTimeFilter<"AnalyticsDailySummary"> | Date | string
    updatedAt?: DateTimeFilter<"AnalyticsDailySummary"> | Date | string
  }, "clientId_snapshotDate">

  export type AnalyticsDailySummaryOrderByWithAggregationInput = {
    clientId?: SortOrder
    snapshotDate?: SortOrder
    periodDays?: SortOrder
    productCount?: SortOrder
    stockCount?: SortOrder
    stockSum?: SortOrder
    ordersCount?: SortOrder
    ordersSum?: SortOrder
    buyoutCount?: SortOrder
    buyoutSum?: SortOrder
    lostOrdersSum?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    _count?: AnalyticsDailySummaryCountOrderByAggregateInput
    _avg?: AnalyticsDailySummaryAvgOrderByAggregateInput
    _max?: AnalyticsDailySummaryMaxOrderByAggregateInput
    _min?: AnalyticsDailySummaryMinOrderByAggregateInput
    _sum?: AnalyticsDailySummarySumOrderByAggregateInput
  }

  export type AnalyticsDailySummaryScalarWhereWithAggregatesInput = {
    AND?: AnalyticsDailySummaryScalarWhereWithAggregatesInput | AnalyticsDailySummaryScalarWhereWithAggregatesInput[]
    OR?: AnalyticsDailySummaryScalarWhereWithAggregatesInput[]
    NOT?: AnalyticsDailySummaryScalarWhereWithAggregatesInput | AnalyticsDailySummaryScalarWhereWithAggregatesInput[]
    clientId?: StringWithAggregatesFilter<"AnalyticsDailySummary"> | string
    snapshotDate?: DateTimeWithAggregatesFilter<"AnalyticsDailySummary"> | Date | string
    periodDays?: IntWithAggregatesFilter<"AnalyticsDailySummary"> | number
    productCount?: IntWithAggregatesFilter<"AnalyticsDailySummary"> | number
    stockCount?: FloatWithAggregatesFilter<"AnalyticsDailySummary"> | number
    stockSum?: FloatWithAggregatesFilter<"AnalyticsDailySummary"> | number
    ordersCount?: FloatWithAggregatesFilter<"AnalyticsDailySummary"> | number
    ordersSum?: FloatWithAggregatesFilter<"AnalyticsDailySummary"> | number
    buyoutCount?: FloatWithAggregatesFilter<"AnalyticsDailySummary"> | number
    buyoutSum?: FloatWithAggregatesFilter<"AnalyticsDailySummary"> | number
    lostOrdersSum?: FloatWithAggregatesFilter<"AnalyticsDailySummary"> | number
    createdAt?: DateTimeWithAggregatesFilter<"AnalyticsDailySummary"> | Date | string
    updatedAt?: DateTimeWithAggregatesFilter<"AnalyticsDailySummary"> | Date | string
  }

  export type AnalyticsConnectionCreateInput = {
    clientId: string
    marketplace?: string
    accountName?: string | null
    sellerSid?: string | null
    apiKeyEncrypted: string
    isActive?: boolean
    lastVerifiedAt?: Date | string | null
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type AnalyticsConnectionUncheckedCreateInput = {
    clientId: string
    marketplace?: string
    accountName?: string | null
    sellerSid?: string | null
    apiKeyEncrypted: string
    isActive?: boolean
    lastVerifiedAt?: Date | string | null
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type AnalyticsConnectionUpdateInput = {
    clientId?: StringFieldUpdateOperationsInput | string
    marketplace?: StringFieldUpdateOperationsInput | string
    accountName?: NullableStringFieldUpdateOperationsInput | string | null
    sellerSid?: NullableStringFieldUpdateOperationsInput | string | null
    apiKeyEncrypted?: StringFieldUpdateOperationsInput | string
    isActive?: BoolFieldUpdateOperationsInput | boolean
    lastVerifiedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type AnalyticsConnectionUncheckedUpdateInput = {
    clientId?: StringFieldUpdateOperationsInput | string
    marketplace?: StringFieldUpdateOperationsInput | string
    accountName?: NullableStringFieldUpdateOperationsInput | string | null
    sellerSid?: NullableStringFieldUpdateOperationsInput | string | null
    apiKeyEncrypted?: StringFieldUpdateOperationsInput | string
    isActive?: BoolFieldUpdateOperationsInput | boolean
    lastVerifiedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type AnalyticsConnectionCreateManyInput = {
    clientId: string
    marketplace?: string
    accountName?: string | null
    sellerSid?: string | null
    apiKeyEncrypted: string
    isActive?: boolean
    lastVerifiedAt?: Date | string | null
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type AnalyticsConnectionUpdateManyMutationInput = {
    clientId?: StringFieldUpdateOperationsInput | string
    marketplace?: StringFieldUpdateOperationsInput | string
    accountName?: NullableStringFieldUpdateOperationsInput | string | null
    sellerSid?: NullableStringFieldUpdateOperationsInput | string | null
    apiKeyEncrypted?: StringFieldUpdateOperationsInput | string
    isActive?: BoolFieldUpdateOperationsInput | boolean
    lastVerifiedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type AnalyticsConnectionUncheckedUpdateManyInput = {
    clientId?: StringFieldUpdateOperationsInput | string
    marketplace?: StringFieldUpdateOperationsInput | string
    accountName?: NullableStringFieldUpdateOperationsInput | string | null
    sellerSid?: NullableStringFieldUpdateOperationsInput | string | null
    apiKeyEncrypted?: StringFieldUpdateOperationsInput | string
    isActive?: BoolFieldUpdateOperationsInput | boolean
    lastVerifiedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type AnalyticsSyncStateCreateInput = {
    clientId: string
    marketplace?: string
    status?: string
    periodDays?: number
    currency?: string
    productCount?: number
    lastStartedAt?: Date | string | null
    lastSyncedAt?: Date | string | null
    lastError?: string | null
    sourceStatus?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type AnalyticsSyncStateUncheckedCreateInput = {
    clientId: string
    marketplace?: string
    status?: string
    periodDays?: number
    currency?: string
    productCount?: number
    lastStartedAt?: Date | string | null
    lastSyncedAt?: Date | string | null
    lastError?: string | null
    sourceStatus?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type AnalyticsSyncStateUpdateInput = {
    clientId?: StringFieldUpdateOperationsInput | string
    marketplace?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    periodDays?: IntFieldUpdateOperationsInput | number
    currency?: StringFieldUpdateOperationsInput | string
    productCount?: IntFieldUpdateOperationsInput | number
    lastStartedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    lastSyncedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    lastError?: NullableStringFieldUpdateOperationsInput | string | null
    sourceStatus?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type AnalyticsSyncStateUncheckedUpdateInput = {
    clientId?: StringFieldUpdateOperationsInput | string
    marketplace?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    periodDays?: IntFieldUpdateOperationsInput | number
    currency?: StringFieldUpdateOperationsInput | string
    productCount?: IntFieldUpdateOperationsInput | number
    lastStartedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    lastSyncedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    lastError?: NullableStringFieldUpdateOperationsInput | string | null
    sourceStatus?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type AnalyticsSyncStateCreateManyInput = {
    clientId: string
    marketplace?: string
    status?: string
    periodDays?: number
    currency?: string
    productCount?: number
    lastStartedAt?: Date | string | null
    lastSyncedAt?: Date | string | null
    lastError?: string | null
    sourceStatus?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type AnalyticsSyncStateUpdateManyMutationInput = {
    clientId?: StringFieldUpdateOperationsInput | string
    marketplace?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    periodDays?: IntFieldUpdateOperationsInput | number
    currency?: StringFieldUpdateOperationsInput | string
    productCount?: IntFieldUpdateOperationsInput | number
    lastStartedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    lastSyncedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    lastError?: NullableStringFieldUpdateOperationsInput | string | null
    sourceStatus?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type AnalyticsSyncStateUncheckedUpdateManyInput = {
    clientId?: StringFieldUpdateOperationsInput | string
    marketplace?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    periodDays?: IntFieldUpdateOperationsInput | number
    currency?: StringFieldUpdateOperationsInput | string
    productCount?: IntFieldUpdateOperationsInput | number
    lastStartedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    lastSyncedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    lastError?: NullableStringFieldUpdateOperationsInput | string | null
    sourceStatus?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type AnalyticsProductCreateInput = {
    clientId: string
    nmId: string
    name: string
    vendorCode?: string | null
    brandName?: string | null
    subjectName?: string | null
    photoUrl?: string | null
    availability?: string | null
    stockCount?: number
    stockSum?: number
    avgOrders?: number
    ordersCount?: number
    ordersSum?: number
    buyoutCount?: number
    buyoutSum?: number
    buyoutPercent?: number
    lostOrdersCount?: number
    lostOrdersSum?: number
    lostBuyoutsCount?: number
    lostBuyoutsSum?: number
    turnoverDays?: number | null
    saleRateDays?: number | null
    currentPriceMin?: number | null
    currentPriceMax?: number | null
    openCount?: number
    cartCount?: number
    orderCount?: number
    orderSum?: number
    funnelBuyoutCount?: number
    funnelBuyoutSum?: number
    cancelCount?: number
    cancelSum?: number
    addToCartPercent?: number
    cartToOrderPercent?: number
    funnelBuyoutPercent?: number
    orderCountDynamic?: number
    orderSumDynamic?: number
    openCountDynamic?: number
    cartCountDynamic?: number
    selectedMetrics?: NullableJsonNullValueInput | InputJsonValue
    pastMetrics?: NullableJsonNullValueInput | InputJsonValue
    comparisonMetrics?: NullableJsonNullValueInput | InputJsonValue
    stockMetrics?: NullableJsonNullValueInput | InputJsonValue
    syncedAt: Date | string
  }

  export type AnalyticsProductUncheckedCreateInput = {
    clientId: string
    nmId: string
    name: string
    vendorCode?: string | null
    brandName?: string | null
    subjectName?: string | null
    photoUrl?: string | null
    availability?: string | null
    stockCount?: number
    stockSum?: number
    avgOrders?: number
    ordersCount?: number
    ordersSum?: number
    buyoutCount?: number
    buyoutSum?: number
    buyoutPercent?: number
    lostOrdersCount?: number
    lostOrdersSum?: number
    lostBuyoutsCount?: number
    lostBuyoutsSum?: number
    turnoverDays?: number | null
    saleRateDays?: number | null
    currentPriceMin?: number | null
    currentPriceMax?: number | null
    openCount?: number
    cartCount?: number
    orderCount?: number
    orderSum?: number
    funnelBuyoutCount?: number
    funnelBuyoutSum?: number
    cancelCount?: number
    cancelSum?: number
    addToCartPercent?: number
    cartToOrderPercent?: number
    funnelBuyoutPercent?: number
    orderCountDynamic?: number
    orderSumDynamic?: number
    openCountDynamic?: number
    cartCountDynamic?: number
    selectedMetrics?: NullableJsonNullValueInput | InputJsonValue
    pastMetrics?: NullableJsonNullValueInput | InputJsonValue
    comparisonMetrics?: NullableJsonNullValueInput | InputJsonValue
    stockMetrics?: NullableJsonNullValueInput | InputJsonValue
    syncedAt: Date | string
  }

  export type AnalyticsProductUpdateInput = {
    clientId?: StringFieldUpdateOperationsInput | string
    nmId?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    vendorCode?: NullableStringFieldUpdateOperationsInput | string | null
    brandName?: NullableStringFieldUpdateOperationsInput | string | null
    subjectName?: NullableStringFieldUpdateOperationsInput | string | null
    photoUrl?: NullableStringFieldUpdateOperationsInput | string | null
    availability?: NullableStringFieldUpdateOperationsInput | string | null
    stockCount?: FloatFieldUpdateOperationsInput | number
    stockSum?: FloatFieldUpdateOperationsInput | number
    avgOrders?: FloatFieldUpdateOperationsInput | number
    ordersCount?: FloatFieldUpdateOperationsInput | number
    ordersSum?: FloatFieldUpdateOperationsInput | number
    buyoutCount?: FloatFieldUpdateOperationsInput | number
    buyoutSum?: FloatFieldUpdateOperationsInput | number
    buyoutPercent?: FloatFieldUpdateOperationsInput | number
    lostOrdersCount?: FloatFieldUpdateOperationsInput | number
    lostOrdersSum?: FloatFieldUpdateOperationsInput | number
    lostBuyoutsCount?: FloatFieldUpdateOperationsInput | number
    lostBuyoutsSum?: FloatFieldUpdateOperationsInput | number
    turnoverDays?: NullableFloatFieldUpdateOperationsInput | number | null
    saleRateDays?: NullableFloatFieldUpdateOperationsInput | number | null
    currentPriceMin?: NullableFloatFieldUpdateOperationsInput | number | null
    currentPriceMax?: NullableFloatFieldUpdateOperationsInput | number | null
    openCount?: FloatFieldUpdateOperationsInput | number
    cartCount?: FloatFieldUpdateOperationsInput | number
    orderCount?: FloatFieldUpdateOperationsInput | number
    orderSum?: FloatFieldUpdateOperationsInput | number
    funnelBuyoutCount?: FloatFieldUpdateOperationsInput | number
    funnelBuyoutSum?: FloatFieldUpdateOperationsInput | number
    cancelCount?: FloatFieldUpdateOperationsInput | number
    cancelSum?: FloatFieldUpdateOperationsInput | number
    addToCartPercent?: FloatFieldUpdateOperationsInput | number
    cartToOrderPercent?: FloatFieldUpdateOperationsInput | number
    funnelBuyoutPercent?: FloatFieldUpdateOperationsInput | number
    orderCountDynamic?: FloatFieldUpdateOperationsInput | number
    orderSumDynamic?: FloatFieldUpdateOperationsInput | number
    openCountDynamic?: FloatFieldUpdateOperationsInput | number
    cartCountDynamic?: FloatFieldUpdateOperationsInput | number
    selectedMetrics?: NullableJsonNullValueInput | InputJsonValue
    pastMetrics?: NullableJsonNullValueInput | InputJsonValue
    comparisonMetrics?: NullableJsonNullValueInput | InputJsonValue
    stockMetrics?: NullableJsonNullValueInput | InputJsonValue
    syncedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type AnalyticsProductUncheckedUpdateInput = {
    clientId?: StringFieldUpdateOperationsInput | string
    nmId?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    vendorCode?: NullableStringFieldUpdateOperationsInput | string | null
    brandName?: NullableStringFieldUpdateOperationsInput | string | null
    subjectName?: NullableStringFieldUpdateOperationsInput | string | null
    photoUrl?: NullableStringFieldUpdateOperationsInput | string | null
    availability?: NullableStringFieldUpdateOperationsInput | string | null
    stockCount?: FloatFieldUpdateOperationsInput | number
    stockSum?: FloatFieldUpdateOperationsInput | number
    avgOrders?: FloatFieldUpdateOperationsInput | number
    ordersCount?: FloatFieldUpdateOperationsInput | number
    ordersSum?: FloatFieldUpdateOperationsInput | number
    buyoutCount?: FloatFieldUpdateOperationsInput | number
    buyoutSum?: FloatFieldUpdateOperationsInput | number
    buyoutPercent?: FloatFieldUpdateOperationsInput | number
    lostOrdersCount?: FloatFieldUpdateOperationsInput | number
    lostOrdersSum?: FloatFieldUpdateOperationsInput | number
    lostBuyoutsCount?: FloatFieldUpdateOperationsInput | number
    lostBuyoutsSum?: FloatFieldUpdateOperationsInput | number
    turnoverDays?: NullableFloatFieldUpdateOperationsInput | number | null
    saleRateDays?: NullableFloatFieldUpdateOperationsInput | number | null
    currentPriceMin?: NullableFloatFieldUpdateOperationsInput | number | null
    currentPriceMax?: NullableFloatFieldUpdateOperationsInput | number | null
    openCount?: FloatFieldUpdateOperationsInput | number
    cartCount?: FloatFieldUpdateOperationsInput | number
    orderCount?: FloatFieldUpdateOperationsInput | number
    orderSum?: FloatFieldUpdateOperationsInput | number
    funnelBuyoutCount?: FloatFieldUpdateOperationsInput | number
    funnelBuyoutSum?: FloatFieldUpdateOperationsInput | number
    cancelCount?: FloatFieldUpdateOperationsInput | number
    cancelSum?: FloatFieldUpdateOperationsInput | number
    addToCartPercent?: FloatFieldUpdateOperationsInput | number
    cartToOrderPercent?: FloatFieldUpdateOperationsInput | number
    funnelBuyoutPercent?: FloatFieldUpdateOperationsInput | number
    orderCountDynamic?: FloatFieldUpdateOperationsInput | number
    orderSumDynamic?: FloatFieldUpdateOperationsInput | number
    openCountDynamic?: FloatFieldUpdateOperationsInput | number
    cartCountDynamic?: FloatFieldUpdateOperationsInput | number
    selectedMetrics?: NullableJsonNullValueInput | InputJsonValue
    pastMetrics?: NullableJsonNullValueInput | InputJsonValue
    comparisonMetrics?: NullableJsonNullValueInput | InputJsonValue
    stockMetrics?: NullableJsonNullValueInput | InputJsonValue
    syncedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type AnalyticsProductCreateManyInput = {
    clientId: string
    nmId: string
    name: string
    vendorCode?: string | null
    brandName?: string | null
    subjectName?: string | null
    photoUrl?: string | null
    availability?: string | null
    stockCount?: number
    stockSum?: number
    avgOrders?: number
    ordersCount?: number
    ordersSum?: number
    buyoutCount?: number
    buyoutSum?: number
    buyoutPercent?: number
    lostOrdersCount?: number
    lostOrdersSum?: number
    lostBuyoutsCount?: number
    lostBuyoutsSum?: number
    turnoverDays?: number | null
    saleRateDays?: number | null
    currentPriceMin?: number | null
    currentPriceMax?: number | null
    openCount?: number
    cartCount?: number
    orderCount?: number
    orderSum?: number
    funnelBuyoutCount?: number
    funnelBuyoutSum?: number
    cancelCount?: number
    cancelSum?: number
    addToCartPercent?: number
    cartToOrderPercent?: number
    funnelBuyoutPercent?: number
    orderCountDynamic?: number
    orderSumDynamic?: number
    openCountDynamic?: number
    cartCountDynamic?: number
    selectedMetrics?: NullableJsonNullValueInput | InputJsonValue
    pastMetrics?: NullableJsonNullValueInput | InputJsonValue
    comparisonMetrics?: NullableJsonNullValueInput | InputJsonValue
    stockMetrics?: NullableJsonNullValueInput | InputJsonValue
    syncedAt: Date | string
  }

  export type AnalyticsProductUpdateManyMutationInput = {
    clientId?: StringFieldUpdateOperationsInput | string
    nmId?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    vendorCode?: NullableStringFieldUpdateOperationsInput | string | null
    brandName?: NullableStringFieldUpdateOperationsInput | string | null
    subjectName?: NullableStringFieldUpdateOperationsInput | string | null
    photoUrl?: NullableStringFieldUpdateOperationsInput | string | null
    availability?: NullableStringFieldUpdateOperationsInput | string | null
    stockCount?: FloatFieldUpdateOperationsInput | number
    stockSum?: FloatFieldUpdateOperationsInput | number
    avgOrders?: FloatFieldUpdateOperationsInput | number
    ordersCount?: FloatFieldUpdateOperationsInput | number
    ordersSum?: FloatFieldUpdateOperationsInput | number
    buyoutCount?: FloatFieldUpdateOperationsInput | number
    buyoutSum?: FloatFieldUpdateOperationsInput | number
    buyoutPercent?: FloatFieldUpdateOperationsInput | number
    lostOrdersCount?: FloatFieldUpdateOperationsInput | number
    lostOrdersSum?: FloatFieldUpdateOperationsInput | number
    lostBuyoutsCount?: FloatFieldUpdateOperationsInput | number
    lostBuyoutsSum?: FloatFieldUpdateOperationsInput | number
    turnoverDays?: NullableFloatFieldUpdateOperationsInput | number | null
    saleRateDays?: NullableFloatFieldUpdateOperationsInput | number | null
    currentPriceMin?: NullableFloatFieldUpdateOperationsInput | number | null
    currentPriceMax?: NullableFloatFieldUpdateOperationsInput | number | null
    openCount?: FloatFieldUpdateOperationsInput | number
    cartCount?: FloatFieldUpdateOperationsInput | number
    orderCount?: FloatFieldUpdateOperationsInput | number
    orderSum?: FloatFieldUpdateOperationsInput | number
    funnelBuyoutCount?: FloatFieldUpdateOperationsInput | number
    funnelBuyoutSum?: FloatFieldUpdateOperationsInput | number
    cancelCount?: FloatFieldUpdateOperationsInput | number
    cancelSum?: FloatFieldUpdateOperationsInput | number
    addToCartPercent?: FloatFieldUpdateOperationsInput | number
    cartToOrderPercent?: FloatFieldUpdateOperationsInput | number
    funnelBuyoutPercent?: FloatFieldUpdateOperationsInput | number
    orderCountDynamic?: FloatFieldUpdateOperationsInput | number
    orderSumDynamic?: FloatFieldUpdateOperationsInput | number
    openCountDynamic?: FloatFieldUpdateOperationsInput | number
    cartCountDynamic?: FloatFieldUpdateOperationsInput | number
    selectedMetrics?: NullableJsonNullValueInput | InputJsonValue
    pastMetrics?: NullableJsonNullValueInput | InputJsonValue
    comparisonMetrics?: NullableJsonNullValueInput | InputJsonValue
    stockMetrics?: NullableJsonNullValueInput | InputJsonValue
    syncedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type AnalyticsProductUncheckedUpdateManyInput = {
    clientId?: StringFieldUpdateOperationsInput | string
    nmId?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    vendorCode?: NullableStringFieldUpdateOperationsInput | string | null
    brandName?: NullableStringFieldUpdateOperationsInput | string | null
    subjectName?: NullableStringFieldUpdateOperationsInput | string | null
    photoUrl?: NullableStringFieldUpdateOperationsInput | string | null
    availability?: NullableStringFieldUpdateOperationsInput | string | null
    stockCount?: FloatFieldUpdateOperationsInput | number
    stockSum?: FloatFieldUpdateOperationsInput | number
    avgOrders?: FloatFieldUpdateOperationsInput | number
    ordersCount?: FloatFieldUpdateOperationsInput | number
    ordersSum?: FloatFieldUpdateOperationsInput | number
    buyoutCount?: FloatFieldUpdateOperationsInput | number
    buyoutSum?: FloatFieldUpdateOperationsInput | number
    buyoutPercent?: FloatFieldUpdateOperationsInput | number
    lostOrdersCount?: FloatFieldUpdateOperationsInput | number
    lostOrdersSum?: FloatFieldUpdateOperationsInput | number
    lostBuyoutsCount?: FloatFieldUpdateOperationsInput | number
    lostBuyoutsSum?: FloatFieldUpdateOperationsInput | number
    turnoverDays?: NullableFloatFieldUpdateOperationsInput | number | null
    saleRateDays?: NullableFloatFieldUpdateOperationsInput | number | null
    currentPriceMin?: NullableFloatFieldUpdateOperationsInput | number | null
    currentPriceMax?: NullableFloatFieldUpdateOperationsInput | number | null
    openCount?: FloatFieldUpdateOperationsInput | number
    cartCount?: FloatFieldUpdateOperationsInput | number
    orderCount?: FloatFieldUpdateOperationsInput | number
    orderSum?: FloatFieldUpdateOperationsInput | number
    funnelBuyoutCount?: FloatFieldUpdateOperationsInput | number
    funnelBuyoutSum?: FloatFieldUpdateOperationsInput | number
    cancelCount?: FloatFieldUpdateOperationsInput | number
    cancelSum?: FloatFieldUpdateOperationsInput | number
    addToCartPercent?: FloatFieldUpdateOperationsInput | number
    cartToOrderPercent?: FloatFieldUpdateOperationsInput | number
    funnelBuyoutPercent?: FloatFieldUpdateOperationsInput | number
    orderCountDynamic?: FloatFieldUpdateOperationsInput | number
    orderSumDynamic?: FloatFieldUpdateOperationsInput | number
    openCountDynamic?: FloatFieldUpdateOperationsInput | number
    cartCountDynamic?: FloatFieldUpdateOperationsInput | number
    selectedMetrics?: NullableJsonNullValueInput | InputJsonValue
    pastMetrics?: NullableJsonNullValueInput | InputJsonValue
    comparisonMetrics?: NullableJsonNullValueInput | InputJsonValue
    stockMetrics?: NullableJsonNullValueInput | InputJsonValue
    syncedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type AnalyticsRegionCreateInput = {
    clientId: string
    regionKey: string
    regionName: string
    officeId?: string | null
    officeName?: string | null
    stockCount?: number
    stockSum?: number
    toClientCount?: number
    fromClientCount?: number
    saleRateDays?: number | null
    metrics?: NullableJsonNullValueInput | InputJsonValue
    syncedAt: Date | string
  }

  export type AnalyticsRegionUncheckedCreateInput = {
    clientId: string
    regionKey: string
    regionName: string
    officeId?: string | null
    officeName?: string | null
    stockCount?: number
    stockSum?: number
    toClientCount?: number
    fromClientCount?: number
    saleRateDays?: number | null
    metrics?: NullableJsonNullValueInput | InputJsonValue
    syncedAt: Date | string
  }

  export type AnalyticsRegionUpdateInput = {
    clientId?: StringFieldUpdateOperationsInput | string
    regionKey?: StringFieldUpdateOperationsInput | string
    regionName?: StringFieldUpdateOperationsInput | string
    officeId?: NullableStringFieldUpdateOperationsInput | string | null
    officeName?: NullableStringFieldUpdateOperationsInput | string | null
    stockCount?: FloatFieldUpdateOperationsInput | number
    stockSum?: FloatFieldUpdateOperationsInput | number
    toClientCount?: FloatFieldUpdateOperationsInput | number
    fromClientCount?: FloatFieldUpdateOperationsInput | number
    saleRateDays?: NullableFloatFieldUpdateOperationsInput | number | null
    metrics?: NullableJsonNullValueInput | InputJsonValue
    syncedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type AnalyticsRegionUncheckedUpdateInput = {
    clientId?: StringFieldUpdateOperationsInput | string
    regionKey?: StringFieldUpdateOperationsInput | string
    regionName?: StringFieldUpdateOperationsInput | string
    officeId?: NullableStringFieldUpdateOperationsInput | string | null
    officeName?: NullableStringFieldUpdateOperationsInput | string | null
    stockCount?: FloatFieldUpdateOperationsInput | number
    stockSum?: FloatFieldUpdateOperationsInput | number
    toClientCount?: FloatFieldUpdateOperationsInput | number
    fromClientCount?: FloatFieldUpdateOperationsInput | number
    saleRateDays?: NullableFloatFieldUpdateOperationsInput | number | null
    metrics?: NullableJsonNullValueInput | InputJsonValue
    syncedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type AnalyticsRegionCreateManyInput = {
    clientId: string
    regionKey: string
    regionName: string
    officeId?: string | null
    officeName?: string | null
    stockCount?: number
    stockSum?: number
    toClientCount?: number
    fromClientCount?: number
    saleRateDays?: number | null
    metrics?: NullableJsonNullValueInput | InputJsonValue
    syncedAt: Date | string
  }

  export type AnalyticsRegionUpdateManyMutationInput = {
    clientId?: StringFieldUpdateOperationsInput | string
    regionKey?: StringFieldUpdateOperationsInput | string
    regionName?: StringFieldUpdateOperationsInput | string
    officeId?: NullableStringFieldUpdateOperationsInput | string | null
    officeName?: NullableStringFieldUpdateOperationsInput | string | null
    stockCount?: FloatFieldUpdateOperationsInput | number
    stockSum?: FloatFieldUpdateOperationsInput | number
    toClientCount?: FloatFieldUpdateOperationsInput | number
    fromClientCount?: FloatFieldUpdateOperationsInput | number
    saleRateDays?: NullableFloatFieldUpdateOperationsInput | number | null
    metrics?: NullableJsonNullValueInput | InputJsonValue
    syncedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type AnalyticsRegionUncheckedUpdateManyInput = {
    clientId?: StringFieldUpdateOperationsInput | string
    regionKey?: StringFieldUpdateOperationsInput | string
    regionName?: StringFieldUpdateOperationsInput | string
    officeId?: NullableStringFieldUpdateOperationsInput | string | null
    officeName?: NullableStringFieldUpdateOperationsInput | string | null
    stockCount?: FloatFieldUpdateOperationsInput | number
    stockSum?: FloatFieldUpdateOperationsInput | number
    toClientCount?: FloatFieldUpdateOperationsInput | number
    fromClientCount?: FloatFieldUpdateOperationsInput | number
    saleRateDays?: NullableFloatFieldUpdateOperationsInput | number | null
    metrics?: NullableJsonNullValueInput | InputJsonValue
    syncedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type AnalyticsDailySummaryCreateInput = {
    clientId: string
    snapshotDate: Date | string
    periodDays: number
    productCount: number
    stockCount: number
    stockSum: number
    ordersCount: number
    ordersSum: number
    buyoutCount: number
    buyoutSum: number
    lostOrdersSum: number
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type AnalyticsDailySummaryUncheckedCreateInput = {
    clientId: string
    snapshotDate: Date | string
    periodDays: number
    productCount: number
    stockCount: number
    stockSum: number
    ordersCount: number
    ordersSum: number
    buyoutCount: number
    buyoutSum: number
    lostOrdersSum: number
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type AnalyticsDailySummaryUpdateInput = {
    clientId?: StringFieldUpdateOperationsInput | string
    snapshotDate?: DateTimeFieldUpdateOperationsInput | Date | string
    periodDays?: IntFieldUpdateOperationsInput | number
    productCount?: IntFieldUpdateOperationsInput | number
    stockCount?: FloatFieldUpdateOperationsInput | number
    stockSum?: FloatFieldUpdateOperationsInput | number
    ordersCount?: FloatFieldUpdateOperationsInput | number
    ordersSum?: FloatFieldUpdateOperationsInput | number
    buyoutCount?: FloatFieldUpdateOperationsInput | number
    buyoutSum?: FloatFieldUpdateOperationsInput | number
    lostOrdersSum?: FloatFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type AnalyticsDailySummaryUncheckedUpdateInput = {
    clientId?: StringFieldUpdateOperationsInput | string
    snapshotDate?: DateTimeFieldUpdateOperationsInput | Date | string
    periodDays?: IntFieldUpdateOperationsInput | number
    productCount?: IntFieldUpdateOperationsInput | number
    stockCount?: FloatFieldUpdateOperationsInput | number
    stockSum?: FloatFieldUpdateOperationsInput | number
    ordersCount?: FloatFieldUpdateOperationsInput | number
    ordersSum?: FloatFieldUpdateOperationsInput | number
    buyoutCount?: FloatFieldUpdateOperationsInput | number
    buyoutSum?: FloatFieldUpdateOperationsInput | number
    lostOrdersSum?: FloatFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type AnalyticsDailySummaryCreateManyInput = {
    clientId: string
    snapshotDate: Date | string
    periodDays: number
    productCount: number
    stockCount: number
    stockSum: number
    ordersCount: number
    ordersSum: number
    buyoutCount: number
    buyoutSum: number
    lostOrdersSum: number
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type AnalyticsDailySummaryUpdateManyMutationInput = {
    clientId?: StringFieldUpdateOperationsInput | string
    snapshotDate?: DateTimeFieldUpdateOperationsInput | Date | string
    periodDays?: IntFieldUpdateOperationsInput | number
    productCount?: IntFieldUpdateOperationsInput | number
    stockCount?: FloatFieldUpdateOperationsInput | number
    stockSum?: FloatFieldUpdateOperationsInput | number
    ordersCount?: FloatFieldUpdateOperationsInput | number
    ordersSum?: FloatFieldUpdateOperationsInput | number
    buyoutCount?: FloatFieldUpdateOperationsInput | number
    buyoutSum?: FloatFieldUpdateOperationsInput | number
    lostOrdersSum?: FloatFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type AnalyticsDailySummaryUncheckedUpdateManyInput = {
    clientId?: StringFieldUpdateOperationsInput | string
    snapshotDate?: DateTimeFieldUpdateOperationsInput | Date | string
    periodDays?: IntFieldUpdateOperationsInput | number
    productCount?: IntFieldUpdateOperationsInput | number
    stockCount?: FloatFieldUpdateOperationsInput | number
    stockSum?: FloatFieldUpdateOperationsInput | number
    ordersCount?: FloatFieldUpdateOperationsInput | number
    ordersSum?: FloatFieldUpdateOperationsInput | number
    buyoutCount?: FloatFieldUpdateOperationsInput | number
    buyoutSum?: FloatFieldUpdateOperationsInput | number
    lostOrdersSum?: FloatFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type StringFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedStringFilter<$PrismaModel> | string
  }

  export type StringNullableFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedStringNullableFilter<$PrismaModel> | string | null
  }

  export type BoolFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel>
    not?: NestedBoolFilter<$PrismaModel> | boolean
  }

  export type DateTimeNullableFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableFilter<$PrismaModel> | Date | string | null
  }

  export type DateTimeFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeFilter<$PrismaModel> | Date | string
  }

  export type SortOrderInput = {
    sort: SortOrder
    nulls?: NullsOrder
  }

  export type AnalyticsConnectionCountOrderByAggregateInput = {
    clientId?: SortOrder
    marketplace?: SortOrder
    accountName?: SortOrder
    sellerSid?: SortOrder
    apiKeyEncrypted?: SortOrder
    isActive?: SortOrder
    lastVerifiedAt?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type AnalyticsConnectionMaxOrderByAggregateInput = {
    clientId?: SortOrder
    marketplace?: SortOrder
    accountName?: SortOrder
    sellerSid?: SortOrder
    apiKeyEncrypted?: SortOrder
    isActive?: SortOrder
    lastVerifiedAt?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type AnalyticsConnectionMinOrderByAggregateInput = {
    clientId?: SortOrder
    marketplace?: SortOrder
    accountName?: SortOrder
    sellerSid?: SortOrder
    apiKeyEncrypted?: SortOrder
    isActive?: SortOrder
    lastVerifiedAt?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type StringWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedStringWithAggregatesFilter<$PrismaModel> | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedStringFilter<$PrismaModel>
    _max?: NestedStringFilter<$PrismaModel>
  }

  export type StringNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedStringNullableWithAggregatesFilter<$PrismaModel> | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedStringNullableFilter<$PrismaModel>
    _max?: NestedStringNullableFilter<$PrismaModel>
  }

  export type BoolWithAggregatesFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel>
    not?: NestedBoolWithAggregatesFilter<$PrismaModel> | boolean
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedBoolFilter<$PrismaModel>
    _max?: NestedBoolFilter<$PrismaModel>
  }

  export type DateTimeNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableWithAggregatesFilter<$PrismaModel> | Date | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedDateTimeNullableFilter<$PrismaModel>
    _max?: NestedDateTimeNullableFilter<$PrismaModel>
  }

  export type DateTimeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeWithAggregatesFilter<$PrismaModel> | Date | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedDateTimeFilter<$PrismaModel>
    _max?: NestedDateTimeFilter<$PrismaModel>
  }

  export type IntFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[] | ListIntFieldRefInput<$PrismaModel>
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel>
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntFilter<$PrismaModel> | number
  }
  export type JsonNullableFilter<$PrismaModel = never> =
    | PatchUndefined<
        Either<Required<JsonNullableFilterBase<$PrismaModel>>, Exclude<keyof Required<JsonNullableFilterBase<$PrismaModel>>, 'path'>>,
        Required<JsonNullableFilterBase<$PrismaModel>>
      >
    | OptionalFlat<Omit<Required<JsonNullableFilterBase<$PrismaModel>>, 'path'>>

  export type JsonNullableFilterBase<$PrismaModel = never> = {
    equals?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
    path?: string[]
    mode?: QueryMode | EnumQueryModeFieldRefInput<$PrismaModel>
    string_contains?: string | StringFieldRefInput<$PrismaModel>
    string_starts_with?: string | StringFieldRefInput<$PrismaModel>
    string_ends_with?: string | StringFieldRefInput<$PrismaModel>
    array_starts_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_ends_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_contains?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    lt?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    lte?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    gt?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    gte?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    not?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
  }

  export type AnalyticsSyncStateCountOrderByAggregateInput = {
    clientId?: SortOrder
    marketplace?: SortOrder
    status?: SortOrder
    periodDays?: SortOrder
    currency?: SortOrder
    productCount?: SortOrder
    lastStartedAt?: SortOrder
    lastSyncedAt?: SortOrder
    lastError?: SortOrder
    sourceStatus?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type AnalyticsSyncStateAvgOrderByAggregateInput = {
    periodDays?: SortOrder
    productCount?: SortOrder
  }

  export type AnalyticsSyncStateMaxOrderByAggregateInput = {
    clientId?: SortOrder
    marketplace?: SortOrder
    status?: SortOrder
    periodDays?: SortOrder
    currency?: SortOrder
    productCount?: SortOrder
    lastStartedAt?: SortOrder
    lastSyncedAt?: SortOrder
    lastError?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type AnalyticsSyncStateMinOrderByAggregateInput = {
    clientId?: SortOrder
    marketplace?: SortOrder
    status?: SortOrder
    periodDays?: SortOrder
    currency?: SortOrder
    productCount?: SortOrder
    lastStartedAt?: SortOrder
    lastSyncedAt?: SortOrder
    lastError?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type AnalyticsSyncStateSumOrderByAggregateInput = {
    periodDays?: SortOrder
    productCount?: SortOrder
  }

  export type IntWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[] | ListIntFieldRefInput<$PrismaModel>
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel>
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntWithAggregatesFilter<$PrismaModel> | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedIntFilter<$PrismaModel>
    _min?: NestedIntFilter<$PrismaModel>
    _max?: NestedIntFilter<$PrismaModel>
  }
  export type JsonNullableWithAggregatesFilter<$PrismaModel = never> =
    | PatchUndefined<
        Either<Required<JsonNullableWithAggregatesFilterBase<$PrismaModel>>, Exclude<keyof Required<JsonNullableWithAggregatesFilterBase<$PrismaModel>>, 'path'>>,
        Required<JsonNullableWithAggregatesFilterBase<$PrismaModel>>
      >
    | OptionalFlat<Omit<Required<JsonNullableWithAggregatesFilterBase<$PrismaModel>>, 'path'>>

  export type JsonNullableWithAggregatesFilterBase<$PrismaModel = never> = {
    equals?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
    path?: string[]
    mode?: QueryMode | EnumQueryModeFieldRefInput<$PrismaModel>
    string_contains?: string | StringFieldRefInput<$PrismaModel>
    string_starts_with?: string | StringFieldRefInput<$PrismaModel>
    string_ends_with?: string | StringFieldRefInput<$PrismaModel>
    array_starts_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_ends_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_contains?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    lt?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    lte?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    gt?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    gte?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    not?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedJsonNullableFilter<$PrismaModel>
    _max?: NestedJsonNullableFilter<$PrismaModel>
  }

  export type FloatFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel>
    in?: number[] | ListFloatFieldRefInput<$PrismaModel>
    notIn?: number[] | ListFloatFieldRefInput<$PrismaModel>
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatFilter<$PrismaModel> | number
  }

  export type FloatNullableFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel> | null
    in?: number[] | ListFloatFieldRefInput<$PrismaModel> | null
    notIn?: number[] | ListFloatFieldRefInput<$PrismaModel> | null
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatNullableFilter<$PrismaModel> | number | null
  }

  export type AnalyticsProductClientIdNmIdCompoundUniqueInput = {
    clientId: string
    nmId: string
  }

  export type AnalyticsProductCountOrderByAggregateInput = {
    clientId?: SortOrder
    nmId?: SortOrder
    name?: SortOrder
    vendorCode?: SortOrder
    brandName?: SortOrder
    subjectName?: SortOrder
    photoUrl?: SortOrder
    availability?: SortOrder
    stockCount?: SortOrder
    stockSum?: SortOrder
    avgOrders?: SortOrder
    ordersCount?: SortOrder
    ordersSum?: SortOrder
    buyoutCount?: SortOrder
    buyoutSum?: SortOrder
    buyoutPercent?: SortOrder
    lostOrdersCount?: SortOrder
    lostOrdersSum?: SortOrder
    lostBuyoutsCount?: SortOrder
    lostBuyoutsSum?: SortOrder
    turnoverDays?: SortOrder
    saleRateDays?: SortOrder
    currentPriceMin?: SortOrder
    currentPriceMax?: SortOrder
    openCount?: SortOrder
    cartCount?: SortOrder
    orderCount?: SortOrder
    orderSum?: SortOrder
    funnelBuyoutCount?: SortOrder
    funnelBuyoutSum?: SortOrder
    cancelCount?: SortOrder
    cancelSum?: SortOrder
    addToCartPercent?: SortOrder
    cartToOrderPercent?: SortOrder
    funnelBuyoutPercent?: SortOrder
    orderCountDynamic?: SortOrder
    orderSumDynamic?: SortOrder
    openCountDynamic?: SortOrder
    cartCountDynamic?: SortOrder
    selectedMetrics?: SortOrder
    pastMetrics?: SortOrder
    comparisonMetrics?: SortOrder
    stockMetrics?: SortOrder
    syncedAt?: SortOrder
  }

  export type AnalyticsProductAvgOrderByAggregateInput = {
    stockCount?: SortOrder
    stockSum?: SortOrder
    avgOrders?: SortOrder
    ordersCount?: SortOrder
    ordersSum?: SortOrder
    buyoutCount?: SortOrder
    buyoutSum?: SortOrder
    buyoutPercent?: SortOrder
    lostOrdersCount?: SortOrder
    lostOrdersSum?: SortOrder
    lostBuyoutsCount?: SortOrder
    lostBuyoutsSum?: SortOrder
    turnoverDays?: SortOrder
    saleRateDays?: SortOrder
    currentPriceMin?: SortOrder
    currentPriceMax?: SortOrder
    openCount?: SortOrder
    cartCount?: SortOrder
    orderCount?: SortOrder
    orderSum?: SortOrder
    funnelBuyoutCount?: SortOrder
    funnelBuyoutSum?: SortOrder
    cancelCount?: SortOrder
    cancelSum?: SortOrder
    addToCartPercent?: SortOrder
    cartToOrderPercent?: SortOrder
    funnelBuyoutPercent?: SortOrder
    orderCountDynamic?: SortOrder
    orderSumDynamic?: SortOrder
    openCountDynamic?: SortOrder
    cartCountDynamic?: SortOrder
  }

  export type AnalyticsProductMaxOrderByAggregateInput = {
    clientId?: SortOrder
    nmId?: SortOrder
    name?: SortOrder
    vendorCode?: SortOrder
    brandName?: SortOrder
    subjectName?: SortOrder
    photoUrl?: SortOrder
    availability?: SortOrder
    stockCount?: SortOrder
    stockSum?: SortOrder
    avgOrders?: SortOrder
    ordersCount?: SortOrder
    ordersSum?: SortOrder
    buyoutCount?: SortOrder
    buyoutSum?: SortOrder
    buyoutPercent?: SortOrder
    lostOrdersCount?: SortOrder
    lostOrdersSum?: SortOrder
    lostBuyoutsCount?: SortOrder
    lostBuyoutsSum?: SortOrder
    turnoverDays?: SortOrder
    saleRateDays?: SortOrder
    currentPriceMin?: SortOrder
    currentPriceMax?: SortOrder
    openCount?: SortOrder
    cartCount?: SortOrder
    orderCount?: SortOrder
    orderSum?: SortOrder
    funnelBuyoutCount?: SortOrder
    funnelBuyoutSum?: SortOrder
    cancelCount?: SortOrder
    cancelSum?: SortOrder
    addToCartPercent?: SortOrder
    cartToOrderPercent?: SortOrder
    funnelBuyoutPercent?: SortOrder
    orderCountDynamic?: SortOrder
    orderSumDynamic?: SortOrder
    openCountDynamic?: SortOrder
    cartCountDynamic?: SortOrder
    syncedAt?: SortOrder
  }

  export type AnalyticsProductMinOrderByAggregateInput = {
    clientId?: SortOrder
    nmId?: SortOrder
    name?: SortOrder
    vendorCode?: SortOrder
    brandName?: SortOrder
    subjectName?: SortOrder
    photoUrl?: SortOrder
    availability?: SortOrder
    stockCount?: SortOrder
    stockSum?: SortOrder
    avgOrders?: SortOrder
    ordersCount?: SortOrder
    ordersSum?: SortOrder
    buyoutCount?: SortOrder
    buyoutSum?: SortOrder
    buyoutPercent?: SortOrder
    lostOrdersCount?: SortOrder
    lostOrdersSum?: SortOrder
    lostBuyoutsCount?: SortOrder
    lostBuyoutsSum?: SortOrder
    turnoverDays?: SortOrder
    saleRateDays?: SortOrder
    currentPriceMin?: SortOrder
    currentPriceMax?: SortOrder
    openCount?: SortOrder
    cartCount?: SortOrder
    orderCount?: SortOrder
    orderSum?: SortOrder
    funnelBuyoutCount?: SortOrder
    funnelBuyoutSum?: SortOrder
    cancelCount?: SortOrder
    cancelSum?: SortOrder
    addToCartPercent?: SortOrder
    cartToOrderPercent?: SortOrder
    funnelBuyoutPercent?: SortOrder
    orderCountDynamic?: SortOrder
    orderSumDynamic?: SortOrder
    openCountDynamic?: SortOrder
    cartCountDynamic?: SortOrder
    syncedAt?: SortOrder
  }

  export type AnalyticsProductSumOrderByAggregateInput = {
    stockCount?: SortOrder
    stockSum?: SortOrder
    avgOrders?: SortOrder
    ordersCount?: SortOrder
    ordersSum?: SortOrder
    buyoutCount?: SortOrder
    buyoutSum?: SortOrder
    buyoutPercent?: SortOrder
    lostOrdersCount?: SortOrder
    lostOrdersSum?: SortOrder
    lostBuyoutsCount?: SortOrder
    lostBuyoutsSum?: SortOrder
    turnoverDays?: SortOrder
    saleRateDays?: SortOrder
    currentPriceMin?: SortOrder
    currentPriceMax?: SortOrder
    openCount?: SortOrder
    cartCount?: SortOrder
    orderCount?: SortOrder
    orderSum?: SortOrder
    funnelBuyoutCount?: SortOrder
    funnelBuyoutSum?: SortOrder
    cancelCount?: SortOrder
    cancelSum?: SortOrder
    addToCartPercent?: SortOrder
    cartToOrderPercent?: SortOrder
    funnelBuyoutPercent?: SortOrder
    orderCountDynamic?: SortOrder
    orderSumDynamic?: SortOrder
    openCountDynamic?: SortOrder
    cartCountDynamic?: SortOrder
  }

  export type FloatWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel>
    in?: number[] | ListFloatFieldRefInput<$PrismaModel>
    notIn?: number[] | ListFloatFieldRefInput<$PrismaModel>
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatWithAggregatesFilter<$PrismaModel> | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedFloatFilter<$PrismaModel>
    _min?: NestedFloatFilter<$PrismaModel>
    _max?: NestedFloatFilter<$PrismaModel>
  }

  export type FloatNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel> | null
    in?: number[] | ListFloatFieldRefInput<$PrismaModel> | null
    notIn?: number[] | ListFloatFieldRefInput<$PrismaModel> | null
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatNullableWithAggregatesFilter<$PrismaModel> | number | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _avg?: NestedFloatNullableFilter<$PrismaModel>
    _sum?: NestedFloatNullableFilter<$PrismaModel>
    _min?: NestedFloatNullableFilter<$PrismaModel>
    _max?: NestedFloatNullableFilter<$PrismaModel>
  }

  export type AnalyticsRegionClientIdRegionKeyCompoundUniqueInput = {
    clientId: string
    regionKey: string
  }

  export type AnalyticsRegionCountOrderByAggregateInput = {
    clientId?: SortOrder
    regionKey?: SortOrder
    regionName?: SortOrder
    officeId?: SortOrder
    officeName?: SortOrder
    stockCount?: SortOrder
    stockSum?: SortOrder
    toClientCount?: SortOrder
    fromClientCount?: SortOrder
    saleRateDays?: SortOrder
    metrics?: SortOrder
    syncedAt?: SortOrder
  }

  export type AnalyticsRegionAvgOrderByAggregateInput = {
    stockCount?: SortOrder
    stockSum?: SortOrder
    toClientCount?: SortOrder
    fromClientCount?: SortOrder
    saleRateDays?: SortOrder
  }

  export type AnalyticsRegionMaxOrderByAggregateInput = {
    clientId?: SortOrder
    regionKey?: SortOrder
    regionName?: SortOrder
    officeId?: SortOrder
    officeName?: SortOrder
    stockCount?: SortOrder
    stockSum?: SortOrder
    toClientCount?: SortOrder
    fromClientCount?: SortOrder
    saleRateDays?: SortOrder
    syncedAt?: SortOrder
  }

  export type AnalyticsRegionMinOrderByAggregateInput = {
    clientId?: SortOrder
    regionKey?: SortOrder
    regionName?: SortOrder
    officeId?: SortOrder
    officeName?: SortOrder
    stockCount?: SortOrder
    stockSum?: SortOrder
    toClientCount?: SortOrder
    fromClientCount?: SortOrder
    saleRateDays?: SortOrder
    syncedAt?: SortOrder
  }

  export type AnalyticsRegionSumOrderByAggregateInput = {
    stockCount?: SortOrder
    stockSum?: SortOrder
    toClientCount?: SortOrder
    fromClientCount?: SortOrder
    saleRateDays?: SortOrder
  }

  export type AnalyticsDailySummaryClientIdSnapshotDateCompoundUniqueInput = {
    clientId: string
    snapshotDate: Date | string
  }

  export type AnalyticsDailySummaryCountOrderByAggregateInput = {
    clientId?: SortOrder
    snapshotDate?: SortOrder
    periodDays?: SortOrder
    productCount?: SortOrder
    stockCount?: SortOrder
    stockSum?: SortOrder
    ordersCount?: SortOrder
    ordersSum?: SortOrder
    buyoutCount?: SortOrder
    buyoutSum?: SortOrder
    lostOrdersSum?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type AnalyticsDailySummaryAvgOrderByAggregateInput = {
    periodDays?: SortOrder
    productCount?: SortOrder
    stockCount?: SortOrder
    stockSum?: SortOrder
    ordersCount?: SortOrder
    ordersSum?: SortOrder
    buyoutCount?: SortOrder
    buyoutSum?: SortOrder
    lostOrdersSum?: SortOrder
  }

  export type AnalyticsDailySummaryMaxOrderByAggregateInput = {
    clientId?: SortOrder
    snapshotDate?: SortOrder
    periodDays?: SortOrder
    productCount?: SortOrder
    stockCount?: SortOrder
    stockSum?: SortOrder
    ordersCount?: SortOrder
    ordersSum?: SortOrder
    buyoutCount?: SortOrder
    buyoutSum?: SortOrder
    lostOrdersSum?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type AnalyticsDailySummaryMinOrderByAggregateInput = {
    clientId?: SortOrder
    snapshotDate?: SortOrder
    periodDays?: SortOrder
    productCount?: SortOrder
    stockCount?: SortOrder
    stockSum?: SortOrder
    ordersCount?: SortOrder
    ordersSum?: SortOrder
    buyoutCount?: SortOrder
    buyoutSum?: SortOrder
    lostOrdersSum?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type AnalyticsDailySummarySumOrderByAggregateInput = {
    periodDays?: SortOrder
    productCount?: SortOrder
    stockCount?: SortOrder
    stockSum?: SortOrder
    ordersCount?: SortOrder
    ordersSum?: SortOrder
    buyoutCount?: SortOrder
    buyoutSum?: SortOrder
    lostOrdersSum?: SortOrder
  }

  export type StringFieldUpdateOperationsInput = {
    set?: string
  }

  export type NullableStringFieldUpdateOperationsInput = {
    set?: string | null
  }

  export type BoolFieldUpdateOperationsInput = {
    set?: boolean
  }

  export type NullableDateTimeFieldUpdateOperationsInput = {
    set?: Date | string | null
  }

  export type DateTimeFieldUpdateOperationsInput = {
    set?: Date | string
  }

  export type IntFieldUpdateOperationsInput = {
    set?: number
    increment?: number
    decrement?: number
    multiply?: number
    divide?: number
  }

  export type FloatFieldUpdateOperationsInput = {
    set?: number
    increment?: number
    decrement?: number
    multiply?: number
    divide?: number
  }

  export type NullableFloatFieldUpdateOperationsInput = {
    set?: number | null
    increment?: number
    decrement?: number
    multiply?: number
    divide?: number
  }

  export type NestedStringFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringFilter<$PrismaModel> | string
  }

  export type NestedStringNullableFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringNullableFilter<$PrismaModel> | string | null
  }

  export type NestedBoolFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel>
    not?: NestedBoolFilter<$PrismaModel> | boolean
  }

  export type NestedDateTimeNullableFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableFilter<$PrismaModel> | Date | string | null
  }

  export type NestedDateTimeFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeFilter<$PrismaModel> | Date | string
  }

  export type NestedStringWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringWithAggregatesFilter<$PrismaModel> | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedStringFilter<$PrismaModel>
    _max?: NestedStringFilter<$PrismaModel>
  }

  export type NestedIntFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[] | ListIntFieldRefInput<$PrismaModel>
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel>
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntFilter<$PrismaModel> | number
  }

  export type NestedStringNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringNullableWithAggregatesFilter<$PrismaModel> | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedStringNullableFilter<$PrismaModel>
    _max?: NestedStringNullableFilter<$PrismaModel>
  }

  export type NestedIntNullableFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableFilter<$PrismaModel> | number | null
  }

  export type NestedBoolWithAggregatesFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel>
    not?: NestedBoolWithAggregatesFilter<$PrismaModel> | boolean
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedBoolFilter<$PrismaModel>
    _max?: NestedBoolFilter<$PrismaModel>
  }

  export type NestedDateTimeNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableWithAggregatesFilter<$PrismaModel> | Date | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedDateTimeNullableFilter<$PrismaModel>
    _max?: NestedDateTimeNullableFilter<$PrismaModel>
  }

  export type NestedDateTimeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeWithAggregatesFilter<$PrismaModel> | Date | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedDateTimeFilter<$PrismaModel>
    _max?: NestedDateTimeFilter<$PrismaModel>
  }

  export type NestedIntWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[] | ListIntFieldRefInput<$PrismaModel>
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel>
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntWithAggregatesFilter<$PrismaModel> | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedIntFilter<$PrismaModel>
    _min?: NestedIntFilter<$PrismaModel>
    _max?: NestedIntFilter<$PrismaModel>
  }

  export type NestedFloatFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel>
    in?: number[] | ListFloatFieldRefInput<$PrismaModel>
    notIn?: number[] | ListFloatFieldRefInput<$PrismaModel>
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatFilter<$PrismaModel> | number
  }
  export type NestedJsonNullableFilter<$PrismaModel = never> =
    | PatchUndefined<
        Either<Required<NestedJsonNullableFilterBase<$PrismaModel>>, Exclude<keyof Required<NestedJsonNullableFilterBase<$PrismaModel>>, 'path'>>,
        Required<NestedJsonNullableFilterBase<$PrismaModel>>
      >
    | OptionalFlat<Omit<Required<NestedJsonNullableFilterBase<$PrismaModel>>, 'path'>>

  export type NestedJsonNullableFilterBase<$PrismaModel = never> = {
    equals?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
    path?: string[]
    mode?: QueryMode | EnumQueryModeFieldRefInput<$PrismaModel>
    string_contains?: string | StringFieldRefInput<$PrismaModel>
    string_starts_with?: string | StringFieldRefInput<$PrismaModel>
    string_ends_with?: string | StringFieldRefInput<$PrismaModel>
    array_starts_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_ends_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_contains?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    lt?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    lte?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    gt?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    gte?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    not?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
  }

  export type NestedFloatNullableFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel> | null
    in?: number[] | ListFloatFieldRefInput<$PrismaModel> | null
    notIn?: number[] | ListFloatFieldRefInput<$PrismaModel> | null
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatNullableFilter<$PrismaModel> | number | null
  }

  export type NestedFloatWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel>
    in?: number[] | ListFloatFieldRefInput<$PrismaModel>
    notIn?: number[] | ListFloatFieldRefInput<$PrismaModel>
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatWithAggregatesFilter<$PrismaModel> | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedFloatFilter<$PrismaModel>
    _min?: NestedFloatFilter<$PrismaModel>
    _max?: NestedFloatFilter<$PrismaModel>
  }

  export type NestedFloatNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel> | null
    in?: number[] | ListFloatFieldRefInput<$PrismaModel> | null
    notIn?: number[] | ListFloatFieldRefInput<$PrismaModel> | null
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatNullableWithAggregatesFilter<$PrismaModel> | number | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _avg?: NestedFloatNullableFilter<$PrismaModel>
    _sum?: NestedFloatNullableFilter<$PrismaModel>
    _min?: NestedFloatNullableFilter<$PrismaModel>
    _max?: NestedFloatNullableFilter<$PrismaModel>
  }



  /**
   * Batch Payload for updateMany & deleteMany & createMany
   */

  export type BatchPayload = {
    count: number
  }

  /**
   * DMMF
   */
  export const dmmf: runtime.BaseDMMF
}