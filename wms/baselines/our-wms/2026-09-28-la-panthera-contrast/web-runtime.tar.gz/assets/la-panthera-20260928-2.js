import{j as n}from"./la-panthera-20260928-0.js";import{A as t}from"./la-panthera-20260928-3.js";function l({session:e}){return n.jsx(t,{enabledClientsOnly:!0,session:e,standalone:!0})}export{l as RelabelingPanel};


