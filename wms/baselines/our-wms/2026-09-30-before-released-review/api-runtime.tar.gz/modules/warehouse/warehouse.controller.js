"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.WarehouseController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const require_permissions_decorator_1 = require("../auth/decorators/require-permissions.decorator");
const create_warehouse_dto_1 = require("./dto/create-warehouse.dto");
const create_zone_dto_1 = require("./dto/create-zone.dto");
const upsert_box_dto_1 = require("./dto/upsert-box.dto");
const upsert_pallet_dto_1 = require("./dto/upsert-pallet.dto");
const warehouse_box_integrity_service_1 = require("./warehouse-box-integrity.service");
const warehouse_shipment_history_service_1 = require("./warehouse-shipment-history.service");
const warehouse_service_1 = require("./warehouse.service");
let WarehouseController = class WarehouseController {
    warehouse;
    boxIntegrity;
    shipmentHistory;
    constructor(warehouse, boxIntegrity, shipmentHistory) {
        this.warehouse = warehouse;
        this.boxIntegrity = boxIntegrity;
        this.shipmentHistory = shipmentHistory;
    }
    listWarehouses(user) {
        return this.warehouse.listWarehouses(user);
    }
    createWarehouse(dto, user) {
        return this.warehouse.createWarehouse(dto, user);
    }
    listZones(user, warehouseId) {
        return this.warehouse.listZones(user, warehouseId);
    }
    createZone(dto, user) {
        return this.warehouse.createZone(dto, user);
    }
    listBoxes(user, clientId, code, archive) {
        return this.warehouse.listBoxes({ clientId, code, archive: archive === 'true' }, user);
    }
    listBoxChecks(user, clientId) {
        return this.boxIntegrity.listChecks(user, clientId);
    }
    getBoxCheck(id, user) {
        return this.boxIntegrity.getCheck(id, user);
    }
    runBoxCheck(dto, user) {
        return this.boxIntegrity.runCheck(dto, user);
    }
    decideBoxCheckRow(id, dto, user) {
        return this.boxIntegrity.decideRow(id, dto, user);
    }
    shipmentHistoryList(user, clientId, periodFrom, periodTo, search) {
        return this.shipmentHistory.list({ clientId, periodFrom, periodTo, search }, user);
    }
    syncShipmentHistory(dto, user) {
        return this.shipmentHistory.sync(user, typeof dto.clientId === 'string' ? dto.clientId : undefined);
    }
    listOnlineReceipts(user, clientId) {
        return this.warehouse.listOnlineReceipts({ clientId }, user);
    }
    listReceiptBatches(user, clientId) {
        return this.warehouse.listReceiptBatches({ clientId }, user);
    }
    listGoodsArrivals(user, clientId, periodFrom, periodTo) {
        return this.warehouse.listGoodsArrivals({ clientId, periodFrom, periodTo }, user);
    }
    goodsArrivalSummary(user, clientId) {
        return this.warehouse.goodsArrivalSummary(clientId, user);
    }
    createGoodsArrival(dto, user) {
        return this.warehouse.createGoodsArrival(dto, user);
    }
    deleteGoodsArrival(id, user) {
        return this.warehouse.deleteGoodsArrival(id, user);
    }
    billGoodsArrivals(dto, user) {
        return this.warehouse.billGoodsArrivals(dto, user);
    }
    openOnlineReceiptBox(dto, user) {
        return this.warehouse.openOnlineReceiptBox(dto, user);
    }
    closeOnlineReceiptBox(dto, user) {
        return this.warehouse.closeOnlineReceiptBox(dto, user);
    }
    closeOpenOnlineReceiptBoxes(dto, user) {
        return this.warehouse.closeOpenOnlineReceiptBoxes(dto, user);
    }
    finishOnlineReceipt(dto, user) {
        return this.warehouse.finishOnlineReceipt(dto, user);
    }
    deleteOnlineReceiptBox(dto, user) {
        return this.warehouse.deleteOnlineReceiptBox(dto, user);
    }
    restoreOnlineReceiptBox(dto, user) {
        return this.warehouse.restoreOnlineReceiptBox(dto, user);
    }
    addOnlineReceiptItem(dto, user) {
        return this.warehouse.addOnlineReceiptItem(dto, user);
    }
    updateOnlineReceiptItem(id, dto, user) {
        return this.warehouse.updateOnlineReceiptItem(id, dto, user);
    }
    deleteOnlineReceiptItem(id, dto, user) {
        return this.warehouse.deleteOnlineReceiptItem(id, dto, user);
    }
    upsertBox(dto, user) {
        return this.warehouse.upsertBox(dto, user);
    }
    listPallets(user, clientId) {
        return this.warehouse.listPallets(clientId, user);
    }
    upsertPallet(dto, user) {
        return this.warehouse.upsertPallet(dto, user);
    }
};
exports.WarehouseController = WarehouseController;
__decorate([
    (0, common_1.Get)('warehouses'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], WarehouseController.prototype, "listWarehouses", null);
__decorate([
    (0, common_1.Post)('warehouses'),
    (0, require_permissions_decorator_1.RequirePermissions)('warehouse:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_warehouse_dto_1.CreateWarehouseDto, Object]),
    __metadata("design:returntype", void 0)
], WarehouseController.prototype, "createWarehouse", null);
__decorate([
    (0, common_1.Get)('zones'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)('warehouseId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", void 0)
], WarehouseController.prototype, "listZones", null);
__decorate([
    (0, common_1.Post)('zones'),
    (0, require_permissions_decorator_1.RequirePermissions)('warehouse:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_zone_dto_1.CreateZoneDto, Object]),
    __metadata("design:returntype", void 0)
], WarehouseController.prototype, "createZone", null);
__decorate([
    (0, common_1.Get)('boxes'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)('clientId')),
    __param(2, (0, common_1.Query)('code')),
    __param(3, (0, common_1.Query)('archive')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, String, String]),
    __metadata("design:returntype", void 0)
], WarehouseController.prototype, "listBoxes", null);
__decorate([
    (0, common_1.Get)('box-checks'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)('clientId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", void 0)
], WarehouseController.prototype, "listBoxChecks", null);
__decorate([
    (0, common_1.Get)('box-checks/:id'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], WarehouseController.prototype, "getBoxCheck", null);
__decorate([
    (0, common_1.Post)('box-checks'),
    (0, require_permissions_decorator_1.RequirePermissions)('warehouse:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], WarehouseController.prototype, "runBoxCheck", null);
__decorate([
    (0, common_1.Post)('box-check-rows/:id/decision'),
    (0, require_permissions_decorator_1.RequirePermissions)('warehouse:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", void 0)
], WarehouseController.prototype, "decideBoxCheckRow", null);
__decorate([
    (0, common_1.Get)('shipment-history'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)('clientId')),
    __param(2, (0, common_1.Query)('periodFrom')),
    __param(3, (0, common_1.Query)('periodTo')),
    __param(4, (0, common_1.Query)('search')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, String, String, String]),
    __metadata("design:returntype", void 0)
], WarehouseController.prototype, "shipmentHistoryList", null);
__decorate([
    (0, common_1.Post)('shipment-history/sync'),
    (0, require_permissions_decorator_1.RequirePermissions)('warehouse:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], WarehouseController.prototype, "syncShipmentHistory", null);
__decorate([
    (0, common_1.Get)('online-receipts'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)('clientId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", void 0)
], WarehouseController.prototype, "listOnlineReceipts", null);
__decorate([
    (0, common_1.Get)('receipt-batches'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)('clientId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", void 0)
], WarehouseController.prototype, "listReceiptBatches", null);
__decorate([
    (0, common_1.Get)('goods-arrivals'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)('clientId')),
    __param(2, (0, common_1.Query)('periodFrom')),
    __param(3, (0, common_1.Query)('periodTo')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, String, String]),
    __metadata("design:returntype", void 0)
], WarehouseController.prototype, "listGoodsArrivals", null);
__decorate([
    (0, common_1.Get)('goods-arrivals/summary'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)('clientId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", void 0)
], WarehouseController.prototype, "goodsArrivalSummary", null);
__decorate([
    (0, common_1.Post)('goods-arrivals'),
    (0, require_permissions_decorator_1.RequirePermissions)('warehouse:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], WarehouseController.prototype, "createGoodsArrival", null);
__decorate([
    (0, common_1.Delete)('goods-arrivals/:id'),
    (0, require_permissions_decorator_1.RequirePermissions)('warehouse:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], WarehouseController.prototype, "deleteGoodsArrival", null);
__decorate([
    (0, common_1.Post)('goods-arrivals/bill'),
    (0, require_permissions_decorator_1.RequirePermissions)('billing:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], WarehouseController.prototype, "billGoodsArrivals", null);
__decorate([
    (0, common_1.Post)('online-receipts/boxes/open'),
    (0, require_permissions_decorator_1.RequirePermissions)('warehouse:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], WarehouseController.prototype, "openOnlineReceiptBox", null);
__decorate([
    (0, common_1.Post)('online-receipts/boxes/close'),
    (0, require_permissions_decorator_1.RequirePermissions)('warehouse:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], WarehouseController.prototype, "closeOnlineReceiptBox", null);
__decorate([
    (0, common_1.Post)('online-receipts/boxes/close-open'),
    (0, require_permissions_decorator_1.RequirePermissions)('warehouse:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], WarehouseController.prototype, "closeOpenOnlineReceiptBoxes", null);
__decorate([
    (0, common_1.Post)('online-receipts/finish'),
    (0, require_permissions_decorator_1.RequirePermissions)('warehouse:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], WarehouseController.prototype, "finishOnlineReceipt", null);
__decorate([
    (0, common_1.Delete)('online-receipts/boxes'),
    (0, require_permissions_decorator_1.RequirePermissions)('warehouse:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], WarehouseController.prototype, "deleteOnlineReceiptBox", null);
__decorate([
    (0, common_1.Post)('online-receipts/boxes/restore'),
    (0, require_permissions_decorator_1.RequirePermissions)('warehouse:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], WarehouseController.prototype, "restoreOnlineReceiptBox", null);
__decorate([
    (0, common_1.Post)('online-receipts/items'),
    (0, require_permissions_decorator_1.RequirePermissions)('warehouse:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], WarehouseController.prototype, "addOnlineReceiptItem", null);
__decorate([
    (0, common_1.Patch)('online-receipts/items/:id'),
    (0, require_permissions_decorator_1.RequirePermissions)('warehouse:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", void 0)
], WarehouseController.prototype, "updateOnlineReceiptItem", null);
__decorate([
    (0, common_1.Delete)('online-receipts/items/:id'),
    (0, require_permissions_decorator_1.RequirePermissions)('warehouse:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", void 0)
], WarehouseController.prototype, "deleteOnlineReceiptItem", null);
__decorate([
    (0, common_1.Post)('boxes'),
    (0, require_permissions_decorator_1.RequirePermissions)('warehouse:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [upsert_box_dto_1.UpsertBoxDto, Object]),
    __metadata("design:returntype", void 0)
], WarehouseController.prototype, "upsertBox", null);
__decorate([
    (0, common_1.Get)('pallets'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)('clientId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", void 0)
], WarehouseController.prototype, "listPallets", null);
__decorate([
    (0, common_1.Post)('pallets'),
    (0, require_permissions_decorator_1.RequirePermissions)('warehouse:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [upsert_pallet_dto_1.UpsertPalletDto, Object]),
    __metadata("design:returntype", void 0)
], WarehouseController.prototype, "upsertPallet", null);
exports.WarehouseController = WarehouseController = __decorate([
    (0, swagger_1.ApiTags)('warehouse'),
    (0, require_permissions_decorator_1.RequirePermissions)('warehouse:read'),
    (0, common_1.Controller)('warehouse'),
    __metadata("design:paramtypes", [warehouse_service_1.WarehouseService,
        warehouse_box_integrity_service_1.WarehouseBoxIntegrityService,
        warehouse_shipment_history_service_1.WarehouseShipmentHistoryService])
], WarehouseController);
