"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.WarehouseModule = void 0;
const common_1 = require("@nestjs/common");
const auth_module_1 = require("../auth/auth.module");
const billing_module_1 = require("../billing/billing.module");
const client_notifications_module_1 = require("../client-notifications/client-notifications.module");
const stock_module_1 = require("../stock/stock.module");
const warehouse_controller_1 = require("./warehouse.controller");
const warehouse_box_integrity_service_1 = require("./warehouse-box-integrity.service");
const warehouse_shipment_history_service_1 = require("./warehouse-shipment-history.service");
const warehouse_service_1 = require("./warehouse.service");
const storage_locations_controller_1 = require("./storage-locations.controller");
const storage_locations_service_1 = require("./storage-locations.service");
let WarehouseModule = class WarehouseModule {
};
exports.WarehouseModule = WarehouseModule;
exports.WarehouseModule = WarehouseModule = __decorate([
    (0, common_1.Module)({
        imports: [auth_module_1.AuthModule, billing_module_1.BillingModule, client_notifications_module_1.ClientNotificationsModule, stock_module_1.StockModule],
        controllers: [warehouse_controller_1.WarehouseController, storage_locations_controller_1.StorageLocationsController],
        providers: [
            warehouse_service_1.WarehouseService,
            storage_locations_service_1.StorageLocationsService,
            warehouse_box_integrity_service_1.WarehouseBoxIntegrityService,
            warehouse_shipment_history_service_1.WarehouseShipmentHistoryService,
        ],
        exports: [warehouse_service_1.WarehouseService, storage_locations_service_1.StorageLocationsService],
    })
], WarehouseModule);
