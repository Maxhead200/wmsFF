"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.WarehouseService = void 0;
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
const prisma_service_1 = require("../../common/prisma/prisma.service");
const inventory_lock_service_1 = require("../../common/inventory/inventory-lock.service");
const box_code_policy_service_1 = require("../../common/boxes/box-code-policy.service");
const receipt_batches_1 = require("../../common/receipt-batches");
const client_scope_service_1 = require("../auth/client-scope.service");
const billing_service_1 = require("../billing/billing.service");
const telegram_notification_service_1 = require("../client-notifications/telegram-notification.service");
const stock_balances_service_1 = require("../stock/stock-balances.service");
const stock_operations_service_1 = require("../stock/stock-operations.service");
let WarehouseService = class WarehouseService {
    prisma;
    clientScopes;
    balances;
    stockOperations;
    telegram;
    billing;
    boxCodes;
    inventoryLock;
    constructor(prisma, clientScopes, balances, stockOperations, telegram, billing, boxCodes, inventoryLock) {
        this.prisma = prisma;
        this.clientScopes = clientScopes;
        this.balances = balances;
        this.stockOperations = stockOperations;
        this.telegram = telegram;
        this.billing = billing;
        this.boxCodes = boxCodes;
        this.inventoryLock = inventoryLock;
    }
    resolveWriteWarehouseId(user, requestedWarehouseId) {
        if (user.roleCodes.includes('CLIENT')) {
            return undefined;
        }
        if (user.permissionCodes.includes('system:admin')) {
            const warehouseId = requestedWarehouseId || user.activeWarehouseId;
            if (!warehouseId) {
                throw new common_1.BadRequestException('Выберите активный филиал.');
            }
            return warehouseId;
        }
        return this.resolveWarehouseScope(user, requestedWarehouseId, true);
    }
    resolveReadWarehouseId(user) {
        if (user.roleCodes.includes('CLIENT'))
            return undefined;
        return this.resolveWarehouseScope(user, undefined, false);
    }
    assertBoxWarehouse(warehouseId, box) {
        if (warehouseId &&
            (box.warehouseId !== warehouseId ||
                (box.zoneId !== null && box.zoneId !== undefined && box.zone?.warehouseId !== warehouseId) ||
                (box.palletId !== null && box.palletId !== undefined && box.pallet?.zone?.warehouseId !== warehouseId))) {
            throw new common_1.ForbiddenException('Короб, его зона или паллета относятся к другому филиалу. Переключите город работы.');
        }
    }
    warehouseScopedBoxWhere(warehouseId) {
        if (!warehouseId)
            return undefined;
        return {
            warehouseId,
            AND: [
                { OR: [{ zoneId: null }, { zone: { warehouseId } }] },
                { OR: [{ palletId: null }, { pallet: { zone: { warehouseId } } }] },
            ],
        };
    }
    listWarehouses(user) {
        return this.prisma.warehouse.findMany({
            where: user && !user.permissionCodes.includes('system:admin')
                ? user.roleCodes.includes('CLIENT')
                    ? {
                        clients: {
                            some: {
                                clientId: { in: user.clientIds },
                                status: 'ACTIVE',
                            },
                        },
                    }
                    : { id: { in: user.warehouseIds ?? [] } }
                : undefined,
            include: { zones: true },
            orderBy: [{ sortOrder: 'asc' }, { code: 'asc' }],
        });
    }
    createWarehouse(dto, user) {
        if (!user.permissionCodes?.includes('system:admin')) {
            throw new common_1.ForbiddenException('Создавать филиалы может только администратор сети.');
        }
        return this.prisma.warehouse.create({
            data: {
                code: dto.code.trim(),
                name: dto.name.trim(),
            },
        });
    }
    listZones(user, warehouseId) {
        const resolvedWarehouseId = this.resolveWarehouseScope(user, warehouseId, false);
        return this.prisma.zone.findMany({
            where: { warehouseId: resolvedWarehouseId },
            include: { warehouse: true },
            orderBy: [{ warehouseId: 'asc' }, { code: 'asc' }],
        });
    }
    createZone(dto, user) {
        const warehouseId = this.resolveWarehouseScope(user, dto.warehouseId, true);
        if (!warehouseId) {
            throw new common_1.BadRequestException('Выберите активный филиал.');
        }
        // Русский комментарий: зоны нужны уже в MVP, стеллажи оставляем как следующий уровень адресации.
        return this.prisma.zone.create({
            data: {
                warehouseId,
                code: dto.code.trim(),
                name: dto.name.trim(),
            },
        });
    }
    listBoxes(filter, user) {
        const where = {
            clientId: this.clientScopes.resolveClientFilter(user, filter.clientId),
            warehouseId: user.activeWarehouseId && !user.roleCodes.includes('CLIENT')
                ? user.activeWarehouseId
                : undefined,
            code: filter.code ? { contains: filter.code, mode: 'insensitive' } : undefined,
            status: filter.archive
                ? { in: ['deleted', 'archived'] }
                : { notIn: ['deleted', 'archived'] },
        };
        return this.prisma.box.findMany({
            where,
            include: {
                client: true,
                zone: true,
                pallet: true,
                storagePlacement: {
                    include: {
                        pallet: {
                            include: { zone: true },
                        },
                    },
                },
                _count: { select: { balances: true, movements: true } },
            },
            orderBy: { code: 'asc' },
            take: 200,
        });
    }
    async listOnlineReceipts(filter, user) {
        const clientId = stringField(filter.clientId, 'clientId');
        this.clientScopes.requireClientAccess(user, clientId, 'read');
        const warehouseId = this.resolveReadWarehouseId(user);
        const receiptPrefix = (await this.boxCodes.getPolicy()).receiptPrefix;
        const client = await this.prisma.client.findUnique({
            where: { id: clientId },
            select: { id: true, onlineReceiptVisibleToClient: true },
        });
        if (!client) {
            throw new common_1.NotFoundException('Клиент не найден.');
        }
        if (!canReadOnlineReceipt(user) && !client.onlineReceiptVisibleToClient) {
            throw new common_1.ForbiddenException('Онлайн-приемка не открыта в кабинете этого клиента.');
        }
        const since = new Date(Date.now() - 1000 * 60 * 60 * 72);
        const operations = (await this.prisma.tsdOperation.findMany({
            where: {
                operationType: { in: ['receipt_open_box', 'receipt_box_status', 'receipt_scan'] },
                OR: [
                    { createdAt: { gte: since } },
                    { operationType: 'receipt_open_box' },
                    { operationType: 'receipt_box_status' },
                ],
                AND: [
                    { payload: { path: ['clientId'], equals: clientId } },
                    ...(warehouseId
                        ? [{ payload: { path: ['warehouseId'], equals: warehouseId } }]
                        : []),
                ],
            },
            // Fetch newest rows first so the operation cap cannot hide the current receipt batch.
            orderBy: { createdAt: 'desc' },
            take: 10000,
        })).reverse();
        const sourceDocuments = [
            ...new Set(operations.map((operation) => stringFromPayload(operation.payload, 'sourceDocument')).filter(Boolean)),
        ];
        const operationBoxCodes = [
            ...new Set(operations.map((operation) => normalizeBoxCode(stringFromPayload(operation.payload, 'boxCode'))).filter(Boolean)),
        ];
        const receivingBoxes = await this.prisma.box.findMany({
            where: {
                clientId,
                status: 'receiving',
                ...(this.warehouseScopedBoxWhere(warehouseId) ?? {}),
            },
            select: { code: true },
            orderBy: { code: 'asc' },
            take: 500,
        });
        const receivingBoxCodes = receivingBoxes.map((box) => box.code);
        const movementWhere = {
            clientId,
            warehouseId,
            type: client_1.MovementType.RECEIPT,
            OR: [
                sourceDocuments.length ? { sourceDocument: { in: sourceDocuments } } : undefined,
                { sourceDocument: { startsWith: 'TSD-RECEIPT-' }, createdAt: { gte: since } },
                operationBoxCodes.length ? { box: { code: { in: operationBoxCodes } } } : undefined,
            ].filter(Boolean),
        };
        const movements = await this.prisma.stockMovement.findMany({
            where: movementWhere,
            include: {
                box: true,
                sku: {
                    include: {
                        barcodes: {
                            select: { value: true, isPrimary: true },
                        },
                    },
                },
                productMarks: {
                    select: {
                        id: true,
                        value: true,
                        status: true,
                        createdAt: true,
                        updatedAt: true,
                    },
                },
            },
            orderBy: { createdAt: 'asc' },
            take: 3000,
        });
        const boxCodes = [
            ...new Set([
                ...operationBoxCodes,
                ...receivingBoxCodes,
                ...movements.map((movement) => movement.box?.code ?? '').filter(Boolean),
            ].filter(Boolean)),
        ];
        const boxes = boxCodes.length
            ? await this.prisma.box.findMany({
                where: {
                    clientId,
                    code: { in: boxCodes },
                    ...(this.warehouseScopedBoxWhere(warehouseId) ?? {}),
                },
                include: {
                    balances: {
                        include: {
                            sku: {
                                include: {
                                    barcodes: {
                                        select: { value: true, isPrimary: true },
                                    },
                                },
                            },
                        },
                    },
                    productMarks: {
                        select: {
                            id: true,
                            skuId: true,
                            value: true,
                            status: true,
                            createdAt: true,
                            updatedAt: true,
                        },
                    },
                },
            })
            : [];
        const boxByCode = new Map(boxes.map((box) => [normalizeBoxCode(box.code), box]));
        const actors = await this.resolveTsdActors(operations.map((operation) => operation.deviceId));
        const operationActors = new Map(operations.map((operation) => [operation.id, actors.get(operation.deviceId) ?? actorFallback(operation.deviceId)]));
        const boxMap = new Map();
        const sourceDocumentByBoxCode = new Map();
        const ensureBox = (boxCode, sourceDocument) => {
            const safeBoxCode = normalizeBoxCode(boxCode);
            const safeSourceDocument = text(sourceDocument);
            const key = safeBoxCode;
            const existing = boxMap.get(key);
            if (existing) {
                attachSourceDocument(existing, safeSourceDocument);
                return existing;
            }
            const box = boxByCode.get(safeBoxCode) ?? null;
            const created = {
                key,
                boxId: box?.id ?? null,
                boxCode: safeBoxCode,
                sourceDocument: safeSourceDocument,
                status: box?.status ?? 'receiving',
                firstSeenAt: null,
                lastSeenAt: null,
                openedAt: null,
                closedAt: null,
                deletedAt: null,
                operator: null,
                deviceCode: null,
                sourceDocuments: [],
                items: [],
                currentBalances: [],
                kizValues: [],
            };
            attachSourceDocument(created, safeSourceDocument);
            boxMap.set(key, created);
            return created;
        };
        operations.forEach((operation) => {
            const payload = recordFromJson(operation.payload);
            const boxCode = text(payload.boxCode);
            if (!boxCode) {
                return;
            }
            const sourceDocument = text(payload.sourceDocument);
            if (sourceDocument && !sourceDocumentByBoxCode.has(normalizeBoxCode(boxCode))) {
                sourceDocumentByBoxCode.set(normalizeBoxCode(boxCode), sourceDocument);
            }
            const box = ensureBox(boxCode, sourceDocument);
            const actor = operationActors.get(operation.id) ?? actorFallback(operation.deviceId);
            box.firstSeenAt = minIso(box.firstSeenAt, operation.createdAt);
            box.lastSeenAt = maxIso(box.lastSeenAt, operation.createdAt);
            box.operator = actor.name;
            box.deviceCode = actor.deviceCode;
            if (operation.operationType === 'receipt_open_box') {
                box.openedAt = maxIso(box.openedAt, operation.createdAt);
                if (box.status !== 'active') {
                    box.status = 'receiving';
                }
            }
            if (operation.operationType === 'receipt_box_status') {
                const status = text(payload.status);
                if (status) {
                    box.status = status;
                }
                if (status === 'active') {
                    box.closedAt = maxIso(box.closedAt, operation.createdAt);
                }
                if (status === 'receiving') {
                    box.openedAt = maxIso(box.openedAt, operation.createdAt);
                }
                if (status === 'deleted') {
                    box.deletedAt = maxIso(box.deletedAt, operation.createdAt);
                    const snapshotItems = snapshotItemsFromPayload(payload);
                    if (snapshotItems.length > 0) {
                        box.items = snapshotItems.map((item, index) => snapshotToOnlineReceiptItem(item, {
                            operationId: operation.id,
                            index,
                            createdAt: operation.createdAt.toISOString(),
                            operatorName: actor.name,
                            deviceCode: actor.deviceCode,
                        }));
                    }
                }
            }
        });
        const operationByScanKey = new Map();
        const forcedReceiptOperationByMovementKey = new Map();
        operations
            .filter((operation) => operation.operationType === 'receipt_scan')
            .forEach((operation) => {
            const payload = recordFromJson(operation.payload);
            operationByScanKey.set(receiptScanKey(payload), operation);
            if (isReceiptAcceptedWithError(operation)) {
                forcedReceiptOperationByMovementKey.set(`${operation.operationKey}:accepted-with-error`, operation);
            }
        });
        movements.forEach((movement) => {
            if (!movement.box?.code) {
                return;
            }
            const sourceDocument = movement.sourceDocument ?? '';
            const box = ensureBox(movement.box.code, sourceDocument);
            if (box.status === 'deleted' && box.items.length > 0) {
                return;
            }
            const operation = (movement.idempotencyKey ? forcedReceiptOperationByMovementKey.get(movement.idempotencyKey) : undefined) ??
                operationByScanKey.get(receiptScanKey({
                    sourceDocument,
                    boxCode: movement.box.code,
                    barcode: primaryBarcode(movement.sku),
                    kiz: movement.productMarks[0]?.value ?? '',
                }));
            const operationPayload = operation ? recordFromJson(operation.payload) : {};
            const acceptedWithError = operation ? isReceiptAcceptedWithError(operation) : false;
            const actor = operation ? operationActors.get(operation.id) ?? actorFallback(operation.deviceId) : null;
            box.firstSeenAt = minIso(box.firstSeenAt, movement.createdAt);
            box.lastSeenAt = maxIso(box.lastSeenAt, movement.createdAt);
            if (actor) {
                box.operator = actor.name;
                box.deviceCode = actor.deviceCode;
            }
            box.items.push({
                movementId: movement.id,
                skuId: movement.skuId,
                barcode: primaryBarcode(movement.sku),
                name: movement.sku.name,
                article: movement.sku.article ?? movement.sku.internalSku,
                color: movement.sku.color,
                size: movement.sku.size,
                quantity: movement.quantity,
                kiz: movement.productMarks[0]?.value ?? (acceptedWithError ? text(operationPayload.kiz) || null : null),
                kizId: movement.productMarks[0]?.id ?? null,
                hasError: acceptedWithError,
                errorMessage: acceptedWithError ? operation?.resolutionMessage ?? operation?.serverMessage ?? 'Принято с ошибкой' : null,
                duplicateBoxCode: acceptedWithError
                    ? duplicateBoxCode(operation?.resolutionMessage ?? operation?.serverMessage ?? '')
                    : null,
                status: movement.status,
                sourceDocument: sourceDocument,
                createdAt: movement.createdAt.toISOString(),
                operatorName: actor?.name ?? box.operator,
                deviceCode: actor?.deviceCode ?? box.deviceCode,
            });
        });
        const movementSourceDocumentByBoxId = new Map();
        movements.forEach((movement) => {
            if (movement.boxId &&
                movement.sourceDocument &&
                !movementSourceDocumentByBoxId.has(movement.boxId)) {
                movementSourceDocumentByBoxId.set(movement.boxId, movement.sourceDocument);
            }
        });
        boxes.forEach((box) => {
            const sourceDocument = sourceDocumentByBoxCode.get(normalizeBoxCode(box.code)) ??
                movementSourceDocumentByBoxId.get(box.id) ??
                '';
            const onlineBox = ensureBox(box.code, sourceDocument);
            onlineBox.boxId = box.id;
            onlineBox.status = box.status;
            onlineBox.currentBalances = box.balances.map((balance) => ({
                balanceId: balance.id,
                skuId: balance.skuId,
                barcode: primaryBarcode(balance.sku),
                name: balance.sku.name,
                quantity: balance.quantity,
                status: balance.status,
            }));
            onlineBox.kizValues = box.productMarks
                .filter((mark) => mark.status === client_1.StockStatus.AVAILABLE)
                .map((mark) => ({
                id: mark.id,
                skuId: mark.skuId,
                value: mark.value,
                status: mark.status,
            }));
        });
        const allBoxes = [...boxMap.values()]
            .map((box) => ({
            ...box,
            sourceDocument: box.sourceDocument || box.sourceDocuments[0] || '',
            firstSeenAt: box.firstSeenAt,
            lastSeenAt: box.lastSeenAt,
            openedAt: box.openedAt,
            closedAt: box.closedAt,
            deletedAt: box.deletedAt,
            totalQuantity: box.currentBalances.reduce((sum, item) => sum + item.quantity, 0) || box.items.reduce((sum, item) => sum + item.quantity, 0),
            kizCount: box.kizValues.length || box.items.filter((item) => Boolean(item.kiz)).length,
            items: box.items.sort((left, right) => left.createdAt.localeCompare(right.createdAt)),
        }));
        const todayMoscow = moscowDateKey(new Date());
        const receiptBoxes = allBoxes
            .filter((box) => !['deleted', 'archived'].includes(box.status))
            .sort((left, right) => compareOnlineReceiptBoxes(left, right, todayMoscow));
        const currentBatchDate = receiptBoxes[0]
            ? (0, receipt_batches_1.receiptDateFromBoxCode)(receiptBoxes[0].boxCode, onlineReceiptActivityDate(receiptBoxes[0]), receiptPrefix)
            : null;
        const resultBoxes = currentBatchDate
            ? receiptBoxes.filter((box) => (0, receipt_batches_1.receiptDateFromBoxCode)(box.boxCode, onlineReceiptActivityDate(box), receiptPrefix) === currentBatchDate)
            : [];
        const activeBoxCodes = new Set(resultBoxes.map((box) => box.boxCode));
        const deletedBoxes = allBoxes
            .filter((box) => box.status === 'deleted' && !activeBoxCodes.has(box.boxCode))
            .sort((left, right) => (right.deletedAt ?? right.lastSeenAt ?? '').localeCompare(left.deletedAt ?? left.lastSeenAt ?? ''));
        const receipts = [...new Map(resultBoxes.map((box) => [box.sourceDocument || box.key, box])).keys()].map((sourceDocument) => {
            const sourceBoxes = resultBoxes.filter((box) => (box.sourceDocument || box.key) === sourceDocument);
            return {
                sourceDocument,
                boxes: sourceBoxes.length,
                quantity: sourceBoxes.reduce((sum, box) => sum + box.totalQuantity, 0),
                kizCount: sourceBoxes.reduce((sum, box) => sum + box.kizCount, 0),
                firstSeenAt: sourceBoxes.reduce((value, box) => minIso(value, box.firstSeenAt), null),
                lastSeenAt: sourceBoxes.reduce((value, box) => maxIso(value, box.lastSeenAt), null),
                operators: [...new Set(sourceBoxes.map((box) => box.operator).filter(Boolean))],
                devices: [...new Set(sourceBoxes.map((box) => box.deviceCode).filter(Boolean))],
            };
        });
        return {
            clientId,
            generatedAt: new Date().toISOString(),
            currentBatchDate,
            receipts,
            boxes: resultBoxes,
            deletedBoxes,
        };
    }
    async listReceiptBatches(filter, user) {
        const clientId = stringField(filter.clientId, 'clientId');
        this.clientScopes.requireClientAccess(user, clientId, 'read');
        const warehouseId = this.resolveReadWarehouseId(user);
        const receiptPrefix = (await this.boxCodes.getPolicy()).receiptPrefix;
        const movements = await this.prisma.stockMovement.findMany({
            where: {
                clientId,
                warehouseId,
                type: client_1.MovementType.RECEIPT,
                quantity: { gt: 0 },
                box: { code: { startsWith: receiptPrefix, mode: client_1.Prisma.QueryMode.insensitive } },
            },
            select: {
                quantity: true,
                createdAt: true,
                box: { select: { code: true } },
                _count: { select: { productMarks: true } },
            },
            orderBy: { createdAt: 'desc' },
            take: 50000,
        });
        const groups = new Map();
        for (const movement of movements) {
            const date = (0, receipt_batches_1.receiptDateFromBoxCode)(movement.box?.code ?? '', movement.createdAt, receiptPrefix);
            const group = groups.get(date) ?? { date, boxCodes: new Set(), quantity: 0, kizCount: 0 };
            if (movement.box?.code)
                group.boxCodes.add(movement.box.code);
            group.quantity += movement.quantity;
            group.kizCount += movement._count.productMarks;
            groups.set(date, group);
        }
        return [...groups.values()]
            .sort((left, right) => right.date.localeCompare(left.date))
            .map((group) => ({
            id: `${clientId}:${group.date}`,
            date: group.date,
            title: `${formatReceiptDate(group.date)} приемка`,
            boxes: group.boxCodes.size,
            quantity: group.quantity,
            kizCount: group.kizCount,
            boxCodes: [...group.boxCodes].sort((left, right) => left.localeCompare(right, 'ru', { numeric: true })),
        }));
    }
    async listGoodsArrivals(filter, user) {
        const clientId = stringField(filter.clientId, 'clientId');
        this.clientScopes.requireClientAccess(user, clientId, 'read');
        const warehouseId = this.resolveReadWarehouseId(user);
        const rows = await this.prisma.auditLog.findMany({
            where: {
                entity: 'goods-arrival',
                entityId: clientId,
                action: 'warehouse.goods-arrival',
                ...(warehouseId
                    ? { payload: { path: ['warehouseId'], equals: warehouseId } }
                    : {}),
            },
            orderBy: { createdAt: 'desc' },
            take: 5000,
        });
        return rows
            .map(goodsArrivalFromAudit)
            .filter((row) => row.status !== 'CANCELLED')
            .filter((row) => !filter.periodFrom || row.arrivalDate >= filter.periodFrom)
            .filter((row) => !filter.periodTo || row.arrivalDate <= filter.periodTo);
    }
    async createGoodsArrival(dto, user) {
        const clientId = stringField(dto.clientId, 'clientId');
        this.clientScopes.requireClientAccess(user, clientId, 'write');
        const warehouseId = this.resolveWriteWarehouseId(user, optionalString(dto.warehouseId));
        const arrivalDate = isoDateField(dto.arrivalDate, 'arrivalDate');
        const bagCount = nonNegativeInteger(dto.bagCount, 'bagCount');
        const boxCount = nonNegativeInteger(dto.boxCount, 'boxCount');
        if (bagCount + boxCount <= 0) {
            throw new common_1.BadRequestException('Укажите количество мешков или коробов больше нуля.');
        }
        const created = await this.prisma.auditLog.create({
            data: {
                userId: user.id,
                action: 'warehouse.goods-arrival',
                entity: 'goods-arrival',
                entityId: clientId,
                payload: {
                    clientId,
                    warehouseId,
                    arrivalDate,
                    bagCount,
                    boxCount,
                    comment: optionalString(dto.comment) ?? null,
                    status: 'ACTIVE',
                    createdByName: user.name,
                },
            },
        });
        return goodsArrivalFromAudit(created);
    }
    async deleteGoodsArrival(id, user) {
        const existing = await this.prisma.auditLog.findUnique({ where: { id } });
        if (!existing || existing.entity !== 'goods-arrival')
            throw new common_1.NotFoundException('Приход товара не найден.');
        const row = goodsArrivalFromAudit(existing);
        this.clientScopes.requireClientAccess(user, row.clientId, 'write');
        const warehouseId = this.resolveWriteWarehouseId(user);
        if (warehouseId && row.warehouseId !== warehouseId) {
            throw new common_1.ForbiddenException('Приход товара относится к другому филиалу или не имеет безопасной привязки.');
        }
        if (row.billingInvoiceId)
            throw new common_1.BadRequestException('Приход уже включен в счет. Сначала отмените счет или исправьте его в биллинге.');
        const updated = await this.prisma.auditLog.update({
            where: { id },
            data: { payload: { ...recordFromJson(existing.payload), status: 'CANCELLED', cancelledByUserId: user.id } },
        });
        return goodsArrivalFromAudit(updated);
    }
    async billGoodsArrivals(dto, user) {
        const clientId = stringField(dto.clientId, 'clientId');
        this.clientScopes.requireClientAccess(user, clientId, 'write');
        const periodFrom = isoDateField(dto.periodFrom, 'periodFrom');
        const periodTo = isoDateField(dto.periodTo, 'periodTo');
        if (periodFrom > periodTo)
            throw new common_1.BadRequestException('Начало периода не может быть позже окончания.');
        const arrivals = (await this.listGoodsArrivals({ clientId, periodFrom, periodTo }, user)).filter((row) => !row.billingInvoiceId);
        const bagCount = arrivals.reduce((sum, row) => sum + row.bagCount, 0);
        const boxCount = arrivals.reduce((sum, row) => sum + row.boxCount, 0);
        if (bagCount + boxCount <= 0)
            throw new common_1.BadRequestException('За выбранный период нет невыставленных приходов товара.');
        const services = await this.ensurePprServices();
        const rows = [
            bagCount > 0
                ? { serviceId: services.bags.id, description: 'ПРР: услуги грузчика, мешки', unit: client_1.BillingUnit.PIECE, quantity: bagCount }
                : null,
            boxCount > 0
                ? { serviceId: services.boxes.id, description: 'ПРР: услуги грузчика, короба', unit: client_1.BillingUnit.BOX, quantity: boxCount }
                : null,
        ].filter((row) => Boolean(row));
        const invoice = await this.billing.createManualInvoice({ clientId, periodFrom, periodTo, comment: `ПРР за период ${periodFrom} - ${periodTo}`, rows }, user);
        for (const arrival of arrivals) {
            const audit = await this.prisma.auditLog.findUnique({ where: { id: arrival.id } });
            if (!audit)
                continue;
            await this.prisma.auditLog.update({
                where: { id: arrival.id },
                data: { payload: { ...recordFromJson(audit.payload), billingInvoiceId: invoice.id, billedAt: new Date().toISOString() } },
            });
        }
        return invoice;
    }
    async goodsArrivalSummary(clientIdValue, user) {
        const clientId = stringField(clientIdValue, 'clientId');
        this.clientScopes.requireClientAccess(user, clientId, 'read');
        const latestPaid = await this.prisma.billingInvoice.findFirst({
            where: {
                clientId,
                status: 'PAID',
                items: { some: { charge: { service: { code: { in: ['PPR_BAGS', 'PPR_BOXES'] } } } } },
            },
            orderBy: [{ paidAt: 'desc' }, { updatedAt: 'desc' }],
            select: { paidAt: true, periodTo: true },
        });
        const monthStart = new Date();
        monthStart.setDate(1);
        const periodFrom = toIsoDate(latestPaid?.paidAt ?? latestPaid?.periodTo ?? monthStart);
        const periodTo = toIsoDate(new Date());
        const arrivals = await this.listGoodsArrivals({ clientId, periodFrom, periodTo }, user);
        const bagCount = arrivals.reduce((sum, row) => sum + row.bagCount, 0);
        const boxCount = arrivals.reduce((sum, row) => sum + row.boxCount, 0);
        const services = await this.ensurePprServices();
        const prices = await this.prisma.clientBillingService.findMany({
            where: { clientId, serviceId: { in: [services.bags.id, services.boxes.id] }, isActive: true },
            select: { serviceId: true, priceRub: true, taxMode: true },
        });
        const priceByService = new Map(prices.map((price) => [price.serviceId, price]));
        const bagPrice = pprPrice(priceByService.get(services.bags.id));
        const boxPrice = pprPrice(priceByService.get(services.boxes.id));
        return {
            clientId,
            periodFrom,
            periodTo,
            bagCount,
            boxCount,
            bagPriceRub: bagPrice,
            boxPriceRub: boxPrice,
            estimatedRub: roundMoney(bagCount * bagPrice + boxCount * boxPrice),
            pricesConfigured: bagPrice > 0 || boxPrice > 0,
        };
    }
    async ensurePprServices() {
        const [bags, boxes] = await Promise.all([
            this.prisma.billingService.upsert({
                where: { code: 'PPR_BAGS' },
                update: { name: 'ПРР: услуги грузчика, мешки', unit: client_1.BillingUnit.PIECE, isActive: true },
                create: { code: 'PPR_BAGS', name: 'ПРР: услуги грузчика, мешки', unit: client_1.BillingUnit.PIECE, isActive: true },
            }),
            this.prisma.billingService.upsert({
                where: { code: 'PPR_BOXES' },
                update: { name: 'ПРР: услуги грузчика, короба', unit: client_1.BillingUnit.BOX, isActive: true },
                create: { code: 'PPR_BOXES', name: 'ПРР: услуги грузчика, короба', unit: client_1.BillingUnit.BOX, isActive: true },
            }),
        ]);
        return { bags, boxes };
    }
    async openOnlineReceiptBox(dto, user) {
        await this.inventoryLock?.assertStockMovementsAllowed();
        const clientId = stringField(dto.clientId, 'clientId');
        const boxCode = await this.boxCodes.requireAllowed(stringField(dto.boxCode, 'boxCode'));
        const sourceDocument = optionalString(dto.sourceDocument) || `WEB-RECEIPT-${dateStamp()}-${boxCode}`;
        this.clientScopes.requireClientAccess(user, clientId, 'write');
        const warehouseId = this.resolveWriteWarehouseId(user, optionalString(dto.warehouseId));
        let box;
        try {
            box = await this.prisma.$transaction(async (tx) => {
                const existingBox = await tx.box.findFirst({
                    where: { code: boxCode },
                    select: { id: true, clientId: true, status: true },
                });
                if (existingBox) {
                    throw new common_1.BadRequestException(existingBox.status === 'deleted'
                        ? `Номер короба ${boxCode} уже использовался и был удален. Восстановите его или отсканируйте новый уникальный номер.`
                        : `Короб ${boxCode} уже был пропикан. Повторное использование номера запрещено.`);
                }
                return tx.box.create({
                    data: { clientId, warehouseId: warehouseId ?? user.activeWarehouseId, code: boxCode, status: 'receiving' },
                });
            });
        }
        catch (caught) {
            if (isPrismaUniqueConflict(caught)) {
                throw new common_1.BadRequestException(`Короб ${boxCode} уже был пропикан. Повторное использование номера запрещено.`);
            }
            throw caught;
        }
        await this.recordReceiptAdminOperation('receipt_open_box', user, {
            clientId,
            warehouseId,
            boxCode,
            sourceDocument,
            status: 'receiving',
            comment: optionalString(dto.comment) || 'Короб открыт из онлайн-приемки WMS.',
        });
        return { boxId: box.id, boxCode, status: box.status, sourceDocument };
    }
    async closeOnlineReceiptBox(dto, user) {
        await this.inventoryLock?.assertStockMovementsAllowed();
        return this.setOnlineReceiptBoxStatus(dto, user, 'active');
    }
    async closeOpenOnlineReceiptBoxes(dto, user) {
        await this.inventoryLock?.assertStockMovementsAllowed();
        const clientId = stringField(dto.clientId, 'clientId');
        this.clientScopes.requireClientAccess(user, clientId, 'write');
        const warehouseId = this.resolveWriteWarehouseId(user, optionalString(dto.warehouseId));
        const requestedBatchDate = optionalString(dto.batchDate);
        const receiptPrefix = (await this.boxCodes.getPolicy()).receiptPrefix;
        const candidateBoxes = await this.prisma.box.findMany({
            where: { clientId, status: 'receiving', ...(this.warehouseScopedBoxWhere(warehouseId) ?? {}) },
            select: { id: true, code: true },
            orderBy: { code: 'asc' },
        });
        const boxes = requestedBatchDate
            ? candidateBoxes.filter((box) => (0, receipt_batches_1.receiptDateFromBoxCode)(box.code, new Date(), receiptPrefix) === requestedBatchDate)
            : candidateBoxes;
        if (boxes.length === 0) {
            return { closed: 0, boxes: [] };
        }
        const comment = optionalString(dto.comment) || 'Все открытые короба закрыты из онлайн-приемки WMS.';
        await this.prisma.$transaction(async (tx) => {
            await tx.box.updateMany({
                where: { id: { in: boxes.map((box) => box.id) } },
                data: { status: 'active' },
            });
            for (const box of boxes) {
                await this.recordReceiptAdminOperation('receipt_box_status', user, {
                    clientId,
                    warehouseId,
                    boxCode: box.code,
                    status: 'active',
                    comment,
                }, tx);
            }
        });
        return { closed: boxes.length, boxes: boxes.map((box) => box.code), status: 'active' };
    }
    async finishOnlineReceipt(dto, user) {
        await this.inventoryLock?.assertStockMovementsAllowed();
        const clientId = stringField(dto.clientId, 'clientId');
        this.clientScopes.requireClientAccess(user, clientId, 'write');
        const warehouseId = this.resolveWriteWarehouseId(user, optionalString(dto.warehouseId));
        const client = await this.prisma.client.findUnique({
            where: { id: clientId },
            select: { id: true, name: true },
        });
        if (!client) {
            throw new common_1.NotFoundException('Клиент не найден.');
        }
        const todayStart = moscowDayStartUtc(new Date());
        const requestedBatchDate = optionalString(dto.batchDate);
        const receiptPrefix = (await this.boxCodes.getPolicy()).receiptPrefix;
        const candidateBoxes = await this.prisma.box.findMany({
            where: {
                clientId,
                ...(this.warehouseScopedBoxWhere(warehouseId) ?? {}),
                status: { notIn: ['deleted', 'archived'] },
                OR: [
                    { status: 'receiving' },
                    {
                        movements: {
                            some: {
                                clientId,
                                type: client_1.MovementType.RECEIPT,
                                createdAt: { gte: todayStart },
                            },
                        },
                    },
                ],
            },
            select: { id: true, code: true, status: true },
            orderBy: { code: 'asc' },
        });
        const boxes = requestedBatchDate
            ? candidateBoxes.filter((box) => (0, receipt_batches_1.receiptDateFromBoxCode)(box.code, new Date(), receiptPrefix) === requestedBatchDate)
            : candidateBoxes;
        if (boxes.length === 0) {
            throw new common_1.BadRequestException('Нет открытых или сегодняшних коробов приемки для завершения.');
        }
        const boxIds = boxes.map((box) => box.id);
        const [movementGroups, balanceGroups, kizCount] = await Promise.all([
            this.prisma.stockMovement.groupBy({
                by: ['boxId', 'skuId', 'status'],
                where: {
                    clientId,
                    type: client_1.MovementType.RECEIPT,
                    boxId: { in: boxIds },
                },
                _sum: { quantity: true },
            }),
            this.prisma.stockBalance.groupBy({
                by: ['boxId', 'skuId', 'status'],
                where: {
                    clientId,
                    boxId: { in: boxIds },
                },
                _sum: { quantity: true },
            }),
            this.prisma.productMark.count({
                where: {
                    clientId,
                    boxId: { in: boxIds },
                    status: client_1.StockStatus.AVAILABLE,
                },
            }),
        ]);
        const balanceByKey = new Map(balanceGroups.map((row) => [receiptBalanceKey(row.boxId, row.skuId, row.status), row._sum.quantity ?? 0]));
        const verificationErrors = movementGroups
            .map((row) => {
            const expected = row._sum.quantity ?? 0;
            const actual = balanceByKey.get(receiptBalanceKey(row.boxId, row.skuId, row.status)) ?? 0;
            return actual >= expected
                ? null
                : {
                    boxId: row.boxId,
                    skuId: row.skuId,
                    status: row.status,
                    expected,
                    actual,
                };
        })
            .filter(isVerificationError);
        if (verificationErrors.length > 0) {
            throw new common_1.BadRequestException({
                message: 'Приемку нельзя завершить: не все строки попали в остатки.',
                errors: verificationErrors.slice(0, 20),
            });
        }
        const closedBoxes = boxes.filter((box) => box.status === 'receiving');
        const totalQuantity = balanceGroups.reduce((sum, row) => sum + (row._sum.quantity ?? 0), 0);
        const finishedAt = new Date();
        const comment = optionalString(dto.comment) || 'Приемка завершена из онлайн-приемки WMS.';
        await this.prisma.$transaction(async (tx) => {
            if (closedBoxes.length > 0) {
                await tx.box.updateMany({
                    where: { id: { in: closedBoxes.map((box) => box.id) } },
                    data: { status: 'active' },
                });
            }
            for (const box of closedBoxes) {
                await this.recordReceiptAdminOperation('receipt_box_status', user, {
                    clientId,
                    warehouseId,
                    boxCode: box.code,
                    status: 'active',
                    comment,
                }, tx);
            }
            await this.recordReceiptAdminOperation('receipt_finish', user, {
                clientId,
                warehouseId,
                status: 'finished',
                boxes: boxes.length,
                closedBoxes: closedBoxes.length,
                quantity: totalQuantity,
                kizCount,
                finishedAt: finishedAt.toISOString(),
                comment,
            }, tx);
            await tx.clientNotification.create({
                data: {
                    clientId,
                    title: 'Приемка товара завершена',
                    body: `Приемка завершена. Коробов: ${boxes.length}, единиц: ${totalQuantity}, КИЗ: ${kizCount}.`,
                    severity: 'SUCCESS',
                    createdByUserId: user.id,
                },
            });
        });
        const telegram = await this.telegram.notifyClient(clientId, [
            'LOGOFF WMS: приемка товара завершена.',
            `Клиент: ${client.name}`,
            `Коробов: ${boxes.length}`,
            `Единиц: ${totalQuantity}`,
            `КИЗ: ${kizCount}`,
        ].join('\n'));
        return {
            finished: true,
            finishedAt: finishedAt.toISOString(),
            boxes: boxes.length,
            closedBoxes: closedBoxes.length,
            quantity: totalQuantity,
            kizCount,
            telegram,
        };
    }
    async deleteOnlineReceiptBox(dto, user) {
        await this.inventoryLock?.assertStockMovementsAllowed();
        const clientId = stringField(dto.clientId, 'clientId');
        const boxCode = await this.boxCodes.requireAllowed(stringField(dto.boxCode, 'boxCode'));
        this.clientScopes.requireClientAccess(user, clientId, 'write');
        const warehouseId = this.resolveWriteWarehouseId(user, optionalString(dto.warehouseId));
        await this.prisma.$transaction(async (tx) => {
            const box = await tx.box.findUnique({
                where: { clientId_code: { clientId, code: boxCode } },
                include: {
                    zone: { select: { warehouseId: true } },
                    pallet: { select: { zone: { select: { warehouseId: true } } } },
                    balances: {
                        include: {
                            sku: {
                                include: {
                                    barcodes: {
                                        select: { value: true, isPrimary: true },
                                    },
                                },
                            },
                        },
                    },
                    productMarks: true,
                },
            });
            if (!box) {
                throw new common_1.NotFoundException(`Короб ${boxCode} не найден.`);
            }
            this.assertBoxWarehouse(warehouseId, box);
            const snapshotItems = snapshotItemsFromBox(box);
            await removeOnlineReceiptBoxData(tx, box.id);
            await this.recordReceiptAdminOperation('receipt_box_status', user, {
                clientId,
                warehouseId,
                boxCode,
                sourceDocument: optionalString(dto.sourceDocument),
                status: 'deleted',
                snapshotStatus: box.status,
                snapshotItems,
                comment: optionalString(dto.comment) || 'Короб удален администратором.',
            }, tx);
        });
        return { boxCode, status: 'deleted' };
    }
    async restoreOnlineReceiptBox(dto, user) {
        await this.inventoryLock?.assertStockMovementsAllowed();
        const clientId = stringField(dto.clientId, 'clientId');
        const boxCode = await this.boxCodes.requireAllowed(stringField(dto.boxCode, 'boxCode'));
        this.clientScopes.requireClientAccess(user, clientId, 'write');
        const warehouseId = this.resolveWriteWarehouseId(user, optionalString(dto.warehouseId));
        const existingBox = await this.prisma.box.findUnique({
            where: { clientId_code: { clientId, code: boxCode } },
            select: {
                id: true,
                status: true,
                warehouseId: true,
                zoneId: true,
                palletId: true,
                zone: { select: { warehouseId: true } },
                pallet: { select: { zone: { select: { warehouseId: true } } } },
            },
        });
        if (existingBox) {
            this.assertBoxWarehouse(warehouseId, existingBox);
        }
        if (existingBox && existingBox.status !== 'deleted') {
            throw new common_1.BadRequestException(`Короб ${boxCode} уже есть в активных остатках.`);
        }
        const deletedOperation = await this.findLatestDeletedReceiptBoxOperation(clientId, boxCode);
        if (!deletedOperation) {
            throw new common_1.NotFoundException(`Нет данных удаления для короба ${boxCode}.`);
        }
        const payload = recordFromJson(deletedOperation.payload);
        if (warehouseId && optionalString(payload.warehouseId) !== warehouseId) {
            throw new common_1.ForbiddenException('Удаленный короб относится к другому филиалу или не имеет безопасной привязки.');
        }
        const sourceDocument = optionalString(payload.sourceDocument) || `RESTORE-RECEIPT-${dateStamp()}-${boxCode}`;
        const snapshotItems = snapshotItemsFromPayload(payload);
        const restoreItems = snapshotItems.length
            ? snapshotItems
            : await this.restoreItemsFromReceiptOperations(clientId, boxCode, deletedOperation.createdAt);
        if (restoreItems.length === 0) {
            throw new common_1.BadRequestException(`У короба ${boxCode} нет сохраненного состава для восстановления.`);
        }
        if (existingBox?.status === 'deleted') {
            await this.prisma.$transaction((tx) => removeOnlineReceiptBoxData(tx, existingBox.id));
        }
        for (const [index, item] of restoreItems.entries()) {
            await this.stockOperations.receiveIntoBox({
                clientId,
                warehouseId,
                boxCode,
                barcode: item.barcode,
                skuId: item.skuId,
                kiz: item.kiz,
                quantity: item.quantity,
                status: item.status ?? client_1.StockStatus.AVAILABLE,
                sourceDocument: item.sourceDocument || sourceDocument,
                idempotencyKey: `online-receipt-restore:${deletedOperation.id}:${index}`,
                comment: `Восстановление удаленного короба ${boxCode}.`,
            }, user);
        }
        await this.setOnlineReceiptBoxStatus({
            clientId,
            warehouseId,
            boxCode,
            sourceDocument,
            comment: `Короб ${boxCode} восстановлен из онлайн-приемки.`,
        }, user, text(payload.snapshotStatus) || 'active');
        return { boxCode, status: text(payload.snapshotStatus) || 'active', restoredItems: restoreItems.length };
    }
    async addOnlineReceiptItem(dto, user) {
        await this.inventoryLock?.assertStockMovementsAllowed();
        const clientId = stringField(dto.clientId, 'clientId');
        const boxCode = await this.boxCodes.requireAllowed(stringField(dto.boxCode, 'boxCode'));
        const barcode = optionalString(dto.barcode);
        const skuId = optionalString(dto.skuId);
        const quantity = positiveInteger(dto.quantity ?? 1, 'quantity');
        const kiz = optionalString(dto.kiz);
        const sourceDocument = optionalString(dto.sourceDocument) || `WEB-RECEIPT-${dateStamp()}-${boxCode}`;
        const boxPolicy = await this.boxCodes.getPolicy();
        validateReceiptProductBarcode(barcode, boxPolicy.allowedPrefixes);
        validateReceiptKiz(kiz, boxPolicy.allowedPrefixes);
        this.clientScopes.requireClientAccess(user, clientId, 'write');
        const warehouseId = this.resolveWriteWarehouseId(user, optionalString(dto.warehouseId));
        const existingBox = await this.prisma.box.findUnique({
            where: { clientId_code: { clientId, code: boxCode } },
            select: {
                id: true,
                warehouseId: true,
                zoneId: true,
                palletId: true,
                zone: { select: { warehouseId: true } },
                pallet: { select: { zone: { select: { warehouseId: true } } } },
            },
        });
        if (existingBox) {
            this.assertBoxWarehouse(warehouseId, existingBox);
            await this.prisma.box.update({ where: { id: existingBox.id }, data: { status: 'receiving' } });
        }
        else {
            await this.prisma.box.create({
                data: {
                    clientId,
                    warehouseId: warehouseId ?? user.activeWarehouseId,
                    code: boxCode,
                    status: 'receiving',
                },
            });
        }
        const result = await this.stockOperations.receiveIntoBox({
            clientId,
            warehouseId,
            boxCode,
            barcode,
            skuId,
            kiz,
            quantity,
            status: client_1.StockStatus.AVAILABLE,
            sourceDocument,
            idempotencyKey: `online-receipt-add:${clientId}:${boxCode}:${Date.now()}:${Math.random().toString(36).slice(2)}`,
            comment: optionalString(dto.comment) || `Онлайн-приемка WMS: ${user.name}`,
        }, user);
        await this.recordReceiptAdminOperation('receipt_scan', user, {
            clientId,
            warehouseId,
            boxCode,
            barcode,
            skuId,
            kiz,
            quantity,
            status: client_1.StockStatus.AVAILABLE,
            sourceDocument,
            comment: optionalString(dto.comment) || 'Строка добавлена администратором в онлайн-приемке.',
        });
        return result;
    }
    async updateOnlineReceiptItem(id, dto, user) {
        await this.inventoryLock?.assertStockMovementsAllowed();
        const quantity = dto.quantity === undefined ? undefined : positiveInteger(dto.quantity, 'quantity');
        const kiz = dto.kiz === undefined ? undefined : optionalString(dto.kiz) ?? '';
        const boxPolicy = await this.boxCodes.getPolicy();
        validateReceiptKiz(kiz || undefined, boxPolicy.allowedPrefixes);
        const warehouseId = this.resolveWriteWarehouseId(user, optionalString(dto.warehouseId));
        return this.prisma.$transaction(async (tx) => {
            const movement = await tx.stockMovement.findUnique({
                where: { id },
                include: {
                    box: {
                        include: {
                            zone: { select: { warehouseId: true } },
                            pallet: { select: { zone: { select: { warehouseId: true } } } },
                        },
                    },
                    productMarks: true,
                },
            });
            if (!movement || movement.type !== client_1.MovementType.RECEIPT || !movement.boxId || !movement.box) {
                throw new common_1.NotFoundException('Строка приемки не найдена.');
            }
            this.clientScopes.requireClientAccess(user, movement.clientId, 'write');
            this.assertBoxWarehouse(warehouseId, movement.box);
            if (quantity !== undefined && quantity !== movement.quantity) {
                await this.adjustBalanceQuantity(tx, {
                    clientId: movement.clientId,
                    warehouseId: warehouseId ?? movement.box.warehouseId,
                    skuId: movement.skuId,
                    boxId: movement.boxId,
                    palletId: movement.palletId,
                    status: movement.status,
                    delta: quantity - movement.quantity,
                });
                await tx.stockMovement.update({ where: { id }, data: { quantity } });
            }
            if (kiz !== undefined) {
                const existingMark = movement.productMarks[0];
                if (existingMark && kiz) {
                    await tx.productMark.update({ where: { id: existingMark.id }, data: { value: kiz } });
                }
                else if (existingMark && !kiz) {
                    await tx.productMark.delete({ where: { id: existingMark.id } });
                }
                else if (!existingMark && kiz) {
                    await tx.productMark.create({
                        data: {
                            clientId: movement.clientId,
                            skuId: movement.skuId,
                            boxId: movement.boxId,
                            stockMovementId: movement.id,
                            value: kiz,
                            sourceDocument: movement.sourceDocument,
                            status: movement.status,
                        },
                    });
                }
            }
            await this.recordReceiptAdminOperation('receipt_scan', user, {
                clientId: movement.clientId,
                warehouseId,
                boxCode: movement.box.code,
                quantity: quantity ?? movement.quantity,
                kiz,
                sourceDocument: movement.sourceDocument,
                status: movement.status,
                comment: optionalString(dto.comment) || 'Строка приемки изменена администратором.',
            }, tx);
            return { id, updated: true };
        });
    }
    resolveWarehouseScope(user, requestedWarehouseId, write) {
        if (user.roleCodes.includes('CLIENT')) {
            if (!requestedWarehouseId)
                return undefined;
            return requestedWarehouseId;
        }
        const warehouseId = user.activeWarehouseId || requestedWarehouseId;
        if (!warehouseId) {
            throw new common_1.BadRequestException('Выберите активный филиал.');
        }
        if (requestedWarehouseId && requestedWarehouseId !== warehouseId) {
            throw new common_1.ForbiddenException('Данные другого филиала недоступны.');
        }
        if (!user.permissionCodes.includes('system:admin') &&
            !(write ? user.writableWarehouseIds : user.warehouseIds)?.includes(warehouseId)) {
            throw new common_1.ForbiddenException('Филиал не назначен сотруднику.');
        }
        return warehouseId;
    }
    async deleteOnlineReceiptItem(id, dto, user) {
        await this.inventoryLock?.assertStockMovementsAllowed();
        const warehouseId = this.resolveWriteWarehouseId(user, optionalString(dto.warehouseId));
        return this.prisma.$transaction(async (tx) => {
            const movement = await tx.stockMovement.findUnique({
                where: { id },
                include: {
                    box: {
                        include: {
                            zone: { select: { warehouseId: true } },
                            pallet: { select: { zone: { select: { warehouseId: true } } } },
                        },
                    },
                    productMarks: true,
                },
            });
            if (!movement || movement.type !== client_1.MovementType.RECEIPT || !movement.boxId || !movement.box) {
                throw new common_1.NotFoundException('Строка приемки не найдена.');
            }
            this.clientScopes.requireClientAccess(user, movement.clientId, 'write');
            this.assertBoxWarehouse(warehouseId, movement.box);
            await this.adjustBalanceQuantity(tx, {
                clientId: movement.clientId,
                warehouseId: warehouseId ?? movement.box.warehouseId,
                skuId: movement.skuId,
                boxId: movement.boxId,
                palletId: movement.palletId,
                status: movement.status,
                delta: -movement.quantity,
            });
            await tx.productMark.deleteMany({ where: { stockMovementId: movement.id } });
            await tx.stockMovement.delete({ where: { id } });
            await this.recordReceiptAdminOperation('receipt_scan', user, {
                clientId: movement.clientId,
                warehouseId,
                boxCode: movement.box.code,
                quantity: -movement.quantity,
                sourceDocument: movement.sourceDocument,
                status: movement.status,
                comment: optionalString(dto.comment) || 'Строка приемки удалена администратором.',
            }, tx);
            return { id, deleted: true };
        });
    }
    async setOnlineReceiptBoxStatus(dto, user, status) {
        const clientId = stringField(dto.clientId, 'clientId');
        const boxCode = await this.boxCodes.requireAllowed(stringField(dto.boxCode, 'boxCode'));
        this.clientScopes.requireClientAccess(user, clientId, 'write');
        const warehouseId = this.resolveWriteWarehouseId(user, optionalString(dto.warehouseId));
        const existingBox = await this.prisma.box.findUnique({
            where: { clientId_code: { clientId, code: boxCode } },
            select: {
                id: true,
                warehouseId: true,
                zoneId: true,
                palletId: true,
                zone: { select: { warehouseId: true } },
                pallet: { select: { zone: { select: { warehouseId: true } } } },
            },
        });
        if (existingBox) {
            this.assertBoxWarehouse(warehouseId, existingBox);
        }
        const box = existingBox
            ? await this.prisma.box.update({ where: { id: existingBox.id }, data: { status } })
            : await this.prisma.box.create({
                data: { clientId, code: boxCode, status, warehouseId: warehouseId ?? user.activeWarehouseId },
            });
        await this.recordReceiptAdminOperation('receipt_box_status', user, {
            clientId,
            warehouseId,
            boxCode,
            sourceDocument: optionalString(dto.sourceDocument),
            status,
            comment: optionalString(dto.comment) || (status === 'active' ? 'Короб закрыт из онлайн-приемки WMS.' : 'Короб открыт из онлайн-приемки WMS.'),
        });
        return { boxId: box.id, boxCode, status };
    }
    async adjustBalanceQuantity(tx, input) {
        if (input.delta === 0) {
            return;
        }
        const balance = await tx.stockBalance.findFirst({
            where: {
                clientId: input.clientId,
                warehouseId: input.warehouseId,
                skuId: input.skuId,
                boxId: input.boxId,
                status: input.status,
            },
        });
        if (!balance && input.delta < 0) {
            throw new common_1.BadRequestException('В коробе нет такого остатка для удаления.');
        }
        if (!balance) {
            await tx.stockBalance.create({
                data: {
                    balanceKey: this.balances.balanceKey(input),
                    clientId: input.clientId,
                    warehouseId: input.warehouseId,
                    skuId: input.skuId,
                    boxId: input.boxId,
                    palletId: input.palletId,
                    status: input.status,
                    quantity: input.delta,
                },
            });
            return;
        }
        const nextQuantity = balance.quantity + input.delta;
        if (nextQuantity < 0) {
            throw new common_1.BadRequestException('Нельзя удалить больше товара, чем сейчас числится в коробе.');
        }
        if (nextQuantity === 0) {
            await tx.stockBalance.delete({ where: { id: balance.id } });
            return;
        }
        await tx.stockBalance.update({ where: { id: balance.id }, data: { quantity: nextQuantity } });
    }
    findLatestDeletedReceiptBoxOperation(clientId, boxCode) {
        return this.prisma.tsdOperation.findFirst({
            where: {
                operationType: 'receipt_box_status',
                payload: {
                    path: ['clientId'],
                    equals: clientId,
                },
            },
            orderBy: { createdAt: 'desc' },
        }).then((operation) => {
            if (!operation) {
                return null;
            }
            const payload = recordFromJson(operation.payload);
            if (normalizeBoxCode(text(payload.boxCode)) === boxCode && text(payload.status) === 'deleted') {
                return operation;
            }
            return this.findDeletedReceiptBoxOperationByScan(clientId, boxCode);
        });
    }
    async findDeletedReceiptBoxOperationByScan(clientId, boxCode) {
        const operations = await this.prisma.tsdOperation.findMany({
            where: {
                operationType: 'receipt_box_status',
                payload: {
                    path: ['clientId'],
                    equals: clientId,
                },
            },
            orderBy: { createdAt: 'desc' },
            take: 200,
        });
        return (operations.find((operation) => {
            const payload = recordFromJson(operation.payload);
            return normalizeBoxCode(text(payload.boxCode)) === boxCode && text(payload.status) === 'deleted';
        }) ?? null);
    }
    async restoreItemsFromReceiptOperations(clientId, boxCode, deletedAt) {
        const operations = await this.prisma.tsdOperation.findMany({
            where: {
                operationType: 'receipt_scan',
                createdAt: { lte: deletedAt },
                payload: {
                    path: ['clientId'],
                    equals: clientId,
                },
            },
            orderBy: { createdAt: 'asc' },
            take: 3000,
        });
        return operations
            .map((operation) => {
            const payload = recordFromJson(operation.payload);
            if (normalizeBoxCode(text(payload.boxCode)) !== boxCode) {
                return null;
            }
            const quantity = Number(payload.quantity ?? 1);
            if (!Number.isFinite(quantity) || quantity <= 0) {
                return null;
            }
            return {
                skuId: optionalString(payload.skuId),
                barcode: optionalString(payload.barcode),
                quantity: Math.trunc(quantity),
                kiz: optionalString(payload.kiz),
                status: normalizeStockStatus(payload.status) ?? client_1.StockStatus.AVAILABLE,
                sourceDocument: optionalString(payload.sourceDocument),
            };
        })
            .filter(isReceiptRestoreItem);
    }
    async recordReceiptAdminOperation(operationType, user, payload, tx = this.prisma) {
        const deviceId = user.deviceCode || `WEB:${user.email}`;
        await tx.tsdOperation.create({
            data: {
                deviceId,
                operationKey: `${operationType}:${Date.now()}:${Math.random().toString(36).slice(2)}`,
                operationType,
                payload: compactJson({ ...payload, warehouseId: payload.warehouseId ?? user.activeWarehouseId }),
                status: 'ACCEPTED',
                serverMessage: optionalString(payload.comment) || 'Операция онлайн-приемки WMS.',
            },
        });
    }
    async resolveTsdActors(deviceIds) {
        const codes = [...new Set(deviceIds.map((value) => text(value)).filter(Boolean))];
        const actors = new Map();
        if (codes.length === 0) {
            return actors;
        }
        const devices = await this.prisma.tsdDevice.findMany({
            where: { code: { in: codes } },
            include: {
                user: {
                    select: {
                        id: true,
                        email: true,
                        name: true,
                    },
                },
            },
        });
        devices.forEach((device) => {
            actors.set(device.code, {
                deviceCode: device.code,
                deviceName: device.name,
                name: device.user.name,
                userEmail: device.user.email,
            });
        });
        const userCodes = codes.filter((code) => code.startsWith('USER:') && !actors.has(code));
        if (userCodes.length > 0) {
            const emails = userCodes.map((code) => code.slice(5));
            const users = await this.prisma.user.findMany({
                where: { email: { in: emails } },
                select: { email: true, name: true },
            });
            users.forEach((userRow) => {
                const code = `USER:${userRow.email}`;
                actors.set(code, {
                    deviceCode: code,
                    deviceName: 'ТСД по логину',
                    name: userRow.name,
                    userEmail: userRow.email,
                });
            });
        }
        return actors;
    }
    async upsertBox(dto, user) {
        this.clientScopes.requireClientAccess(user, dto.clientId, 'write');
        const warehouseId = this.resolveWriteWarehouseId(user);
        const existing = await this.prisma.box.findUnique({
            where: { clientId_code: { clientId: dto.clientId, code: dto.code.trim() } },
            select: {
                id: true,
                warehouseId: true,
                zoneId: true,
                palletId: true,
                zone: { select: { warehouseId: true } },
                pallet: { select: { zone: { select: { warehouseId: true } } } },
            },
        });
        if (existing) {
            this.assertBoxWarehouse(warehouseId, existing);
        }
        const zone = dto.zoneId
            ? await this.prisma.zone.findUnique({ where: { id: dto.zoneId }, select: { id: true, warehouseId: true } })
            : null;
        if (dto.zoneId && (!zone || (warehouseId && zone.warehouseId !== warehouseId))) {
            throw new common_1.ForbiddenException('Зона хранения относится к другому филиалу.');
        }
        const pallet = dto.palletId
            ? await this.prisma.pallet.findUnique({
                where: { id: dto.palletId },
                select: { id: true, clientId: true, zoneId: true, zone: { select: { warehouseId: true } } },
            })
            : null;
        if (dto.palletId &&
            (!pallet || pallet.clientId !== dto.clientId || (warehouseId && pallet.zone?.warehouseId !== warehouseId))) {
            throw new common_1.ForbiddenException('Паллета относится к другому филиалу или клиенту.');
        }
        if (dto.zoneId && pallet?.zoneId && pallet.zoneId !== dto.zoneId) {
            throw new common_1.BadRequestException('Паллета находится в другой зоне хранения.');
        }
        return this.prisma.box.upsert({
            where: {
                clientId_code: {
                    clientId: dto.clientId,
                    code: dto.code.trim(),
                },
            },
            update: {
                warehouseId: warehouseId ?? user.activeWarehouseId,
                zoneId: dto.zoneId,
                palletId: dto.palletId,
            },
            create: {
                clientId: dto.clientId,
                warehouseId: warehouseId ?? user.activeWarehouseId,
                code: dto.code.trim(),
                zoneId: dto.zoneId,
                palletId: dto.palletId,
            },
            include: {
                zone: true,
                pallet: true,
            },
        });
    }
    listPallets(clientId, user) {
        return this.prisma.pallet.findMany({
            where: {
                clientId: this.clientScopes.resolveClientFilter(user, clientId),
                zone: user.activeWarehouseId && !user.roleCodes.includes('CLIENT')
                    ? { warehouseId: user.activeWarehouseId }
                    : undefined,
            },
            include: {
                client: true,
                zone: true,
                boxes: true,
                _count: { select: { balances: true } },
            },
            orderBy: { code: 'asc' },
            take: 200,
        });
    }
    async upsertPallet(dto, user) {
        this.clientScopes.requireClientAccess(user, dto.clientId, 'write');
        const warehouseId = this.resolveWriteWarehouseId(user);
        const existing = await this.prisma.pallet.findUnique({
            where: { clientId_code: { clientId: dto.clientId, code: dto.code.trim() } },
            select: { id: true, zone: { select: { warehouseId: true } } },
        });
        if (warehouseId && existing && existing.zone?.warehouseId !== warehouseId) {
            throw new common_1.ForbiddenException('Паллета относится к другому филиалу.');
        }
        const zone = dto.zoneId
            ? await this.prisma.zone.findUnique({ where: { id: dto.zoneId }, select: { id: true, warehouseId: true } })
            : null;
        if (warehouseId && (!zone || zone.warehouseId !== warehouseId)) {
            throw new common_1.ForbiddenException('Для паллеты выберите зону активного филиала.');
        }
        return this.prisma.pallet.upsert({
            where: {
                clientId_code: {
                    clientId: dto.clientId,
                    code: dto.code.trim(),
                },
            },
            update: {
                zoneId: dto.zoneId,
            },
            create: {
                clientId: dto.clientId,
                code: dto.code.trim(),
                zoneId: dto.zoneId,
            },
            include: {
                zone: true,
            },
        });
    }
};
exports.WarehouseService = WarehouseService;
exports.WarehouseService = WarehouseService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        client_scope_service_1.ClientScopeService,
        stock_balances_service_1.StockBalancesService,
        stock_operations_service_1.StockOperationsService,
        telegram_notification_service_1.TelegramNotificationService,
        billing_service_1.BillingService,
        box_code_policy_service_1.BoxCodePolicyService,
        inventory_lock_service_1.InventoryLockService])
], WarehouseService);
function attachSourceDocument(box, sourceDocument) {
    if (!sourceDocument) {
        return;
    }
    if (!box.sourceDocument) {
        box.sourceDocument = sourceDocument;
    }
    if (!box.sourceDocuments.includes(sourceDocument)) {
        box.sourceDocuments.push(sourceDocument);
    }
}
function snapshotItemsFromBox(box) {
    const marksBySku = new Map();
    box.productMarks
        .filter((mark) => mark.status === client_1.StockStatus.AVAILABLE)
        .forEach((mark) => {
        const list = marksBySku.get(mark.skuId) ?? [];
        list.push(mark);
        marksBySku.set(mark.skuId, list);
    });
    return box.balances.flatMap((balance) => {
        const base = {
            skuId: balance.skuId,
            barcode: primaryBarcode(balance.sku),
            name: balance.sku.name,
            article: balance.sku.article ?? balance.sku.internalSku,
            color: balance.sku.color,
            size: balance.sku.size,
            status: balance.status,
        };
        const marks = marksBySku.get(balance.skuId) ?? [];
        if (marks.length > 0) {
            return marks.map((mark) => ({
                ...base,
                quantity: 1,
                kiz: mark.value,
                sourceDocument: mark.sourceDocument ?? undefined,
            }));
        }
        return [
            {
                ...base,
                quantity: balance.quantity,
            },
        ];
    });
}
function snapshotItemsFromPayload(payload) {
    const items = Array.isArray(payload.snapshotItems) ? payload.snapshotItems : [];
    return items
        .map((item) => (item && typeof item === 'object' && !Array.isArray(item) ? item : null))
        .filter((item) => Boolean(item))
        .map((item) => {
        const quantity = Number(item.quantity ?? 1);
        if (!Number.isFinite(quantity) || quantity <= 0) {
            return null;
        }
        return {
            skuId: optionalString(item.skuId),
            barcode: optionalString(item.barcode),
            name: optionalString(item.name),
            article: optionalString(item.article),
            color: optionalString(item.color) ?? null,
            size: optionalString(item.size) ?? null,
            quantity: Math.trunc(quantity),
            kiz: optionalString(item.kiz),
            status: normalizeStockStatus(item.status) ?? client_1.StockStatus.AVAILABLE,
            sourceDocument: optionalString(item.sourceDocument),
        };
    })
        .filter(isReceiptRestoreItem);
}
function isReceiptRestoreItem(item) {
    return Boolean(item);
}
function snapshotToOnlineReceiptItem(item, meta) {
    return {
        movementId: `deleted:${meta.operationId}:${meta.index}`,
        skuId: item.skuId ?? '',
        barcode: item.barcode ?? '',
        name: item.name ?? item.barcode ?? item.skuId ?? 'Товар',
        article: item.article ?? '',
        color: item.color ?? null,
        size: item.size ?? null,
        quantity: item.quantity,
        kiz: item.kiz ?? null,
        kizId: null,
        hasError: false,
        errorMessage: null,
        duplicateBoxCode: null,
        status: item.status ?? client_1.StockStatus.AVAILABLE,
        sourceDocument: item.sourceDocument ?? '',
        createdAt: meta.createdAt,
        operatorName: meta.operatorName,
        deviceCode: meta.deviceCode,
    };
}
function normalizeStockStatus(value) {
    const status = text(value);
    return Object.values(client_1.StockStatus).includes(status) ? status : null;
}
function canReadOnlineReceipt(user) {
    return user.permissionCodes.includes('system:admin') || user.permissionCodes.includes('warehouse:read');
}
function recordFromJson(value) {
    return value && typeof value === 'object' && !Array.isArray(value) ? value : {};
}
function stringFromPayload(payload, key) {
    return text(recordFromJson(payload)[key]);
}
function stringField(value, field) {
    const result = text(value);
    if (!result) {
        throw new common_1.BadRequestException(`Поле ${field} обязательно.`);
    }
    return result;
}
function optionalString(value) {
    const result = text(value);
    return result || undefined;
}
function positiveInteger(value, field) {
    const parsed = typeof value === 'number' ? value : Number(value);
    if (!Number.isInteger(parsed) || parsed <= 0) {
        throw new common_1.BadRequestException(`Поле ${field} должно быть положительным целым числом.`);
    }
    return parsed;
}
function nonNegativeInteger(value, field) {
    const parsed = value == null || value === '' ? 0 : Number(value);
    if (!Number.isInteger(parsed) || parsed < 0) {
        throw new common_1.BadRequestException(`Поле ${field} должно быть целым числом от 0.`);
    }
    return parsed;
}
function isoDateField(value, field) {
    const result = text(value);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(result) || Number.isNaN(new Date(`${result}T00:00:00.000Z`).getTime())) {
        throw new common_1.BadRequestException(`Поле ${field} должно содержать дату в формате ГГГГ-ММ-ДД.`);
    }
    return result;
}
function goodsArrivalFromAudit(row) {
    const payload = recordFromJson(row.payload);
    return {
        id: row.id,
        clientId: text(payload.clientId),
        warehouseId: text(payload.warehouseId) || null,
        arrivalDate: text(payload.arrivalDate),
        bagCount: Number(payload.bagCount) || 0,
        boxCount: Number(payload.boxCount) || 0,
        comment: text(payload.comment) || null,
        status: text(payload.status) || 'ACTIVE',
        billingInvoiceId: text(payload.billingInvoiceId) || null,
        createdByName: text(payload.createdByName) || null,
        createdByUserId: row.userId,
        createdAt: row.createdAt.toISOString(),
    };
}
function formatReceiptDate(value) {
    const [year, month, day] = value.split('-');
    return `${day}.${month}.${year}`;
}
function toIsoDate(value) {
    return value.toISOString().slice(0, 10);
}
function pprPrice(value) {
    const price = Number(value?.priceRub ?? 0);
    return value?.taxMode === 'ADD_6_PERCENT' ? roundMoney((price / 94) * 100) : roundMoney(price);
}
function roundMoney(value) {
    return Math.round((value + Number.EPSILON) * 100) / 100;
}
function text(value) {
    return value == null ? '' : String(value).trim();
}
function normalizeBoxCode(value) {
    return value.trim().toLocaleUpperCase('ru-RU');
}
function isPrismaUniqueConflict(value) {
    return Boolean(value && typeof value === 'object' && 'code' in value && value.code === 'P2002');
}
function validateReceiptProductBarcode(value, allowedPrefixes) {
    if (!value) {
        return;
    }
    if (isConfiguredBoxCode(value, allowedPrefixes)) {
        throw new common_1.BadRequestException('В поле ШК товара отсканирован номер короба. Отсканируйте ШК товара.');
    }
    if (value.length > 13) {
        throw new common_1.BadRequestException('ШК товара не должен быть длиннее 13 символов. Возможно, отсканирован КИЗ.');
    }
}
function validateReceiptKiz(value, allowedPrefixes) {
    if (!value) {
        return;
    }
    if (isConfiguredBoxCode(value, allowedPrefixes)) {
        throw new common_1.BadRequestException('В поле КИЗ отсканирован номер короба. Отсканируйте КИЗ товара.');
    }
    if (value.length <= 20) {
        throw new common_1.BadRequestException('КИЗ должен быть длиннее 20 символов. Возможно, отсканирован ШК товара.');
    }
}
function isFflBoxCode(value) {
    return value.trim().toLocaleUpperCase('ru-RU').startsWith('FFL');
}
function isConfiguredBoxCode(value, allowedPrefixes) {
    const normalized = normalizeBoxCode(value);
    return allowedPrefixes.some((prefix) => normalized.startsWith(prefix));
}
function primaryBarcode(sku) {
    return sku.barcodes.find((barcode) => barcode.isPrimary)?.value ?? sku.barcodes[0]?.value ?? '';
}
function receiptScanKey(payload) {
    return [
        text(payload.sourceDocument),
        normalizeBoxCode(text(payload.boxCode)),
        text(payload.barcode),
        text(payload.kiz),
    ].join('|');
}
function isReceiptAcceptedWithError(operation) {
    return Boolean(operation.status === client_1.TsdOperationStatus.ACCEPTED &&
        operation.reviewReason === client_1.TsdReviewReason.RECEIPT_FAILED &&
        operation.reviewAction === 'APPLY_INVENTORY_ADJUSTMENT' &&
        operation.reviewComment?.startsWith('[RECEIPT_ERROR_ACCEPTED]'));
}
function duplicateBoxCode(message) {
    return message.match(/короб(?:е)?\s+([A-ZА-Я0-9_-]+)/iu)?.[1] ?? null;
}
function receiptBalanceKey(boxId, skuId, status) {
    return `${boxId ?? ''}|${skuId}|${status}`;
}
function isVerificationError(value) {
    return Boolean(value);
}
const moscowDateFormatter = new Intl.DateTimeFormat('en-CA', {
    day: '2-digit',
    month: '2-digit',
    timeZone: 'Europe/Moscow',
    year: 'numeric',
});
function moscowDayStartUtc(value) {
    const parts = moscowDateFormatter.formatToParts(value);
    const byType = new Map(parts.map((part) => [part.type, part.value]));
    const year = Number(byType.get('year'));
    const month = Number(byType.get('month'));
    const day = Number(byType.get('day'));
    return new Date(Date.UTC(year, month - 1, day) - 3 * 60 * 60 * 1000);
}
function compareOnlineReceiptBoxes(left, right, today) {
    const leftDate = onlineReceiptActivityDate(left);
    const rightDate = onlineReceiptActivityDate(right);
    const leftToday = moscowDateKey(leftDate) === today ? 1 : 0;
    const rightToday = moscowDateKey(rightDate) === today ? 1 : 0;
    if (leftToday !== rightToday) {
        return rightToday - leftToday;
    }
    const byDate = rightDate.getTime() - leftDate.getTime();
    return byDate || left.boxCode.localeCompare(right.boxCode, 'ru-RU');
}
function onlineReceiptActivityDate(value) {
    return dateFromIso(value.lastSeenAt) ?? dateFromIso(value.closedAt) ?? dateFromIso(value.openedAt) ?? dateFromIso(value.firstSeenAt) ?? new Date(0);
}
function dateFromIso(value) {
    if (!value) {
        return null;
    }
    const date = new Date(value);
    return Number.isNaN(date.getTime()) ? null : date;
}
function moscowDateKey(value) {
    const parts = moscowDateFormatter.formatToParts(value);
    const byType = new Map(parts.map((part) => [part.type, part.value]));
    return `${byType.get('year') ?? ''}-${byType.get('month') ?? ''}-${byType.get('day') ?? ''}`;
}
function minIso(current, value) {
    const next = iso(value);
    if (!next) {
        return current;
    }
    return !current || next < current ? next : current;
}
function maxIso(current, value) {
    const next = iso(value);
    if (!next) {
        return current;
    }
    return !current || next > current ? next : current;
}
function iso(value) {
    if (!value) {
        return '';
    }
    return value instanceof Date ? value.toISOString() : value;
}
function actorFallback(deviceId) {
    return {
        deviceCode: deviceId,
        deviceName: deviceId,
        name: deviceId.startsWith('WEB:') ? deviceId.slice(4) : deviceId,
    };
}
function compactJson(payload) {
    const result = {};
    Object.entries(payload).forEach(([key, value]) => {
        const jsonValue = toInputJsonValue(value);
        if (jsonValue === undefined) {
            return;
        }
        result[key] = jsonValue;
    });
    return result;
}
function toInputJsonValue(value) {
    if (value === undefined) {
        return undefined;
    }
    if (value === null || ['string', 'number', 'boolean'].includes(typeof value)) {
        return value;
    }
    if (value instanceof Date) {
        return value.toISOString();
    }
    if (Array.isArray(value)) {
        return value
            .map((item) => toInputJsonValue(item))
            .filter((item) => item !== undefined);
    }
    if (typeof value === 'object') {
        const objectValue = {};
        Object.entries(value).forEach(([key, item]) => {
            const jsonItem = toInputJsonValue(item);
            if (jsonItem !== undefined) {
                objectValue[key] = jsonItem;
            }
        });
        return objectValue;
    }
    return undefined;
}
function dateStamp() {
    const now = new Date();
    return [
        now.getFullYear(),
        String(now.getMonth() + 1).padStart(2, '0'),
        String(now.getDate()).padStart(2, '0'),
        '-',
        String(now.getHours()).padStart(2, '0'),
        String(now.getMinutes()).padStart(2, '0'),
        String(now.getSeconds()).padStart(2, '0'),
    ].join('');
}
async function removeOnlineReceiptBoxData(tx, boxId) {
    await tx.productMark.deleteMany({ where: { boxId } });
    await tx.stockBalance.deleteMany({ where: { boxId } });
    await tx.stockMovement.deleteMany({ where: { boxId } });
    await tx.box.delete({ where: { id: boxId } });
}
