"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.WmsAiInternetService = void 0;
const common_1 = require("@nestjs/common");
const SEARCH_TIMEOUT_MS = 10_000;
let WmsAiInternetService = class WmsAiInternetService {
    async search(question) {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), SEARCH_TIMEOUT_MS);
        try {
            const query = `WMS склад ${question}`.slice(0, 700);
            const response = await fetch(`https://html.duckduckgo.com/html/?q=${encodeURIComponent(query)}`, {
                headers: {
                    Accept: 'text/html',
                    'User-Agent': 'LOGOFF-WMS-AI/1.0 (warehouse support assistant)',
                },
                signal: controller.signal,
            });
            if (!response.ok) {
                return [];
            }
            return parseDuckDuckGo(await response.text()).slice(0, 5);
        }
        catch {
            return [];
        }
        finally {
            clearTimeout(timeout);
        }
    }
};
exports.WmsAiInternetService = WmsAiInternetService;
exports.WmsAiInternetService = WmsAiInternetService = __decorate([
    (0, common_1.Injectable)()
], WmsAiInternetService);
function parseDuckDuckGo(html) {
    const rows = html.split(/class="result results_links[^"]*"/i).slice(1);
    const result = [];
    for (const row of rows) {
        const link = row.match(/class="result__a"[^>]*href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/i);
        if (!link)
            continue;
        const url = unwrapDuckDuckGoUrl(decodeHtml(link[1]));
        if (!/^https?:\/\//i.test(url))
            continue;
        const snippetMatch = row.match(/class="result__snippet"[^>]*>([\s\S]*?)<\/(?:a|div)>/i);
        result.push({
            title: cleanHtml(link[2]),
            url,
            snippet: snippetMatch ? cleanHtml(snippetMatch[1]) : '',
        });
    }
    return uniqueByUrl(result);
}
function unwrapDuckDuckGoUrl(value) {
    try {
        const url = new URL(value, 'https://duckduckgo.com');
        const target = url.searchParams.get('uddg');
        return target ? decodeURIComponent(target) : url.toString();
    }
    catch {
        return value;
    }
}
function cleanHtml(value) {
    return decodeHtml(value.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim());
}
function decodeHtml(value) {
    return value
        .replace(/&amp;/g, '&')
        .replace(/&quot;/g, '"')
        .replace(/&#x27;|&#39;/g, "'")
        .replace(/&lt;/g, '<')
        .replace(/&gt;/g, '>');
}
function uniqueByUrl(items) {
    const seen = new Set();
    return items.filter((item) => {
        if (seen.has(item.url))
            return false;
        seen.add(item.url);
        return true;
    });
}
