"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.WmsAiLocalModelService = void 0;
const common_1 = require("@nestjs/common");
const MODEL_TIMEOUT_MS = 60_000;
let WmsAiLocalModelService = class WmsAiLocalModelService {
    baseUrl = (process.env.WMS_AI_OLLAMA_URL || 'http://ollama:11434').replace(/\/+$/, '');
    model = process.env.WMS_AI_OLLAMA_MODEL || 'qwen2.5:3b';
    async planTool(question) {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 20_000);
        try {
            const response = await fetch(`${this.baseUrl}/api/chat`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                signal: controller.signal,
                body: JSON.stringify({
                    model: this.model,
                    stream: false,
                    format: 'json',
                    options: { temperature: 0, num_predict: 220 },
                    messages: [
                        {
                            role: 'system',
                            content: [
                                'Выбери ровно один разрешённый read-only инструмент WMS.',
                                'Ответь только JSON: {"tool":"...","confidence":0.0,"params":{}}.',
                                'Инструменты: BOXES_NOT_IN_PALLET_SORT, UNRECOGNIZED_BOXES_IN_PALLET_SORT, PRODUCT_BOX_STOCK, BOX_CONTENTS, PALLET_CONTENTS, LOW_STOCK_SKUS, CLIENT_STOCK_SUMMARY, REQUEST_OVERVIEW, RECENT_STOCK_MOVEMENTS, KIZ_PROBLEMS, INTERBRANCH_TRANSFERS.',
                                'Параметры: search, boxCode, palletCode, maxTotal, minTotal, clientSearch, requestNumber, days, status.',
                                'Если уверенности нет, confidence должен быть меньше 0.55.',
                            ].join('\n'),
                        },
                        { role: 'user', content: question },
                    ],
                }),
            });
            if (!response.ok)
                return null;
            const payload = (await response.json());
            const content = payload.message?.content?.trim();
            if (!content)
                return null;
            const parsed = JSON.parse(content);
            if (!parsed ||
                typeof parsed.tool !== 'string' ||
                typeof parsed.confidence !== 'number') {
                return null;
            }
            return parsed;
        }
        catch {
            return null;
        }
        finally {
            clearTimeout(timeout);
        }
    }
    async answer(question, warehouse, sources) {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), MODEL_TIMEOUT_MS);
        try {
            const response = await fetch(`${this.baseUrl}/api/chat`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                signal: controller.signal,
                body: JSON.stringify({
                    model: this.model,
                    stream: false,
                    options: { temperature: 0.15, num_predict: 240 },
                    messages: [
                        {
                            role: 'system',
                            content: 'Ты локальный инженер WMS. Отвечай по-русски, кратко и предметно. ' +
                                'Не выдумывай данные WMS, SQL, результаты проверок и факты из источников. ' +
                                'Сначала сформулируй вероятную причину, затем безопасную диагностику и план решения. ' +
                                'Любое изменение данных или кода требует явного подтверждения администратора. ' +
                                'Используй только переданные источники и указывай, если их недостаточно.',
                        },
                        {
                            role: 'user',
                            content: [
                                `Активный склад: ${warehouse.name}, ${warehouse.city} (${warehouse.code}).`,
                                `Проблема: ${question}`,
                                sources.length
                                    ? `Результаты интернет-поиска:\n${sources
                                        .map((source, index) => `${index + 1}. ${source.title}\n${source.snippet}\n${source.url}`)
                                        .join('\n')}`
                                    : 'Интернет-источники не найдены.',
                            ].join('\n\n'),
                        },
                    ],
                }),
            });
            if (!response.ok)
                throw new Error(`Ollama HTTP ${response.status}`);
            const payload = (await response.json());
            const text = payload.message?.content?.trim();
            if (!text)
                throw new Error('Empty model response');
            return { text, engine: 'LOCAL_MODEL' };
        }
        catch {
            return {
                engine: 'LOCAL_RULES',
                text: sources.length
                    ? 'Готового локального решения пока нет. Я нашёл материалы по похожей проблеме. Проверьте источники ниже, затем сохраните подтверждённое решение — в следующий раз я применю его локально.'
                    : 'Готового локального решения пока нет, а интернет-поиск не дал надёжных источников. Опишите симптом, экран, номер объекта и текст ошибки подробнее — это поможет точно диагностировать проблему.',
            };
        }
        finally {
            clearTimeout(timeout);
        }
    }
};
exports.WmsAiLocalModelService = WmsAiLocalModelService;
exports.WmsAiLocalModelService = WmsAiLocalModelService = __decorate([
    (0, common_1.Injectable)()
], WmsAiLocalModelService);
