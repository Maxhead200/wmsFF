"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.WmsAiModule = void 0;
const common_1 = require("@nestjs/common");
const auth_module_1 = require("../auth/auth.module");
const wms_ai_controller_1 = require("./wms-ai.controller");
const wms_ai_internet_service_1 = require("./wms-ai-internet.service");
const wms_ai_local_model_service_1 = require("./wms-ai-local-model.service");
const wms_ai_service_1 = require("./wms-ai.service");
const wms_openclaw_service_1 = require("./wms-openclaw.service");
let WmsAiModule = class WmsAiModule {
};
exports.WmsAiModule = WmsAiModule;
exports.WmsAiModule = WmsAiModule = __decorate([
    (0, common_1.Module)({
        imports: [auth_module_1.AuthModule],
        controllers: [wms_ai_controller_1.WmsAiController],
        providers: [wms_ai_service_1.WmsAiService, wms_ai_internet_service_1.WmsAiInternetService, wms_ai_local_model_service_1.WmsAiLocalModelService, wms_openclaw_service_1.WmsOpenClawService],
    })
], WmsAiModule);
