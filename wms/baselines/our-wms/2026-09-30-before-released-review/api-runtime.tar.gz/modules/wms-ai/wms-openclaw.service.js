"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.WmsOpenClawService = void 0;
exports.openClawEnabled = openClawEnabled;
exports.openClawAllowed = openClawAllowed;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../common/prisma/prisma.service");
const ACTION = 'WMS_OPENCLAW_JOB';
const UNKNOWN = 'Результат выполнения неизвестен. Проверьте журнал OpenClaw и фактические изменения перед новым заданием. Повторное выполнение отключено.';
// FIX: the privileged gateway is isolated from legacy warehouse chat permissions.
function openClawEnabled() { return process.env.WMS_OPENCLAW_ENABLED === 'true'; }
function openClawAllowed(user) {
    if (user.isDemo || user.clientScopeMode !== 'ALL' || user.roleCodes?.includes('CLIENT'))
        return false;
    const administrator = Boolean(user.administrationEnabled || user.permissionCodes?.includes('system:admin'));
    if (!administrator)
        return false;
    if (process.env.WMS_OPENCLAW_ACCESS === 'administrators')
        return true;
    return (process.env.WMS_OPENCLAW_USER_IDS ?? '').split(',').map(id => id.trim()).filter(Boolean).includes(user.id);
}
let WmsOpenClawService = class WmsOpenClawService {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    status(user) {
        return { enabled: openClawEnabled(), allowed: openClawEnabled() && openClawAllowed(user), provider: 'OPENAI', engine: 'OPENCLAW' };
    }
    async submit(input, user) {
        this.assertAccess(user);
        this.validate(input);
        const config = this.config();
        const id = this.id(input.requestId);
        const payload = { ...input, message: input.message.trim(), status: 'RUNNING', warehouseId: user.activeWarehouseId ?? 'none' };
        // FIX: a database primary key arbitrates retries across API processes and restarts.
        try {
            await this.prisma.auditLog.create({ data: { id, userId: user.id, action: ACTION, entity: 'OpenClawJob', entityId: input.requestId, payload: payload } });
        }
        catch (error) {
            if (error.code !== 'P2002')
                throw error;
            const existing = await this.record(input.requestId, user);
            const old = existing.payload;
            if (old.message !== payload.message || old.conversationId !== payload.conversationId || old.warehouseId !== payload.warehouseId) {
                throw new common_1.ConflictException('Идентификатор задания уже использован для другого запроса.');
            }
            return this.publicJob(existing);
        }
        // No automatic retry: the agent may already have committed a real server change.
        void this.run(id, payload, user, config).catch(() => undefined);
        return { requestId: input.requestId, status: 'RUNNING' };
    }
    async get(requestId, user) {
        this.assertAccess(user);
        if (!this.uuid(requestId))
            throw new common_1.BadRequestException('Некорректный идентификатор задания.');
        return this.publicJob(await this.record(requestId, user));
    }
    async listJobs(user, cursor) {
        this.assertAccess(user);
        if (cursor && (!cursor.startsWith('openclaw:') || !this.uuid(cursor.slice(9)))) {
            throw new common_1.BadRequestException('Некорректная страница истории OpenClaw.');
        }
        if (cursor) {
            const previous = await this.prisma.auditLog.findUnique({ where: { id: cursor }, select: { action: true, entity: true } });
            if (previous?.action !== ACTION || previous.entity !== 'OpenClawJob') {
                throw new common_1.BadRequestException('Страница истории OpenClaw не найдена.');
            }
        }
        const rows = await this.prisma.auditLog.findMany({
            // FIX: use the existing AuditLog primary-key index instead of scanning all WMS audit rows.
            where: { id: { gte: 'openclaw:', lt: 'openclaw;' }, action: ACTION, entity: 'OpenClawJob' },
            orderBy: [{ createdAt: 'desc' }, { id: 'desc' }],
            take: 21,
            ...(cursor ? { cursor: { id: cursor }, skip: 1 } : {}),
            select: { id: true, userId: true, createdAt: true, payload: true, user: { select: { name: true } } },
        });
        return {
            items: rows.slice(0, 20).map(row => ({
                ...this.publicJob(row),
                conversationId: row.payload.conversationId,
                message: row.payload.message,
                userId: row.userId,
                userName: row.user?.name ?? 'Удалённый пользователь',
                createdAt: row.createdAt.toISOString(),
            })),
            nextCursor: rows.length > 20 ? rows[19].id : null,
        };
    }
    assertAccess(user) {
        if (!openClawEnabled())
            throw new common_1.ServiceUnavailableException('OpenClaw ещё не включён.');
        if (!openClawAllowed(user))
            throw new common_1.ForbiddenException('OpenClaw доступен только разрешённым администраторам и владельцу.');
    }
    uuid(value) { return /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(value); }
    validate(input) {
        if (!this.uuid(input.requestId) || !this.uuid(input.conversationId) || typeof input.message !== 'string' || input.message.trim().length < 2 || input.message.length > 4000)
            throw new common_1.BadRequestException('Некорректное задание OpenClaw.');
    }
    id(requestId) { return `openclaw:${requestId.toLowerCase()}`; }
    config() {
        const token = process.env.WMS_OPENCLAW_TOKEN;
        let url;
        try {
            url = new URL(process.env.WMS_OPENCLAW_URL ?? '');
        }
        catch {
            throw new common_1.ServiceUnavailableException('Не настроен адрес OpenClaw.');
        }
        if (!token || url.protocol !== 'http:' || !['127.0.0.1', 'localhost', '172.18.0.1', 'openclaw-gateway'].includes(url.hostname) || url.username || url.password || url.search || url.hash || !['', '/'].includes(url.pathname))
            throw new common_1.ServiceUnavailableException('Требуется закрытый адрес и серверный токен OpenClaw.');
        return { url: new URL('/v1/chat/completions', url).toString(), token };
    }
    async record(requestId, user) {
        const row = await this.prisma.auditLog.findUnique({ where: { id: this.id(requestId) } });
        if (!row || row.action !== ACTION || row.userId !== user.id)
            throw new common_1.NotFoundException('Задание не найдено.');
        return row;
    }
    publicJob(row) {
        const payload = row.payload;
        const stale = payload.status === 'RUNNING' && Date.now() - row.createdAt.getTime() > 11 * 60_000;
        return { requestId: payload.requestId, status: stale ? 'UNKNOWN' : payload.status, answer: payload.answer, error: stale ? UNKNOWN : payload.error };
    }
    async run(id, payload, user, config) {
        try {
            const response = await fetch(config.url, {
                method: 'POST', redirect: 'error', signal: AbortSignal.timeout(10 * 60_000),
                headers: { Authorization: `Bearer ${config.token}`, 'Content-Type': 'application/json' },
                body: JSON.stringify({ model: 'openclaw/wms', stream: false,
                    user: `wms:${user.id}:${payload.warehouseId}:${payload.conversationId.toLowerCase()}`,
                    messages: [{ role: 'user', content: `Контекст WMS: userId=${user.id}, warehouseId=${payload.warehouseId}, jobId=${payload.requestId}.\n${payload.message}` }],
                }),
            });
            if (!response.ok)
                throw new Error('Gateway failed');
            const data = await response.json();
            const answer = data.choices?.[0]?.message?.content;
            if (typeof answer !== 'string' || !answer.trim() || answer.length > 100_000)
                throw new Error('Invalid response');
            const redacted = answer.replaceAll(config.token, '[скрыто]');
            await this.prisma.auditLog.update({ where: { id }, data: { payload: { ...payload, status: 'DONE', answer: redacted, finishedAt: new Date().toISOString() } } });
        }
        catch {
            await this.prisma.auditLog.update({ where: { id }, data: { payload: { ...payload, status: 'UNKNOWN', error: UNKNOWN, finishedAt: new Date().toISOString() } } });
        }
    }
};
exports.WmsOpenClawService = WmsOpenClawService;
exports.WmsOpenClawService = WmsOpenClawService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], WmsOpenClawService);
