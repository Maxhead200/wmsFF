"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ClientsModule = void 0;
const common_1 = require("@nestjs/common");
const auth_module_1 = require("../auth/auth.module");
const clients_controller_1 = require("./clients.controller");
const clients_service_1 = require("./clients.service");
const product_display_controller_1 = require("./product-display.controller");
const product_display_service_1 = require("./product-display.service");
const core_1 = require("@nestjs/core");
const product_display_interceptor_1 = require("./product-display.interceptor");
let ClientsModule = class ClientsModule {
};
exports.ClientsModule = ClientsModule;
exports.ClientsModule = ClientsModule = __decorate([
    (0, common_1.Module)({
        imports: [auth_module_1.AuthModule],
        controllers: [clients_controller_1.ClientsController, product_display_controller_1.ProductDisplayController],
        providers: [clients_service_1.ClientsService, product_display_service_1.ProductDisplayService, { provide: core_1.APP_INTERCEPTOR, useClass: product_display_interceptor_1.ProductDisplayInterceptor }],
        exports: [clients_service_1.ClientsService],
    })
], ClientsModule);
