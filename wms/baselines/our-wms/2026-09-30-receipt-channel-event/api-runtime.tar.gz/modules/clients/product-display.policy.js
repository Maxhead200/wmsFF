"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PRODUCT_DISPLAY_FIELDS = void 0;
exports.validProductDisplayFields = validProductDisplayFields;
exports.productDisplayText = productDisplayText;
// FIX: presentation preferences never replace SKU identifiers or stored product data.
exports.PRODUCT_DISPLAY_FIELDS = ['name', 'article', 'barcode', 'size', 'color'];
function validProductDisplayFields(value) {
    return Array.isArray(value) && value.length > 0 && value.length <= 5 &&
        new Set(value).size === value.length &&
        value.every(field => exports.PRODUCT_DISPLAY_FIELDS.includes(field));
}
function productDisplayText(product, fields) {
    return fields.map(field => product[field]?.trim()).filter(Boolean).join(' · ');
}
