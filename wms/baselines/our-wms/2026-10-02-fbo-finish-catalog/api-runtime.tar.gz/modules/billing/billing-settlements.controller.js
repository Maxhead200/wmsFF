"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BillingSettlementsController = exports.BillingSettlementsQuery = void 0;
const common_1 = require("@nestjs/common");
const class_validator_1 = require("class-validator");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const require_permissions_decorator_1 = require("../auth/decorators/require-permissions.decorator");
const billing_settlements_service_1 = require("./billing-settlements.service");
class BillingSettlementsQuery {
    periodFrom;
    periodTo;
    clientId;
}
exports.BillingSettlementsQuery = BillingSettlementsQuery;
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Matches)(/^\d{4}-\d{2}-\d{2}$/),
    __metadata("design:type", String)
], BillingSettlementsQuery.prototype, "periodFrom", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Matches)(/^\d{4}-\d{2}-\d{2}$/),
    __metadata("design:type", String)
], BillingSettlementsQuery.prototype, "periodTo", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], BillingSettlementsQuery.prototype, "clientId", void 0);
// FIX: additive route leaves existing billing controllers and calculations intact.
let BillingSettlementsController = class BillingSettlementsController {
    settlements;
    constructor(settlements) {
        this.settlements = settlements;
    }
    list(query, user) { return this.settlements.list(query, user); }
};
exports.BillingSettlementsController = BillingSettlementsController;
__decorate([
    (0, common_1.Get)(),
    __param(0, (0, common_1.Query)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [BillingSettlementsQuery, Object]),
    __metadata("design:returntype", void 0)
], BillingSettlementsController.prototype, "list", null);
exports.BillingSettlementsController = BillingSettlementsController = __decorate([
    (0, common_1.Controller)('billing/settlements'),
    (0, require_permissions_decorator_1.RequirePermissions)('billing:read'),
    __metadata("design:paramtypes", [billing_settlements_service_1.BillingSettlementsService])
], BillingSettlementsController);
